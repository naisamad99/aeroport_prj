export class Notification {
    volCeduleId: number;
    numTel: string;
    dateInscription: Date;
    dateArret?: Date;
}