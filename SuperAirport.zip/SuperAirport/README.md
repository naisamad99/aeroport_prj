# SuperAirport
Airport website clone using asp.net core and angular material design

To start the project:

In SuperAirport/APIAeroport (Asp.net App) run the cestrel server: dotnet run (or) dotnet watch run to watch changes in code.

In SuperAirport/SPAAeroport (Angular App):
- npm install (to get back node_modules folder)
- ng serve --open (to open up the project in the browser)

This project uses darksky api and skycons for the weather info.
You should provide your own darksky api key in order to make the weather work.
