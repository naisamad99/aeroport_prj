<?php

class VolModel {
    
    private $data;

    public function __construct() {
        $data = '';
    }

    public function selectFromTables($cols, $tables, $where = '') {
        
        $query = 'SELECT '. implode(',', $cols) .' FROM '. implode(',', $tables) . (empty($where)? '' : ' WHERE ' . $where);
        $params = [];
        $pdo = new DataAccessObject(DSN, DB_USERNAME, DB_PASSWORD);
        $this->data = $pdo->query($query, $params);
        $pdo->close();
        return $this->data;
           
    }
    
    public function selectWithQuery($query) {
        
        $params = [];
        $pdo = new DataAccessObject(DSN, DB_USERNAME, DB_PASSWORD);
        $this->data = $pdo->query($query, $params);
        $pdo->close();
        return $this->data;
    }

    

    public function insert($classObject) {
        
        switch($classObject) {
            
            case $classObject instanceof Compagnie: 
                $table = 'compagnies';
                $fields = ['CompagnieId', 'NomCompagnie', 'LogoUri'];
                $values = [':CompagnieId', ':NomCompagnie', ':LogoUri'];
                $params = [':CompagnieId' => $classObject->getCompagnieId(), ':NomCompagnie' => $classObject->getNomCompagnie(),
                            ':LogoUri' => $classObject->getLogoUri()];
                break;
            
            case $classObject instanceof Aeroport: 
                $table = 'aeroports';
                $fields = ['AeroportId', 'NomAeroport', 'Ville', 'Pays'];
                $values = [':AeroportId', ':NomAeroport', ':Ville', ':Pays'];
                $params = [':AeroportId' => $classObject->getAeroportId(), ':NomAeroport' => $classObject->getNomAeroport(),
                           ':Ville' => $classObject->getVille(), ':Pays' => $classObject->getPays()];
                break;
            
            case $classObject instanceof VolGenerique: 
                $table = 'volgeneriques';
                $fields = ['VolGeneriqueId', 'AeroportId', 'CompagnieId', 'HeurePrevue', 'Direction'];
                $values = [':VolGeneriqueId', ':AeroportId', ':CompagnieId', ':HeurePrevue', ':Direction'];
                $params = [':VolGeneriqueId' => $classObject->getVolGeneriqueId(), ':AeroportId' => $classObject->getAeroportId(), 
                            ':CompagnieId' => $classObject->getCompagnieId(), ':HeurePrevue' => $classObject->getHeurePrevue(), 
                            ':Direction' => $classObject->getDirection()];
                break;
            
            case $classObject instanceof VolCedule: 
                $table = 'volcedules';
                $fields = ['VolCeduleId', 'VolGeneriqueId', 'DatePrevue', 'DateRevisee', 'Statut', 'Porte'];
                $values = [':VolCeduleId', ':VolGeneriqueId', ':DatePrevue', ':DateRevisee', ':Statut', ':Porte'];
                $params = [':VolCeduleId' => $classObject->getVolCeduleId(), ':VolGeneriqueId' => $classObject->getVolGeneriqueId(), ':DatePrevue' => $classObject->getDatePrevue(), 
                            ':DateRevisee' => $classObject->getDateRevisee(), ':Statut' => $classObject->getStatut(), 
                            ':Porte' => $classObject->getPorte()];
                break;
            
            case $classObject instanceof Notification: 
                $table = 'notifications';
                $fields = ['VolCeduleId', 'NumTel', 'DateInscription', 'DateArret'];
                $values = [':VolCeduleId', ':NumTel', ':DateInscription', ':DateArret'];
                $params = [':VolCeduleId' => $classObject->getVolCeduleId(), ':NumTel' => $classObject->getNumTel(), 
                            ':DateInscription' => $classObject->getDateInscription(), ':DateArret' => $classObject->getDateArret()];
                break;
            
        
        }
        
        $query = 'INSERT INTO '. $table . '(' . implode(',', $fields) . ') VALUES(' . implode(',', $values) . ')'; //return $query;
        $pdo = new DataAccessObject2(DSN, DB_USERNAME, DB_PASSWORD);
        $this->data = $pdo->query($query, $params);
        $pdo->close();
        return $this->data;
    }
    
}
