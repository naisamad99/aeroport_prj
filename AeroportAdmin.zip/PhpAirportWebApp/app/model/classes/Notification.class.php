<?php

class Notification {
    
    private $VolCeduleId;
    private $NumTel;
    private $DateInscription;
    private $DateArret;
    
    function __construct($VolCeduleId, $NumTel, $DateInscription, $DateArret) {
        $this->VolCeduleId = $VolCeduleId;
        $this->NumTel = $NumTel;
        $this->DateInscription = $DateInscription;
        $this->DateArret = $DateArret;
    }

    function getVolCeduleId() {
        return $this->VolCeduleId;
    }

    function getNumTel() {
        return $this->NumTel;
    }

    function getDateInscription() {
        return $this->DateInscription;
    }

    function getDateArret() {
        return $this->DateArret;
    }

    function setVolCeduleId($VolCeduleId) {
        $this->VolCeduleId = $VolCeduleId;
    }

    function setNumTel($NumTel) {
        $this->NumTel = $NumTel;
    }

    function setDateInscription($DateInscription) {
        $this->DateInscription = $DateInscription;
    }

    function setDateArret($DateArret) {
        $this->DateArret = $DateArret;
    }


}
