<?php

class Aeroport {
    
    private $AeroportId;
    private $NomAeroport;
    private $Ville;
    private $Pays;
    
    function __construct($AeroportId, $NomAeroport, $Ville, $Pays) {
        $this->AeroportId = $AeroportId;
        $this->NomAeroport = $NomAeroport;
        $this->Ville = $Ville;
        $this->Pays = $Pays;
    }
    function getAeroportId() {
        return $this->AeroportId;
    }

    function getNomAeroport() {
        return $this->NomAeroport;
    }

    function getVille() {
        return $this->Ville;
    }

    function getPays() {
        return $this->Pays;
    }

    function setAeroportId($AeroportId) {
        $this->AeroportId = $AeroportId;
    }

    function setNomAeroport($NomAeroport) {
        $this->NomAeroport = $NomAeroport;
    }

    function setVille($Ville) {
        $this->Ville = $Ville;
    }

    function setPays($Pays) {
        $this->Pays = $Pays;
    }



}
