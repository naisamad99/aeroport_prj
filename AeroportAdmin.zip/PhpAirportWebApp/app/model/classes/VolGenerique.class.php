<?php

class VolGenerique {
    
    private $VolGeneriqueId; 
    private $AeroportId; 
    private $CompagnieId; 
    private $HeurePrevue; 
    private $Direction;
    
    function __construct($VolGeneriqueId, $AeroportId, $CompagnieId, $HeurePrevue, $Direction) {
        $this->VolGeneriqueId = $VolGeneriqueId;
        $this->AeroportId = $AeroportId;
        $this->CompagnieId = $CompagnieId;
        $this->HeurePrevue = $HeurePrevue;
        $this->Direction = $Direction;
    }

    function getVolGeneriqueId() {
        return $this->VolGeneriqueId;
    }

    function getAeroportId() {
        return $this->AeroportId;
    }

    function getCompagnieId() {
        return $this->CompagnieId;
    }

    function getHeurePrevue() {
        return $this->HeurePrevue;
    }

    function getDirection() {
        return $this->Direction;
    }

    function setVolGeneriqueId($VolGeneriqueId) {
        $this->VolGeneriqueId = $VolGeneriqueId;
    }

    function setAeroportId($AeroportId) {
        $this->AeroportId = $AeroportId;
    }

    function setCompagnieId($CompagnieId) {
        $this->CompagnieId = $CompagnieId;
    }

    function setHeurePrevue($HeurePrevue) {
        $this->HeurePrevue = $HeurePrevue;
    }

    function setDirection($Direction) {
        $this->Direction = $Direction;
    }


}
