<?php

class VolCedule {
    
    private $VolCeduleId; 
    private $VolGeneriqueId; 
    private $DatePrevue; 
    private $DateRevisee; 
    private $Statut;
    private $Porte;
    
   function __construct($VolCeduleId, $VolGeneriqueId, $DatePrevue, $DateRevisee, $Statut, $Porte) {
        $this->VolCeduleId = $VolCeduleId;
        $this->VolGeneriqueId = $VolGeneriqueId;
        $this->DatePrevue = $DatePrevue;
        $this->DateRevisee = $DateRevisee;
        $this->Statut = $Statut;
        $this->Porte = $Porte;
    }
//    
//   function __construct($VolGeneriqueId, $DatePrevue, $DateRevisee, $Statut, $Porte) {
//        $this->VolCeduleId = 0;
//        $this->VolGeneriqueId = $VolGeneriqueId;
//        $this->DatePrevue = $DatePrevue;
//        $this->DateRevisee = $DateRevisee;
//        $this->Statut = $Statut;
//        $this->Porte = $Porte;
//    }

    function getVolCeduleId() {
        return $this->VolCeduleId;
    }

    function getVolGeneriqueId() {
        return $this->VolGeneriqueId;
    }

    function getDatePrevue() {
        return $this->DatePrevue;
    }

    function getDateRevisee() {
        return $this->DateRevisee;
    }

    function getStatut() {
        return $this->Statut;
    }

    function getPorte() {
        return $this->Porte;
    }

    function setVolCeduleId($VolCeduleId) {
        $this->VolCeduleId = $VolCeduleId;
    }

    function setVolGeneriqueId($VolGeneriqueId) {
        $this->VolGeneriqueId = $VolGeneriqueId;
    }

    function setDatePrevue($DatePrevue) {
        $this->DatePrevue = $DatePrevue;
    }

    function setDateRevisee($DateRevisee) {
        $this->DateRevisee = $DateRevisee;
    }

    function setStatut($Statut) {
        $this->Statut = $Statut;
    }

    function setPorte($Porte) {
        $this->Porte = $Porte;
    }


}
