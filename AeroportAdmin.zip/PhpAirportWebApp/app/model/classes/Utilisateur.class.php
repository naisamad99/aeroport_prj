<?php


class Utilisateur {
    
    private $NomUtilisateur;
    private $MotDePassse;
    private $Role;
    
    function __construct($NomUtilisateur, $MotDePassse, $Role) {
        $this->NomUtilisateur = $NomUtilisateur;
        $this->MotDePassse = $MotDePassse;
        $this->Role = $Role;
    }

    function getNomUtilisateur() {
        return $this->NomUtilisateur;
    }

    function getMotDePassse() {
        return $this->MotDePassse;
    }

    function getRole() {
        return $this->Role;
    }

    function setNomUtilisateur($NomUtilisateur) {
        $this->NomUtilisateur = $NomUtilisateur;
    }

    function setMotDePassse($MotDePassse) {
        $this->MotDePassse = $MotDePassse;
    }

    function setRole($Role) {
        $this->Role = $Role;
    }


    
}
