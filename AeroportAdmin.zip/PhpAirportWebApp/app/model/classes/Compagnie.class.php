<?php

class Compagnie {
    
    private $CompagnieId;
    private $NomCompagnie;
    private $LogoUri;
    
    function __construct($CompagnieId, $NomCompagnie, $LogoUri) {
        $this->CompagnieId = $CompagnieId;
        $this->NomCompagnie = $NomCompagnie;
        $this->LogoUri = $LogoUri;
    }
    function getCompagnieId() {
        return $this->CompagnieId;
    }

    function getNomCompagnie() {
        return $this->NomCompagnie;
    }

    function getLogoUri() {
        return $this->LogoUri;
    }

    function setCompagnieId($CompagnieId) {
        $this->CompagnieId = $CompagnieId;
    }

    function setNomCompagnie($NomCompagnie) {
        $this->NomCompagnie = $NomCompagnie;
    }

    function setLogoUri($LogoUri) {
        $this->LogoUri = $LogoUri;
    }


    
}
