<?php

class UtilisateurModel {

    public $utilisateurs = null;

    function __construct() {
        $this->utilisateurs = [];
    }

    public function selectAll() {

        $query = 'SELECT * FROM utilisateurs';
        $params = [];
        $pdo = new DataAccessObject(DSN, DB_USERNAME, DB_PASSWORD);
        $this->utilisateurs = $pdo->query($query, $params);
        $pdo->close();
        return $this->utilisateurs;
    }

    public function select($NomUtilisateur, $MotDePasse) {

        $query = 'SELECT * FROM utilisateurs WHERE NomUtilisateur = :NomUtilisateur AND MotDePasse = :MotDePasse';
        $params = [':NomUtilisateur' => $NomUtilisateur, ':MotDePasse' => $MotDePasse];
        
        $pdo = new DataAccessObject(DSN, DB_USERNAME, DB_PASSWORD);
        $this->utilisateurs = $pdo->query($query, $params);
        $pdo->close();


        return $this->utilisateurs;
    }

    public function insert(Utilisateur $utilisateur) {
        $fields = ['NomUtilisateur', 'MotDePasse', 'role'];
        $values = [':NomUtilisateur', ':email', ':MotDePasse', ':role'];
        $query = 'INSERT INTO utilisateurs(' . implode(',', $fields) . ' ) VALUES(' . implode(',', $values) . ')';
        $params = [':NomUtilisateur' => $utilisateur->getUtilisateurname(), ':MotDePasse' => $utilisateur->getPassword(), ':role' => $utilisateur->getRole()];
        $pdo = new DataAccessObject(DSN, DB_USERNAME, DB_PASSWORD);
        $this->utilisateurs = $pdo->query($query, $params);
        $pdo->close();
        
        return $this->utilisateurs;
    }
    
}
