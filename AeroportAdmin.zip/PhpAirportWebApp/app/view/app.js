'use strict';
//console.log('Runtime 99');

const requires = ['ui.router'];
const app = angular.module('ebuyApp', requires);

app.config(['$stateProvider', '$urlRouterProvider', function ($stateProvider, $urlRouterProvider) {
        $stateProvider
                .state('home', {
                    url: '/home',
                    template: '../app/view/home/home.html',
                    //controller: 'adminController'
                })
                .state('statistics', {
                    url: '/statistics',
                    template: '../app/view/statistics/statistics.html',
                    controller: 'statisticsController'
                })
                .state('settings', {
                    url: '/settings',
                    template: '../app/view/settings/settings.html',
                    controller: 'settingsController'
                })
                
                .state('help', {
                    url: '/help',
                    template: '../app/view/help/help.html'
                });
        $urlRouterProvider.otherwise('help');
    }]);

//app.service('databaseService', ['$http', '$log', '$timeout', DatabaseSevice]);

//app.controller('adminController', ['$scope', '$http', '$log', '$timeout', 'databaseService', AdminController]);

app.controller('statisticsController', function($scope){
    $scope.stats = '';
});

app.controller('settingsController', function($scope){
    $scope.settings = '';
});

//app.controller('loginController', LoginController);

app.controller('footerController', function($scope){
    $scope.currentYear = new Date().getFullYear();
});


function isEmpty(obj) {
    for (var prop in obj) {
        if (obj.hasOwnProperty(prop))
            return false;
    }
    return true
}


