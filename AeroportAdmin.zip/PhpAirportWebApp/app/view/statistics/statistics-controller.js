console.log('Loading of StatisticsController...');

function StatisticsController($scope, $http, $log) {

    // initialization
    $scope.initialization = function () {        
    }
    
    // Methods
        
    
    // Starting Initialization
    $scope.initialization();

}

