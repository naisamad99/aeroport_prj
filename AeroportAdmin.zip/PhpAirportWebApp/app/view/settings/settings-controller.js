console.log('Loading of SettingsController...');

function SettingsController($scope, $http, $log) {

    // initialization
    $scope.initialization = function () {        
    }
    
    // Methods
        
    
    // Starting Initialization
    $scope.initialization();

}

