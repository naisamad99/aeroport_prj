// Classes

// A I R P O R T
function Aeroport(AeroportId, NomAeroport, Ville, Pays) {
    
    this.AeroportId = AeroportId;
    this.NomAeroport = NomAeroport;
    this.Ville = Ville;
    this.Pays = Pays;
    this.toString = function(){
        return '[' + this.AeroportId + ', ' + this.NomAeroport+ ', ' + this.Ville  + ', ' + this.Pays + ']';
    }
}

// C O M P A G N I E

function Compagnie(CompagnieId, NomCompagnie, LogoUri) {
    this.CompagnieId = CompagnieId;
    this.NomCompagnie = NomCompagnie;
    this.LogoUri = LogoUri;
}

// V O L G E N  E R I Q U E

function VolGenerique(VolGeneriqueId, AeroportId, CompagnieId, HeurePrevue, Direction) {
     this.VolGeneriqueId = VolGeneriqueId;
     this.AeroportId = AeroportId;
     this.CompagnieId = CompagnieId;
     this.HeurePrevue = HeurePrevue;
     this.Direction = Direction;
}

// V O L C E D U L E

function VolCedule(VolCeduleId, VolGeneriqueId, DatePrevue, DateRevisee, Statut, Porte) {
    this.VolCeduleId = VolCeduleId;
    this.VolGeneriqueId = VolGeneriqueId;
    this.DatePrevue = DatePrevue;
    this.DateRevisee = DateRevisee;
    this.Statut = Statut;
    this.Porte = Porte;
}




//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


function Country(iso_alpha2_code, name) {
    this.iso_alpha2_code = iso_alpha2_code;
    this.name = name;
    
    
    this.getIsoCode = function(){
        return this.id;
    }
    this.getName = function(){
        return this.nme;
    }
    this.toString = function(){
        return '[' + this.iso_alpha2_code + ', ' + this.name + ']';
    }
}


function City(id, name, state, country_id) {
    this.id = id;
    this.name = name;
    this.state = state;
    this.country_id = country_id;
    
    this.getId = function(){
        return this.id;
    }
    this.getName = function(){
        return this.nme;
    }
    this.getState = function(){
        return this.state;
    }
    this.getCountryId = function(){
        return this.id;
    }
    this.setId = function(id){
        this.id = id;
    }   
    this.toString = function(){
        return '[' + this.id + ', ' + this.name+ ', ' + this.state  + ', ' + this.country_id + ']';
    }
   
}

// A I R P O R T
function Airport(iata, name, city_id, url_logo) {
    
    this.name = name;
    this.iata = iata;
    this.city_id = city_id;
    this.url_logo = url_logo;
    
    this.getName = function() {
        return this.name;
    }

    this.getIata = function() {
        return this.iata;
    }

    this.getCityId = function() {
        return this.city_id;
    }

    this.getUrlLogo = function() {
        return this.url_logo;
    }

    this.setName = function(name) {
        this.name = name;
    }

    this.setIata = function(iata) {
        this.iata = iata;
    }

    this.setCityId = function(city_id) {
        this.city_id = city_id;
    }

    this.setUrlLogo = function(url_logo) {
        this.url_logo = url_logo;
    }
    this.toString = function(){
        return '[' + this.iata + ', ' + this.name+ ', ' + this.city_id  + ', ' + this.url_logo + ']';
    }

}

// A I R L I N E
function Airline(iata, name, oaci, country_iso_code, url_icon) {
    
    this.init = function(){
        this.iata = iata;
        this.name = name;
        this.oaci = oaci;
        this.country_iso_code = country_iso_code;
        this.url_icon = url_icon;
    }

    this.getName = function() {
        return this.name;
    }

    this.getIata = function() {
        return this.iata;
    }

    this.getOaci = function() {
        return this.oaci;
    }

    this.getCountryIsoCode = function() {
        return this.country_iso_code;
    }

    this.getUrlIcon = function() {
        return this.url_icon;
    }

    this.setName = function(name) {
        this.name = name;
    }

    this.setIata = function(iata) {
        this.iata = iata;
    }

    this.setOaci = function(oaci) {
        this.oaci = oaci;
    }

    this.setCountryIsoCode = function(country_iso_code) {
        this.country_iso_code = country_iso_code;
    }

    this.setUrlIcon = function(url_icon) {
        this.url_icon = url_icon;
    }
    this.toString = function(){
        return '[' + this.iata + ', ' + this.name+ ', ' + this.oaci  + ', ' + this.country_iso_code  + ', ' + this.url_icon + ']';
    }

    // Initialization
    this.init();

}

// F L I G H T - R E F
function FlightReference(flightnumber, airline_iata, airport_iata, direction, time) {
    
    this.init = function(){
        this.flightnumber = flightnumber;
        this.airline_iata = airline_iata;
        this.airport_iata = airport_iata;
        this.direction = direction;
        this.time = time;
    }
    
    this.getFlightNumber = function() {
        return this.flightnumber;
    }

    this.getAirlineIata = function() {
        return this.airline_iata;
    }

    this.getAirportIata = function() {
        return this.airport_iata;
    }

    this.getDirection = function() {
        return this.direction;
    }

    this.getTime = function() {
        return this.time;
    }

    this.setFlightNumber = function(flightnumber) {
        this.flightnumber = flightnumber;
    }

    this.setAirlineIata = function(airline_iata) {
        this.airline_iata = airline_iata;
    }

    this.setAirportIata = function(airport_iata) {
        this.airport_iata = airport_iata;
    }

    this.setDirection = function(direction) {
        this.direction = direction;
    }

    this.setTime = function(time) {
        this.time = time;
    }
    this.toString = function(){
        return '[' + this.flightnumber + ', ' + this.airline_iata+ ', ' + this.airport_iata  + ', ' + this.direction  + ', ' + this.time + ']';
    }
 
    // Initialization
    this.init();
    
    
}    


// F L I G H T
function Flight(flightref_number, scheduled_time, estimated_time, status, terminal, gate) {
    
    this.init = function(){
        this.id = -1;
        this.flightref_number = flightref_number;
        this.scheduled_time = scheduled_time;
        this.estimated_time = estimated_time;
        this.status = status;
        this.terminal = terminal;
        this.gate = gate;
    }

    this.getId = function() {
        return this.id;
    }

    this.getFlightReferenceNumber = function() {
        return this.flightref_number;
    }

    this.getScheduledTime = function() {
        return this.scheduled_time;
    }

    this.getEstimatedTime = function() {
        return this.estimated_time;
    }

    this.getStatus = function() {
        return this.status;
    }

    this.getTerminal = function() {
        return this.terminal;
    }

    this.getGate = function() {
        return this.gate;
    }

    this.setId = function(id) {
        this.id = id;
    }

    this.setFlightReferenceNumber = function(flightref_number) {
        this.flightref_number = flightref_number;
    }

    this.setScheduledTime = function(scheduled_time) {
        this.scheduled_time = scheduled_time;
    }

    this.setEstimatedTime = function(estimated_time) {
        this.estimated_time = estimated_time;
    }

    this.setStatus = function(status) {
        this.status = status;
    }

    this.setTerminal = function(terminal) {
        this.terminal = terminal;
    }

    this.setGate = function(gate) {
        this.gate = gate;
    }
    this.toString = function(){
        return '[' + this.flightref_number + ', ' + this.scheduled_time+ ', ' + this.estimated_time  + ', ' + this.status  + 
                ', ' + this.terminal  + ', ' + this.gate + ']';
    }
               
    // Initialization
    this.init();

    
}
