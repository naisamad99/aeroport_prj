function DatabaseSevice($http, $log, $timeout){
    $log.log('Loading DatabaseService ...');
    
    var country_table_loaded, city_table_loaded, airport_table_loaded, airline_table_loaded, flightref_table_loaded, flight_table_loaded;
    var aeroports_table_loaded, compagnies_table_loaded;
    var tablenames = [];
    
    this.init = function(){
        this.record_number = 0;
        this.tables_loaded = false;
        this.showLoadingWaitingMessage = false;
        this.tables_loaded_ratio = 0;
        this.recordingProgress = new CircularProgressObject(document.getElementById("record-progress-canvas"), 100, 100, 65);
        this.recordingtobd_result = '';
        flightref_table_loaded = flight_table_loaded = false;
        country_table_loaded = city_table_loaded = airport_table_loaded = airline_table_loaded = false;
        aeroports_table_loaded = compagnies_table_loaded = false;
        this.getCountries();
        this.getAirlines();
        this.getAirports();
        this.getCities();
        this.getFlightRefs();
        this.getFlights();
    }
    
    this.loadFlightCalendar = function(ret){
        $log.log('<>>>>>>> loadFlightCalendar ...');
        tablenames.push('volcedules');
        tablenames.push('volgeneriques');
        if (this.compagnies_table_required) tablenames.push('compagnies');
        if (this.aeroports_table_required) tablenames.push('aeroports'); 
        //tablenames.push('testtables');tablenames.push('testtables');
        $log.log('Table list to update: ' + tablenames.join());
        document.getElementById("load-process-content").innerHTML = '';
        this.recordingtobd_result = '<h2 style="font-size:15px;font-weight:bold;background-color:cornflowerblue;padding:4px;">Rapport du chargement:</h2><ul>';
        this.showLoadingWaitingMessage = true;
        this.postData(tablenames.length - 1);
    }
    this.postData = function(level){
        var self = this;
        $log.log('Iteration : ' + level);
        var tablename = tablenames[level--];
        var postData = null;
        switch(tablename) {
            case 'aeroports':  postData = 'aeroports=' + JSON.stringify(self.getAeroportsToTransfer()); break;
            case 'compagnies': postData = 'compagnies=' + JSON.stringify(self.getCompagniesToTransfer()); break;
            case 'volgeneriques': postData = 'volgeneriques=' + JSON.stringify(self.getVolGeneriquesToTransfer()); break;
            case 'volcedules': postData = 'volcedules=' + JSON.stringify(self.getVolCedulesToTransfer()); break;
            case 'testtables': var v = 10; postData = 'testtables=' + JSON.stringify(v); break;    
        }
        if (postData === null) {
            $log.log('[Warning] Unknow table name. ');
            return;
        }
        $http({
                method : 'POST',
                url : './flight/recordtodb/' + tablename,
                data: postData,
                headers : {'Content-Type': 'application/x-www-form-urlencoded'}  
            })
            .then(function(response){
                $log.log(tablename + ' record request status: ' + response.status);
                self.recordingtobd_result += response.data;
                var ratio = self.recordingProgress.ratio + 100/tablenames.length; $log.log('Ratioooooooooooo: '+ ratio);
                for (var i = self.recordingProgress.ratio; i < ratio; i++){
                    $timeout(function () {self.recordingProgress.setRatio(i+1); }, 1500);
                }
                if (level >= 0) self.postData(level);
                else {
                    self.recordingtobd_result += '</ul>'
                    document.getElementById("load-process-content").innerHTML = response.data;
                    $timeout(function () {self.showLoadingWaitingMessage = false;}, 4000);
                    $log.log('End of transfert');
                }
                
            }, function(response){
                $log.log(tablename + ' record request status: ' + response.status);
                self.recordingtobd_result += response.data + '</ul>';
                document.getElementById("load-process-content").innerHTML = response.data;
                $timeout(function () {self.showLoadingWaitingMessage = false;}, 4000);
                $log.log('End of transfert');
                
            });
        
    }
    
    
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    
    this.setTablesLoaded = function(){
        var self = this;
        self.tables_loaded_ratio += 12.5;
        if (this.tables_loaded_ratio == 100) {
            $timeout(function(){self.tables_loaded = country_table_loaded && city_table_loaded && airport_table_loaded && 
                             airline_table_loaded && flightref_table_loaded && flight_table_loaded &&
                             aeroports_table_loaded && compagnies_table_loaded; }, 4000);
            
        }
        else {
           self.tables_loaded = country_table_loaded && city_table_loaded && airport_table_loaded && 
                             airline_table_loaded && flightref_table_loaded && flight_table_loaded &&
                             aeroports_table_loaded && compagnies_table_loaded; 
        }    
        
        
    }
    
    this.getAeroportsSize = function(){
        var self = this;
        self.aeroports_table_required = true;
        $http({method: 'GET', url: './flight/chargertable/aeroports'})
             .then(function(response){
                aeroports_table_loaded = true; self.setTablesLoaded();
                if (self.airports.length <= parseInt(response.data)) self.aeroports_table_required = false;
                else self.record_number += self.airports.length;
                $log.log('[Informa] Table aeroports chargee, taille: ' + response.data + ', required: ' + self.aeroports_table_required);
                $log.log('Record_number: ' + self.record_number);
             }, function(response){
                 $log.log('[Warning] Table aeroports non chargee: ' + response.status);
                 $log.log('Record_number: ' + self.record_number);
             }
        );
    }
    this.getCompagniesSize = function(){
        var self = this;
        self.compagnies_table_required = true;
        $http({method: 'GET', url: './flight/chargertable/compagnies'})
             .then(function(response){
                compagnies_table_loaded = true; self.setTablesLoaded(); 
                if (self.airlines.length <= parseInt(response.data)) self.compagnies_table_required = false;
                else self.record_number += self.airlines.length;
                $log.log('[Informa] Table compagnies chargee, taille: ' + response.data + ', required: ' + self.compagnies_table_required);
                $log.log('Record_number: ' + self.record_number);
                }, function(response){
                 $log.log('[Warning] Table compagnies non chargee: ' + response.status);
                 $log.log('Record_number: ' + self.record_number);
             }
        );
    }
    this.getAeroportsToTransfer = function(){
        $log.log('Loading getAeroportsToTransfer ...');
        var aeroports = [];
        var airportlength = this.airports.length;
        var citylength = this.cities.length;
        for (var i = 0; i < airportlength; i++){
            var cityname = '', countryname = '', state;
            for (var j = 0; j < citylength; j++){
                if (this.airports[i].city_id == this.cities[j].id){
                   if (this.cities[j].country_iso_code != '') countryname  = this.getCountryName(this.cities[j].country_iso_code); 
                   if (this.cities[j].name != '') { 
                       state = this.cities[j].state;
                       if (state != '') state = ', ' + state;
                       cityname  = this.cities[j].name + state; 
                   }
                   break;
                }
            }
            //new Aeroport(AeroportId, NomAeroport, Ville, Pays)
            var aeroport = new Aeroport(this.airports[i].iata, this.airports[i].name, cityname, countryname); 
            aeroports.push(aeroport);
        }
        $log.log('Aeroports size: ' + aeroports.length + '\n');
        return aeroports;
    }
    this.getCompagniesToTransfer = function(){
        $log.log('Loading getCompagniesToTransfer ...');
        var compagnies = [];
        var airlinelength = this.airlines.length;
        for (var i = 0; i < airlinelength; i++){
            //new Compagnie(CompagnieId, NomCompagnie, LogoUri)
            var compagnie = new Compagnie(this.airlines[i].iata, this.airlines[i].name, this.airlines[i].url_icon); 
            compagnies.push(compagnie);
        }
        $log.log('Compagnies size: ' + compagnies.length + '\n');
        //this.ImprimerCompagnies(compagnies);
        return compagnies;
    }
    this.ImprimerCompagnies = function(compagnies){
        var compagnielength = compagnies.length;
        var out = 'Compagnies:\n';
        for (var i = 0; i < compagnielength; i++){
            out += '[' + compagnies[i].CompagnieId + ', ' + compagnies[i].NomCompagnie + ', ' + compagnies[i].LogoUri + ']\n';
        }
        $log.log(out);
    }
    this.getVolGeneriquesToTransfer = function(){
        $log.log('Loading getVolGeneriqueToTransfer ...');
        var volgeneriques = [];
        var flightrefslength = this.flightrefs.length;
        for (var i = 0; i < flightrefslength; i++){
            //new VolGenerique(VolGeneriqueId, AeroportId, CompagnieId, HeurePrevue, Direction)
            var volgenerique = new VolGenerique(this.flightrefs[i].flightnumber, this.flightrefs[i].airport_iata, this.flightrefs[i].airline_iata, 
                                                this.flightrefs[i].time, this.flightrefs[i].direction); 
            volgeneriques.push(volgenerique);
        }
        $log.log('VolGeneriques size: ' + volgeneriques.length + '\n');
        //this.ImprimerVolGeneriques(volgeneriques);
        return volgeneriques;
    }
    
    this.ImprimerVolGeneriques = function(volgeneriques){
        var volgeneriquelength = volgeneriques.length; 
        var out = 'VolGeneriques:\n';
        for (var i = 0; i < volgeneriquelength; i++){
            out += '[' + volgeneriques[i].VolGeneriqueId + ', ' + volgeneriques[i].AeroportId + ', ' + volgeneriques[i].CompagnieId + ', ' + 
                        volgeneriques[i].HeurePrevue + ', ' + volgeneriques[i].Direction + ']\n';
        }
        $log.log(out);
        
    }
    this.getVolCedulesToTransfer = function(){
        $log.log('Loading getVolCeduleToTransfer ...');
        var volcedules = [];
        var flightlength = this.flights.length;
        for (var i = 0; i < flightlength; i++){
            //new  VolCedule(VolCeduleId, VolGeneriqueId, DatePrevue, DateRevisee, Statut, Porte)
            var volcedule = new VolCedule(this.flights[i].id, this.flights[i].flightref_number, this.flights[i].scheduled_time, 
                                          this.flights[i].estimated_time, this.flights[i].status, 
                                          this.flights[i].terminal + this.flights[i].gate); 
            volcedules.push(volcedule);
        }
        $log.log('VolCedules size: ' + volcedules.length + '\n');
        return volcedules;
    }
    this.ImprimerVolCedules = function(volcedules){
        var volcedulelength = volcedules.length; 
        var out = 'VolCedules:\n';
        for (var i = 0; i < volcedulelength; i++){
            out += '[' + volcedules[i].VolCeduleId + ', ' + volcedules[i].VolGeneriqueId + ', ' + volcedules[i].DatePrevue + ', ' + 
                        volcedules[i].DateRevisee + ', ' + volcedules[i].Statut + ', ' + volcedules[i].Porte + ']\n';
        }
        $log.log(out);
    }
    
    //===================================================================================================================================
    //-------------------------------------------------------------------------------------------------------------------> C O U N T R Y
    //===================================================================================================================================
    //Country(iso_alpha2_code, name) 
    this.getCountries = function(){
       var self = this;
       self.countries = [];
       $http({method: 'GET', url: './flight/loadtable/countries'})
            .then(function(response){
                self.countries = response.data;
                country_table_loaded = true; self.setTablesLoaded();
                $log.log('[Informa] Table countries loaded, size: ' + self.countries.length);
                
            }, function(response){
                $log.log('[Warning] Table countries not loaded: ' + response.status);
            }
        );
    }
    this.getCountryName = function(iso_code) {
        var len = this.countries.length;
        for (var i = 0; i < len; i++){
            if (this.countries[i].iso_alpha2_code == iso_code) return this.countries[i].name;
        }
        return '';
        
    }
    this.printCountries = function(nbr){
        var len = this.countries.length;
        if (len > nbr) len = nbr;
        $log.log(len + ' Countries');
        var out = '';
        for (var i = 0; i < len; i++){
            out += '{' + this.countries[i].iso_alpha2_code + ', ' + this.countries[i].name + '}\n';
            out += country.toString() + '\n';
        }
        $log.log(out);
    }
    
    //===================================================================================================================================
    //-------------------------------------------------------------------------------------------------------------------------> C I T Y
    //===================================================================================================================================
    // City(id, name, state, country_id)
    this.getCities = function(){
       var self = this;
       self.cities = [];
       $http({method: 'GET', url: './flight/loadtable/cities'})
            .then(function(response){
                self.cities = response.data;
                city_table_loaded = true; self.setTablesLoaded();
                $log.log('[Informa] Table cities loaded, size: ' + self.cities.length);
                
            }, function(response){
                $log.log('[Warning] Table cities not loaded: ' + response.status);
            }
        );
    }
    this.printCities = function(){
        var len = this.cities.length;
        $log.log(len +' Cities');
        var out = '';
        for (var i = 0; i < len; i++){
            out += '{'+ this.cities[i].id + ', ' + this.cities[i].name + ', ' + this.cities[i].state + ', ' + this.cities[i].country_id + '}\n';
        }
        $log.log(out);
    }
       
    //===================================================================================================================================
    //-------------------------------------------------------------------------------------------------------------------> A I R P O R T
    //===================================================================================================================================
    // Airport(iata, name, city_id, url_logo)
    this.getAirports = function(){
       var self = this;
       self.airports = [];
       $http({method: 'GET', url: './flight/loadtable/airports'})
            .then(function(response){
                self.airports = response.data;
                airport_table_loaded = true; self.setTablesLoaded();
                $log.log('[Informa] Table airports loaded, size: ' + self.airports.length);
                self.getAeroportsSize(); 
            }, function(response){
                $log.log('[Warning] Table airports not loaded: ' + response.status);
            }
        );
    }
    this.printAirports = function(){
        var len = this.airports.length;
        $log.log(len +' airports');
        var out = '';
        for (var i = 0; i < len; i++){
            out += '{' + this.airports[i].iata  + ', ' + this.airports[i].name  + ', ' + this.airports[i].city_id  + ', ' + 
                          this.airports[i].url_logo + '}\n';
        }
        $log.log(out);
    } 
    
    //===================================================================================================================================
    //-------------------------------------------------------------------------------------------------------------------> A I R L I N E
    //===================================================================================================================================
    // Airline(iata, name, oaci, country_iso_code, url_icon)
    this.getAirlines = function(){
       var self = this;
       self.airlines = [];
       $http({method: 'GET', url: './flight/loadtable/airlines'})
            .then(function(response){
                self.airlines = response.data;
                airline_table_loaded = true; self.setTablesLoaded();
                $log.log('[Informa] Table airlines loaded, size: ' + self.airlines.length);
                self.getCompagniesSize();
            }, function(response){
                $log.log('[Warning] Table airlines not loaded: ' + response.status);
            }
        );
    }
    this.printAirlines = function(){
        var len = this.airlines.length;
        $log.log(len +' airlines');
        var out = '';
        for (var i = 0; i < len; i++){
            out += '{' + this.airlines[i].iata  + ', ' + this.airlines[i].name  + ', ' + this.airlines[i].oaci  + ', ' +   
                                    this.airlines[i].country_iso_code  + ', ' + this.airlines[i].url_icon + '}\n';
        }
        $log.log(out);
    } 
     
    //===================================================================================================================================
    //-----------------------------------------------------------------------------------------------------> F L G H T R E F E R E N C E
    //===================================================================================================================================
    // FlightReference(flightnumber, airline_iata, airport_iata, direction, time)
    this.getFlightRefs = function(){
       var self = this;
       self.flightrefs = [];
       $http({method: 'GET', url: './flight/loadtable/flightrefs'})
            .then(function(response){
                self.flightrefs = response.data;
                //self.printFlightRefs();
                flightref_table_loaded = true; self.setTablesLoaded();
                self.record_number += self.flightrefs.length;
                $log.log('[Informa] Table flightrefs loaded, size: ' + self.flightrefs.length);
                
            }, function(response){
                $log.log('[Warning] Table flightrefs not loaded: ' + response.status);
            }
        );
    }
    this.printFlightRefs = function(){
        var len = this.flightrefs.length;
        $log.log(len +' flightrefs');
        var out = '';
        for (var i = 0; i < len; i++){
            out += '{' + this.flightrefs[i].flightnumber + ', ' + this.flightrefs[i].airline_iata+ ', ' + 
                    this.flightrefs[i].airport_iata  + ', ' + this.flightrefs[i].direction  + ', ' + this.flightrefs[i].time + '}\n';
        }
        $log.log(out);
    } 
    
    //===================================================================================================================================
    //-----------------------------------------------------------------------------------------------------------------------> F L G H T
    //===================================================================================================================================
    // Flight(flightref_number, scheduled_time, estimated_time, status, terminal, gate)
    
    this.getFlights = function(){
       var self = this;
       self.flights = [];
       $http({method: 'GET', url: './flight/loadtable/flights'})
            .then(function(response){
                self.flights = response.data;
                //self.printFlights();
                flight_table_loaded = true; self.setTablesLoaded();
                self.record_number += self.flights.length;
                $log.log('[Informa] Table flights loaded, size: ' + self.flights.length);
                
            }, function(response){
                $log.log('[Warning] Table flights not loaded: ' + response.status);
            }
        );
    }
    this.printFlights = function(nbr){
        var len = this.flights.length;
        if (len > nbr) len = nbr;
        $log.log(len +' flights');
        var out = '';
        for (var i = 0; i < len; i++){
            out += '{' + this.flights[i].id + ', '  + this.flights[i].flightref_number + ', ' + this.flights[i].scheduled_time+ ', ' + 
                    this.flights[i].estimated_time  + ', ' + this.flights[i].status  + ', ' + this.flights[i].terminal  + ', ' + this.flights[i].gate + '}\n';
        }
        $log.log(out);
    }  
     
    //Initialization
    this.init();
}

function CircularProgressObject(canvas, x, y, radius){
    const CounterClockwise = false;
    const StartAngle = 1.5 * Math.PI;
    const EndAngle = 3.5 * Math.PI;
    
    this.init = function(){
        this.canvas = canvas;
        this.x = x;
        this.y = y;
        this.radius = radius;
        this.refreshDrawing(EndAngle, 15, 'red');
        this.setRatio(0);
        
    }
    this.setRatio = function(ratio){
        this.ratio = ratio;
        var endAngle = (this.ratio/100 * 2 + 1.5) * Math.PI;
        this.refreshDrawing(endAngle, 19, 'green');
    }
    this.refreshDrawing = function(endAngle, lineWidth, color){
        var ctx = this.canvas.getContext('2d');
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.radius, StartAngle, endAngle, CounterClockwise);
        ctx.lineWidth = lineWidth; // line width;
        ctx.strokeStyle = color; // line color
        ctx.stroke();
    }
    
    
    // Init
    this.init();
}

/*
 <body>
<canvas id="demoCanvas" width="340" height="340"> canvas</canvas> 
<script>
var canvas = document.getElementById('demoCanvas');
var ctx = canvas.getContext('2d');
var x = 90;
var y = 100;
var radius = 55;
//var startAngle = 1.1 * Math.PI;
//var endAngle = 1.9 * Math.PI;
var startAngle = 1.5 * Math.PI;
var endAngle = 3.5 * Math.PI;
var counterClockwise = false;
ctx.beginPath();
ctx.arc(x, y, radius, startAngle, endAngle, counterClockwise);
ctx.lineWidth = 15;
// line color
ctx.strokeStyle = 'red';
ctx.stroke();
////////////////////////////////////////////////////
var ctx1 = canvas.getContext('2d');
var startAngle1 = 1.5 * Math.PI;
var endAngle1 = 2 * Math.PI;
var counterClockwise = false;
ctx1.beginPath();
ctx1.arc(x, y, radius, startAngle1, endAngle1, counterClockwise);
ctx1.lineWidth = 20;
// line color
ctx1.strokeStyle = 'green';
ctx1.stroke();
</script>
</body> 
 */
