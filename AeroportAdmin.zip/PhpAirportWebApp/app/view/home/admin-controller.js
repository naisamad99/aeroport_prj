function AdminController($scope, $http, $log, $timeout, databaseService){
    $log.log('AdminController');
    
    this.init = function(){
        $scope.databaseSevice = databaseService;
        $scope.status_cal = '';
        $scope.content_cal = '';
        $scope.status_prc = '';
        $scope.content_prc = '';
        $scope.showWaitingMessage = false;
        $scope.verif_flight_calendar = 0;
        $scope.updatingProcessAction('status');
    }
    
    $scope.loadFlightCalendar_php = function(){
        $log.log('verifyFileCalendarFile');  
        $scope.showWaitingMessage = true;
        $http({method: 'Get', url : './home/loadFlightCalendar'})
            .then(function(response){
                
                scope.status_cal = 'Status: '+ response.status;
                document.getElementById("load-process-content").innerHTML = response.data;
                $scope.showWaitingMessage = false;
                
            }, function(response){
                $scope.status_cal = 'Status: '+ response.status  + ': Echec';
                $scope.content_cal = response.data;
                $scope.showWaitingMessage = false;
            });    
    }
    
    $scope.loadFlightCalendar_js = function(){
        $scope.status_cal = '';
        $scope.content_cal = '';
        $scope.databaseSevice.loadFlightCalendar();
    }
    
    $scope.verifyFileCalendarFile = function(){
        $log.log('verifyFileCalendarFile'); 
        $scope.status_cal = '';
        $scope.content_cal = '';
        $scope.showWaitingMessage = true;
        $http({method: 'Get', url : './home/verifyFileCalendarFile'})
            .then(function(response){
                for (var i = 0; i < 20; i++){
                    $timeout(function () {
                            $scope.verif_flight_calendar += 5; //$log.log('verif_flight_calendar: ' + $scope.verif_flight_calendar);
                            if ($scope.verif_flight_calendar == 100) {
                                $scope.status_cal = 'Status: '+ response.status;
                                document.getElementById("load-process-content").innerHTML = response.data;
                                $timeout(function () {$scope.showWaitingMessage = false;}, 4000);
                            }
                        }, 3000);
                    
                }
            }, function(response){
                $scope.status_cal = 'Statut: opération échouée, code: '+ response.status;
                $scope.content_cal = response.data;
                $scope.showWaitingMessage = false;
            });   
    }
    
    $scope.updatingProcessAction = function(action){
        $log.log('Action: ' + action);
        if (['enable','disable','run', 'end', 'status'].indexOf(action.toLowerCase()) == -1) return;
        $http({method: 'Get', url : './home/updateprocess/' + action})
            .then(function(response){
                $scope.status_prc = 'Statut: opération réussie, code: '+ response.status;
                $scope.content_prc = response.data;
                $log.log($scope.content_prc);
            }, function(response){
                $scope.status_prc = 'Statut: opération échouée, code: '+ response.status;
                $scope.content_prc = response.data;
                $log.log($scope.status_prc);
                $log.log($scope.content_prc);
            });   
    }
    
    // Init
    this.init();
}

