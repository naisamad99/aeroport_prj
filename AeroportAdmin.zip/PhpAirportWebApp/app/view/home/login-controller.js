console.log('Loading LoginController...')
function LoginController($scope, $http, $location, $log){
    
    $log.log('Using of LoginController');
    
    $scope.initialization = function() {
        $scope.showLoginBox = false;
        $scope.loginIconToolTip = '';
        $scope.username = 'admin1';
        $scope.password = '1234';
        $scope.message = '';
        getSession();
        //$log.log('Session: ' + $scope.session.username);
    }
    
    getSession = function(){
        $scope.session = {username: 'Not logged', role: -1};
        $http({method : 'GET', url : './home/session'})
            .then(function(response){
                $scope.session = response.data;
                $scope.status = response.status;
                $scope.data = response.data;
            }, function(response){
                $scope.status = response.status;
                $scope.data = response.data;
            });
    }
    
    notLogged = function(){
        return ($scope.session.username === 'Not logged' && $scope.session.role ==  -1);
    }
    
    $scope.logInOutRequest = function(){
        if (notLogged()) $scope.showLoginBox = true;
        else {
           $scope.session = {username: 'Not logged', role: -1};
           $http({method : 'GET', url : './home/logout'})
            .then(function(response){
                $scope.session = response.data;
                $location.path('/help');
                $scope.status = response.status;
                $scope.data = response.data;
            }, function(response){
                $scope.status = response.status;
                $scope.data = response.data;
            }); 
        }
    }
    
    $scope.mouseEnterLoginIcon =  function(){
        $log.log('username : ' + $scope.session.username + ', role: ' + ($scope.session.role == -1));
        if (notLogged()) $scope.loginIconToolTip = 'Login';
        else $scope.loginIconToolTip = 'Logout';
        
    }
    
    $scope.mouseLeaveLoginIcon =  function(){ $scope.loginIconToolTip = '';}
    
    
    $scope.submitLogin = function(username, password){
        var formData = { username: username, password: password };
        var postData = 'userData='+JSON.stringify(formData);
        $http({
                method : 'POST',
                url : './home/login',
                data: postData,
                headers : {'Content-Type': 'application/x-www-form-urlencoded'}  

            })
            .then(function(response){
                $scope.status = response.status;
                $scope.data = 'username: '+ response.data.username + ',  role: '+response.data.role;
                if (response.data.username && response.data.role) {
                    $scope.session = response.data;
                    $scope.showLoginBox = false;
                }
                else $scope.message = response.data;
                
                
            }, function(response){
                $scope.status = response.status;
                $scope.data = response.data;
                $scope.showLoginBox = false;
            });
    }
    
    $scope.homeMenuClicked = function(){
        $log.log('current path: ' + $location.path());
    }
    
    $scope.isAdminLogin = function(){
        return ($scope.session.username !== 'Not logged' && $scope.session.role == 127);
    }
    $scope.isUserLogin = function(){
        return ($scope.session.username !== 'Not logged' && $scope.session.role >= 0 )
    }
    
    // Starting the initialization
    $scope.initialization();
}


