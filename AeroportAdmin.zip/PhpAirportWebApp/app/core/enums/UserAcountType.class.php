<?php

// Definition des Enumerations

class UserAcountType extends Enum {
    
    const __Default = self::Users;
    const Users = 0;
    const Operators = 5;
    const Administrators = 9;
    
}

