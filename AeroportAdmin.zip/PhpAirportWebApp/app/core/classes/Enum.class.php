<?php
 abstract class Enum
{
    const __Default = 0; 
    private $index;
    
    final public function __construct($value = null) {
                
        $c = new ReflectionClass($this);
        if (!isset($value) && isset($c->getConstants()[0])) $value = $c->getConstants()[0];
        if(!in_array($value, $c->getConstants())) {
            throw IllegalArgumentException();
        }
        $this->index = $value;
    }

    final public function __toString(){
        
        $c = new ReflectionClass($this);
        $constants = $c->getConstants();
        $constName = null;
        foreach ($constants as $name => $index) {
            if ($index == $this->index && $name != '__Default') {
                $constName = $name;
                break;
            }    
        }
        return $constName;
    }
    
    final public function index() {
        
       return $this->index;
    }
    
    final public function names() {
        $c = new ReflectionClass($this);
        if (isset($c->getConstants()[0])) unset($c->getConstants()[0]);
        return array_slice($c->getConstants(), 1);
    }
}
