<?php

class View {
    
    protected $filename;
    protected $title;
    protected $data;
    
    public function __construct($filename, $data=[], $title = '') {
        
        $this->filename = $filename;
        $this->data = $data;
        $this->title = $title;
        
    }
    
    public function setTitle($title) {
        $this->title = $title;
    }
    
    public function getTitle() {
        return $this->title;
    }
    
    public function render() {
        
        if (file_exists($this->filename)) {
            require $this->filename;
        } else {
            println("<br><hr>Le fichier de vue n'exite pas.<hr>");
            throw new Exception("Le fichier de vue n'exite pas.");
        }
    }
}
