<?php

class Application {

    protected $controller = DEFAULT_CONTROLLER;
    protected $action = DEFAULT_ACTION;
    protected $params = [];

    public function __construct() {

        $this->prepareUrl();

        // Controller a charger : <.CTRL_DIR . $this->controller . CLASS_EXT>
        if (file_exists(CTRL_DIR . $this->controller . CLASS_EXT)) {
            $this->controller = new $this->controller();
            if (method_exists($this->controller, $this->action)) {
                session_start();
                call_user_func_array([$this->controller, $this->action], $this->params);
            } else {
                Message::set('APP001', ': ['.$this->action.']'); Message::display();
            }
        } else {
            Message::set('APP001', ': ['.$this->controller.']'); Message::display();
        }
    }

    private function prepareUrl() {

        if (isset($_SERVER['REQUEST_URI'])) {
            $request_uri = str_replace('//', '/', trim(substr($_SERVER['REQUEST_URI'], strpos($_SERVER['REQUEST_URI'], '/public') + 7), '/'));
            $url = explode('/', $request_uri);
            
            if (count($url) == 1) {
                array_unshift($url,'home');
                $url[1] = explode('.', $url[1])[0];
            }
            if (!empty($url[0])) {
                $this->controller = $url[0] . 'Controller';
            }
            if (!empty($url[1])) {
                $this->action = $url[1];
            }
            unset($url[0], $url[1]);

            /*                 * ******************************************************************
             * ** Il reste a analyser les params pour eliminer les elements nulls.
             * ****************************************************************** */
            if (!empty($url)) {
                $this->params = array_values($url);
            }
           
        }
    }

}
