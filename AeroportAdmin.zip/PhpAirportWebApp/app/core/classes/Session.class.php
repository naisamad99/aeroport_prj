<?php

class Session {
    
    public static function connected() {
        return isset($_SESSION['is_connected']);
    }

    public static function set($username, $accounttype = 255) {
        if (!isset($_SESSION[$username])) {
            $_SESSION['is_connected'] = [$username, $accounttype];
        }
    }
    public static function unSet() {
        if (isset($_SESSION['is_connected'])) {
            unset($_SESSION['is_connected']);
        }
    }
    
    public static function getUserName() {
        if (isset($_SESSION['is_connected'])) {
            return $_SESSION['is_connected'][0];
        } else {
            return 'Not logged';
        }
    }

    public static function getUserType() {
        if (isset($_SESSION['is_connected'])) {
            return $_SESSION['is_connected'][1];
        } else {
            return -1;
        }
    }
    
    public static function getUser() {
        
        return '{"username":"'.Session::getUserName().'", "role":"'.Session::getUserType().'"}';;
        
    }
    

}
