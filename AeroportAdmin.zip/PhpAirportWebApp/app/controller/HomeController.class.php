<?php

class HomeController extends BaseController {
    
    private $host = '127.0.0.1:8181';
    private $taskname = 'FUPDTTASK';

    public function index() {

        $this->ctrl_action = __METHOD__;
        $data = [];

        $this->setView($data, 'Home');
        $this->view->render();
    }

    public function login() {
        $userData = json_decode($_POST['userData']);
        if (isset($userData->username) && isset($userData->password)) {
            $this->model = new UtilisateurModel();
            $data = $this->model->select(sanitize_input($userData->username), sanitize_input($userData->password));

            if (count($data) == 1) {
                Session::set($data[0]->NomUtilisateur, $data[0]->Role);
                echo '{"username":"' . $data[0]->NomUtilisateur . '", "role":"' . $data[0]->Role . '"}';
            } else {

                // Echec d'authentification
                Message::set('DBS002');
                echo Message::get()[0];
            }
        } else {
            Message::set('DBS002');
            echo Message::get()[0];
        }
    }

    public function session() {
        echo Session::getUser();
    }

    public function logout() {
        session_destroy();
        Session::unSet();
        echo Session::getUser();
    }
    
    public function loadtable() {
        
        if (!Session::connected() || Session::getUserType() != 127) {
            Message::set('APP001');
            echo Message::get()[0];
            return;
        }
        $host = 'localhost:8181';
        $url = 'http://' . $host. '/phpControlTowerWebApi/public/flight/jsondata';
        //$url = '../app/ressources/docs/flightcalendar';
        $url_content = file_get_contents($url);
        $json = json_decode($url_content);

        $countries = $json->countries;
        $cities = $json->cities;
        $airports = $json->airports;
        $airlines = $json->airlines;
        $flightreferences = $json->flightreferences;
        $flights = $json->flights;

        $this->model = new VolModel();
        $out = '<h3>Recap:</h3><hr>';
        $count = 0;
        $size = count($airports);
        if ($size < 50){
            foreach ($airports as $airport){
                $city = $this->getCityName($cities, $airport->city_id, $countries);
                $result = $this->model->insert(new Aeroport($airport->iata, $airport->name, $city['name'], $city['country']));
                if ($result['code'] != 0) $count++;
            }
            $count = $size - $count;
            $out .= "<p>Table: Aeroports<br>Nombre d'enregistrements proposés: " . $size . "<br>Nombre d'enregistrements ajoutés dans la table: " . 
                    $count . '</p><br>';
        }
        $count = 0;
        $size = count($airlines);
        if ($size < 50){
            foreach ($airlines as $airline){
                $result = $this->model->insert(new Compagnie($airline->iata, $airline->name, $airline->url_icon));
                if ($result['code'] != 0) $count++;
            }
            $count = $size - $count;
            $out .= "<p>Table: Compagnies<br>Nombre d'enregistrements proposés: " . $size . "<br>Nombre d'enregistrements ajoutés dans la table: " . 
                $count . '</p><br>';
        }
        
        $count = 0;
        foreach ($flightreferences as $flightreference){
            $result = $this->model->insert(new VolGenerique($flightreference->flightnumber, $flightreference->airport_iata,
                        $flightreference->airline_iata, $flightreference->time, $flightreference->direction));
            if ($result['code'] != 0) {
                $count++; $out .= '['. $flight->flightnumber .': err code: ' . $result['code'] . ']';
            }
            
        }
        $count = count($flightreferences) - $count;
        $out .= "<p>Table: VolGeneriques<br>Nombre d'enregistrements proposés: " . count($flightreferences) . "<br>Nombre d'enregistrements ajoutés dans la table: " . 
                $count . '</p><br>';
        
        $count = 0;
        foreach ($flights as $flight){
            $sdate = substr($flight->scheduled_time, 0, 10);
            $stime = substr($flight->scheduled_time, 10);
            switch ($sdate) {
                case  '2020-01-08': $sdate = '2020-01-10'; break;
                case  '2020-01-09': $sdate = '2020-01-11'; break;
                case  '2020-01-10': $sdate = '2020-01-12'; break;
                case  '2020-01-11': $sdate = '2020-01-13'; break;
            }
            $edate = substr($flight->estimated_time, 0, 10);
            $etime = substr($flight->estimated_time, 10);
            switch ($edate) {
                case  '2020-01-08': $edate = '2020-01-10'; break;
                case  '2020-01-09': $edate = '2020-01-11'; break;
                case  '2020-01-10': $edate = '2020-01-12'; break;
                case  '2020-01-11': $edate = '2020-01-13'; break;
            }
            $result = $this->model->insert(new VolCedule($flight->id, $flight->flightref_number, $sdate . $stime, $edate . $etime,
                        $flight->status, $flight->terminal . $flight->gate));
            if ($result['code'] != 0) {
                $count++; $out .= '['. $flight->id . '/' . $flight->flightref_number .': err code: ' . $result['code'] . ']';
            }
            
        }
        $count = count($flights) - $count;
        $out .= "<br><p>Table: VolCedules<br>Nombre d'enregistrements proposé: " . count($flights) . "<br>Nombre d'enregistrements ajoutés dans la table: " . 
                $count . '</p><br>';
      
        
        
        echo $out;
        
    }
    public function loadFlightCalendar() {

        if (!Session::connected() || Session::getUserType() != 127) {
            Message::set('APP001');
            echo Message::get()[0];
            return;
        }
        $host = 'localhost:8181';
        $url = 'http://' . $host. '/phpControlTowerWebApi/public/flight/jsondata';
        //$url = '../app/ressources/docs/flightcalendar';
        $url_content = file_get_contents($url);
        $json = json_decode($url_content);

        $countries = $json->countries;
        $cities = $json->cities;
        $airports = $json->airports;
        $airlines = $json->airlines;
        $flightreferences = $json->flightreferences;
        $flights = $json->flights;

        $this->model = new VolModel();
        $out = '<br><hr><br><h3>Rapport de mise a jour:</h2><ul>';

        $data = $this->model->selectWithQuery("SELECT * FROM aeroports");
        $count = 0;
        foreach ($airports as $airport) {
            $found = false;
            foreach ($data as $aeroport) {
                if ($airport->iata == $aeroport->AeroportId) {
                    $found = true;
                    break;
                }
            }
            if (!$found) {
                $city = $this->getCityName($cities, $airport->city_id, $countries);
                $this->model->insert(new Aeroport($airport->iata, $airport->name, $city['name'], $city['country']));
            }
        }
        $out .= '<li> table "aeroports": ' . count($airports) . ' entrées ajoutées.</li>';

        $data = $this->model->selectWithQuery("SELECT * FROM compagnies");
        foreach ($airlines as $airline) {
            $found = false;
            foreach ($data as $compagnie) {
                if ($airline->iata == $compagnie->CompagnieId) {
                    $found = true;
                    break;
                }
            }
            if (!$found)
                $this->model->insert(new Compagnie($airline->iata, $airline->name, $airline->url_icon));
        }
        $out .= '<li> table "compagnies": ' . count($airlines) . ' entrées ajoutées.</li>';

        $data = $this->model->selectWithQuery("SELECT * FROM volgeneriques");
        foreach ($flightreferences as $flightref) {
            $found = false;
            foreach ($data as $volgenerique) {
                if ($flightref->flightnumber == $volgenerique->VolGeneriqueId) {
                    $found = true;
                    break;
                }
            }
            if (!$found)
                $this->model->insert(new VolGenerique($flightref->flightnumber, $flightref->airport_iata,
                                $flightref->airline_iata, $flightref->time, $flightref->direction));
        }
        $out .= '<li> table "volgeneriques": ' . count($flightreferences) . ' entrées ajoutées.</li>';

        $data = $this->model->selectWithQuery("SELECT * FROM volcedules");
        foreach ($flights as $flight) {
            $found = false;
            foreach ($data as $volcedule) {
                if ($flight->flightref_number == $volcedule->VolGeneriqueId && $flight->scheduled_time == $volcedule->DatePrevue) {
                    $found = true;
                    break;
                }
            }
            if (!$found)
                $this->model->insert(new VolCedule($flight->flightref_number, $flight->scheduled_time, $flight->estimated_time,
                                $flight->status, $flight->terminal . $flight->gate));
        }
        $flightCount = count($flights);
        $out .= '<li> table "volcedules": ' . $flightCount . ' entrées ajoutées.</li></ul><br>';
        if ($flightCount > 0) {
            $out .= '<strong>Periode de ' . $flights[0]->scheduled_time . ' a ' .
                    $flights[$flightCount - 1]->scheduled_time . '.</strong>';
        }
        echo $out;
    }

    public function verifyFileCalendarFile($mode = '') {

        if (!Session::connected() || Session::getUserType() != 127) {
            Message::set('APP001');
            echo Message::get()[0];
            return;
        }
        $host = 'localhost:8181';
        header('content-type text/html charset=utf-8');
        $url = 'http://' . $host. '/phpControlTowerWebApi/public/flight/jsondata';
        //$url = '../app/ressources/docs/flightcalendar';
        $out = '';
        try {
            $url_content = file_get_contents($url);
            $json = json_decode($url_content);
            $countries = $json->countries;
            $cities = $json->cities;
            $airports = $json->airports;
            $airlines = $json->airlines;
            $flightreferences = $json->flightreferences;
            $flights = $json->flights;
            $flightCount = count($flights);
            $out = '<div><br><strong>Données sur la ressource&nbsp;<b><i>Calendrier des vols</i></b></strong><br><br>' .
                    '<ul>' .
                    '<li> Nombre de vols génériques: &nbsp;' . count($flightreferences) . '</li>' .
                    '<li> Nombre de vols planifiés&nbsp;: &nbsp;' . $flightCount . '</li>' .
                    '<li> Nombre de compagnies aériennes partipantes&nbsp;: &nbsp;' . count($airlines) . '</li>' .
                    '<li> Nombre d\'aéoports participants&nbsp;: &nbsp;' . count($airports) . '</li>' .
                    '<li> Nombre de villes disservies&nbsp;: &nbsp;' . count($cities) . '</li>' .
                    '<li> Nombre de pays en référence&nbsp;: &nbsp;' . count($countries) . '</li><br>' .
                    '</ul>';


            if ($flightCount > 0) {
                $out .= '<br><p style="font-size:15px;font-weight: bold;background-color:cornflowerblue;padding:4px;">Periode du ' . $flights[0]->scheduled_time . ' au ' .
                        $flights[$flightCount - 1]->scheduled_time . '.</p><br><hr><br>';
            }
            $out .= '</div>';
        } catch (Exception $ex) {
            $out = '<h3>Erreur s\'est produite: la ressource n\'est pas accessible ou données corrompues.</h3><hr><br>';
        }
        if (empty($mode)) echo $out;
        else  if(strpos($out, "Erreur") == 4) echo 'Erreur'; else echo '';
        
    }

    public function updateprocess($action = 'status') {
        if (!Session::connected() || Session::getUserType() != 127) {
            Message::set('APP001');
            echo Message::get()[0];
            return;
        }
        header("Access-Control-Allow-Origin: *");
        if (in_array(strtolower($action), array('enable','disable','run', 'end', 'status'))) {

            /* Commandes de creation , desactivation , activation, terminaison, suppresion, execution de la tache de mise a jour BD */
            //$cmd_create = 'Schtasks /Create /SC MINUTE /MO 1 /tn batchscript /tr ./task.bat';
            $cmd_disable = 'Schtasks /Change /disable /tn '. $this->taskname;
            $cmd_enable = 'Schtasks /Change /enable /tn '. $this->taskname;
            $cmd_run = 'Schtasks /Run /tn '. $this->taskname;
            $cmd_end = 'Schtasks /End /tn '. $this->taskname;
            //$cmd_delete = 'Schtasks /Delete /tn '. $this->taskname . ' /f';
            $cmd_query = 'Schtasks /Query /tn '. $this->taskname;
            $out = [];
            $ret = 0;

            if (strtoupper(substr(PHP_OS, 0, 3)) == 'WIN') {
                // A activer apres reglement du probleme de creation de tache par php due probablement au droit d'acces
                //exec($cmd_query, $out, $ret);
                if ($ret != 0) { // Créer la tache FlightUpdate_Task si elle n'existe pas.
                    exec($cmd_query, $out, $ret);
                    if (($ret != 0)) {
                        echo 'Erreur de création de la tache d\'execution du processus de mise a jour.'; 
                        return; 
                    }
                }
                switch ($action) {
                    case 'enable': exec($cmd_enable, $out, $ret);
                        break;
                    case 'disable': exec($cmd_disable, $out, $ret);
                        break;
                    case 'run': exec($cmd_run, $out, $ret);
                        break;
                    case 'end': exec($cmd_end, $out, $ret);
                        break;
                    //case 'delete': exec($cmd_delete, $out, $ret); break;
                }
                exec($cmd_query, $out, $ret);
                $TaskName = $NextRunTime = $Status = '';
                if ($ret == 0) {
                    $result = explode(' ', $out[count($out) - 1]);
                    $TaskName = $result[0];
                    $len_1 = count($result) - 1;
                    $Status = $result[$len_1];
                    for ($i = 1; $i < $len_1; $i++) {
                        $NextRunTime .= $result[$i] . ' ';
                    }
                    echo '{"Action":"' . $action . '",' .
                          '"TaskName":"' . $TaskName . '",' .
                          '"NextRunTime":"' . $NextRunTime . '",' .
                          '"Status":"' . $this->getProcessStatus($Status) . '"}';
                } else { 
                    echo 'La tache d\'execution du processus de mise a jour ne repond pas.'; 
                    return; 
                }
            } else {// Linux / Unix / MacOs
                echo 'Linux / Unix / MacOs';
            }
        }
    }

    public function test() {
        $dt = '2020-01-09 18:17:15';
        $sdate = substr($dt, 0, 10);
            $stime = substr($dt, 10);
            switch ($sdate) {
                case  '2020-01-09': $sdate = '2020-01-10'; break;
                case  '2020-01-10': $sdate = '2020-01-11'; break;
                case  '2020-01-11': $sdate = '2020-01-12'; break;
            }
       echo $sdate . $stime;
    }

    /*
     *  P R I V A T E    F U N C T  I O N S 
     */
    private function getProcessStatus($status){
        switch($status){
            case 'Ready': return 'Pret';
            case 'Disabled': return 'Désactivé';
            case 'Running':return 'En execution';
            case 'Queued':return 'En attente';
            default: return '';
        }
    }
    private function getCityName($cities, $city_id, $countries) {
        $cityInfo = ['name' => '', 'country' => ''];
        foreach ($cities as $city) {
            if ($city->id == $city_id) {
                if (!empty($city->country_iso_code))
                    $country_name = $this->getCountryName($countries, $city->country_iso_code);
                else
                    $country_name = '';
                if (!empty($city->state))
                    $cityInfo = ['name' => $city->name . ', ' . $city->state, 'country' => $country_name];
                else
                    $cityInfo = ['name' => $city->name, 'country' => $country_name];
                break;
            }
        }
        return $cityInfo;
    }

    private function getCountryName($countries, $country_id) {
        $country_name = '';
        foreach ($countries as $country) {
            if ($country->iso_alpha2_code == $country_id) {
                $country_name = $country->name;
                break;
            }
        }
        return $country_name;
    }

    private function execInBackground($cmd) {
        if (substr(php_uname(), 0, 7) == "Windows") {
            pclose(popen("start /B " . $cmd, "r"));
        } else {
            exec($cmd . " > /dev/null &");
        }
    }

}
