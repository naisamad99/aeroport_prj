<?php

class FlightController extends BaseController {
    
    public function loadtable($tablename = '') {
        if (!Session::connected() || Session::getUserType() != 127) {
            Message::set('APP001');
            echo Message::get()[0];
            return;
        }
        $host = 'localhost:8181';
        $url = 'http://' . $host. '/phpControlTowerWebApi/public/flight/jsondata';
        $url_content = file_get_contents($url);
        $tablename = strtolower($tablename);
        if ($tablename == 'all') echo $url_content;
        else {
            $json = json_decode($url_content);
            $tabledata = [];
            switch($tablename){
                case 'countries' : $tabledata = $json->countries; break;
                case 'cities' : $tabledata = $json->cities; break;
                case 'airports' : $tabledata = $json->airports; break;
                case 'airlines' : $tabledata = $json->airlines; break;
                case 'flightrefs' : $tabledata = $json->flightreferences; break;
                case 'flights' : $tabledata = $json->flights; break;
                default : $tabledata = [];
            }
            echo json_encode($tabledata);
        }
    }
    
    public function recordtodb($tablename = ''){
        if (!Session::connected() || Session::getUserType() != 127) {
            Message::set('APP001');
            echo Message::get()[0];
            return;
        }
        $_tablename = strtolower($tablename);
        $array = json_decode($_POST[$_tablename]);
        $this->model = new VolModel();
        $log = '<li>'; $i = 0;
        switch($_tablename){
            case 'aeroports' : 
                foreach ($array as $aeroport) {
                    $ro = $this->model->insert(new Aeroport($aeroport->AeroportId, $aeroport->NomAeroport, $aeroport->Ville, $aeroport->Pays));  
                    if ($ro['code'] == 0) $i++;
                } 
                $log .= $i . ' ' . $_tablename . ' enregistré(s).</li>';
                break; 
                
            case 'compagnies' : 
                foreach ($array as $compagnie) {
                    $ro = $this->model->insert(new Compagnie($compagnie->CompagnieId, $compagnie->NomCompagnie, $compagnie->LogoUri));  
                    if ($ro['code'] == 0) $i++;
                } 
                $log .= $i . ' ' . $_tablename . ' enregistré(s).</li>';
                break;
            case 'volgeneriques' : 
                foreach ($array as $volgenerique) {
                    // VolGenerique(VolGeneriqueId, AeroportId, CompagnieId, HeurePrevue, Direction)
                    $ro = $this->model->insert(new VolGenerique($volgenerique->VolGeneriqueId, $volgenerique->AeroportId, $volgenerique->CompagnieId, 
                                                                $volgenerique->HeurePrevue, $volgenerique->Direction));  
                    if ($ro['code'] == 0) $i++;
                } 
                $log .= $i . ' ' . $_tablename . ' enregistré(s).</li>';
                break;
            case 'volcedules' : 
                foreach ($array as $volcedule) {
                    // VolCedule(VolCeduleId, VolGeneriqueId, DatePrevue, DateRevisee, Statut, Porte)
                    $ro = $this->model->insert(new VolCedule($volcedule->VolCeduleId, $volcedule->VolGeneriqueId, $volcedule->DatePrevue, 
                                                                $volcedule->DateRevisee, $volcedule->Statut, $volcedule->Porte));  
                    if ($ro['code'] == 0) $i++;
                } 
                $log .= $i . ' ' . $_tablename . ' enregistré(s).</li>';
                break;
            case 'testtables' : 
                $log .= '10 ' . $_tablename . '0 enregistré(s).</li>';
                $log .= '<li>11 ' . $_tablename . '1 enregistré(s).</li>';
                $log .= '<li>12 ' . $_tablename . '2 enregistré(s).</li>';
                break;
            default : $log = '<No table></li>';
        }
        echo $log;
    }
    
    public function chargertable($tablename = '') {
        if (!Session::connected() || Session::getUserType() != 127) {
            Message::set('APP001');
            echo Message::get()[0];
            return;
        }
        $this->model = new VolModel();
        $tablename = strtolower($tablename);
        switch($tablename){
            case 'aeroports' : $tabledata = $this->model->selectWithQuery("SELECT * FROM aeroports;"); break;
            case 'compagnies' : $tabledata = $this->model->selectWithQuery("SELECT * FROM compagnies;"); break;
            default : $tabledata = [];
        }
        echo count($tabledata);
       
    }
    private function updateDepartureFlights($flights=[]){

         header("Content-type:text/html");

         foreach ($flights as $flightItem) {

             $yearmonthdayflightid = substr($flightItem->url, strpos($flightItem->url, "?") + 1);
             $data = $this->detail($flightItem->carrier->fs, $flightItem->carrier->flightNumber, $yearmonthdayflightid, 'Update');
             $flight = json_decode($data)->props->initialState->flightTracker->flight; //props.initialState.flightTracker.flight

             $airport = $flight->arrivalAirport;
             $airline = $flight->ticketHeader;

             $flightmodel = new FlightModel();

             $out = '[';
             // Insert the city if not exist
             $data = $flightmodel->selectWithQuery("SELECT * FROM cities WHERE name='" . $airport->city . "'");

             if (count($data) < 1) {
                 $data = $flightmodel->selectWithQuery("SELECT * FROM countries WHERE iso_alpha2_code='" . $airport->country . "'");
                 $country_id = (count($data) < 1)? 263 : $data[0]->id; 
                 $flightmodel->insert(new City($airport->city, $airport->state, $country_id));
                 $data = $flightmodel->selectWithQuery("SELECT * FROM cities WHERE name='" . $airport->city . "'");
                 $out .= 'Insertion in cities],[<br>';
             } 
             $city_id = $data[0]->id;

             // Insert the airport if not exist
             $data = $flightmodel->selectWithQuery("SELECT * FROM airports WHERE iata='" . $airport->iata . "'");
             if (count($data) < 1) {
                 $flightmodel->insert(new Airport($airport->name, $airport->iata, $city_id)); 
                 $data = $flightmodel->selectWithQuery("SELECT * FROM airports WHERE iata='" . $airport->iata . "'");
                 $out .= 'Insertion in airports],[<br>';
             }
             $airport_id = $data[0]->id;

             // Insert the airline if not exist
             $data = $flightmodel->selectWithQuery("SELECT * FROM airlines WHERE iata='" . $airline->carrier->fs . "'");
             if (count($data) < 1) {
                 $flightmodel->insert(new Airline($airline->carrier->name, $airline->carrier->fs, '', 263, $airline->iconURL)); 
                 $data = $flightmodel->selectWithQuery("SELECT * FROM airlines WHERE iata='" . $airline->carrier->fs . "'");
                 $out .= 'Insertion in airlines],[<br>';
             }
             $airline_id = $data[0]->id;

             // Insert the flightref if not exist
             $flightnumber = $airline->carrier->fs . $airline->flightNumber;
             $data = $flightmodel->selectWithQuery("SELECT * FROM flightreferences WHERE flightnumber='" . $flightnumber . "'");
             if (count($data) < 1) {
                 $time = $flight->departureAirport->times->scheduled->time24; 
                 //Or $time = $this->formatDateTime($flight->schedule->scheduledDeparture); 
                 $flightmodel->insert(new FlightReference($flightnumber, $airline_id, $airport_id, 0, $time)); 
                 $out .= 'Insertion in flightrefs],[<br>';
              }


              // Insert the flight if not exist
              $data = $flightmodel->selectWithQuery("SELECT * FROM flights WHERE flightref_number='" . 
                         $flightnumber . "' AND scheduled_time='" . $this->formatDateTime($flight->schedule->scheduledDeparture) . "'");
              if (count($data) < 1) {
                 $flightmodel->insert(new Flight($flightnumber, $this->formatDateTime($flight->schedule->scheduledDeparture), 
                         $this->formatDateTime($flight->schedule->scheduledDeparture), $this->getStatusId($flight->status->status), 
                         $flight->departureAirport->terminal, $flight->departureAirport->gate)); 
                 $out .= 'Insertion in flights]]<br>';
              }

         }

         echo $out;
     }
    
    private function updateArrivalFlights($flights=[]){

    }

    private function getStatusId($statusString) {

        switch($statusString) {
            case 'On time' : return 0;  //A L'HEURE 
            case 'Departed': return 1;  //PARTI
            case 'Arrived' : return 2;  //ARRIVE
            case 'Delayed' : return 3;  //RETARDE
            case 'Advanced' : return 4; //AVANCE
            case 'Canceled': return 5;  // ANNULE
            default:  return 4; // En Avance
        }

    }

    private function formatDateTime($dateTimeStr) {

        return date_format(date_create($dateTimeStr),"Y-m-d H:i:s");

    }

    private function addDateTimeAndFormat($dateTimeStr, $number, $unity) {

        $date=date_create($dateTimeStr);
        date_add($date,date_interval_create_from_date_string($number . ' ' . $unity));
        return date_format($date,"Y-m-d H:i:s");

    }
}
