
<?php

require_once '../app/configs/globals.php';


// Definir la nouvelle extention des classes php de l'aaplication

spl_autoload_extensions(CLASS_EXT);

// Utiliser l'implementation par default de '__autoload' pour charger le fichier de php qui contient la classe invoquée
//spl_autoload_register('spl_autoload', false);

spl_autoload_register();


// Lancement de l'application
new Application;

?>
