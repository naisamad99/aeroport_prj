-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Dec 21, 2019 at 07:10 PM
-- Server version: 8.0.18
-- PHP Version: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `aeroportdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `aeroports`
--

CREATE TABLE `aeroports` (
  `AeroportId` varchar(5) CHARACTER SET utf16 COLLATE utf16_general_ci NOT NULL,
  `NomAeroport` varchar(60) CHARACTER SET utf16 COLLATE utf16_general_ci DEFAULT NULL,
  `Ville` varchar(50) CHARACTER SET utf16 COLLATE utf16_general_ci DEFAULT NULL,
  `Pays` varchar(50) CHARACTER SET utf16 COLLATE utf16_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf16;

--
-- Dumping data for table `aeroports`
--

INSERT INTO `aeroports` (`AeroportId`, `NomAeroport`, `Ville`, `Pays`) VALUES
('ATL', 'Hartsfield-Jackson Atlanta International Airport', 'Atlanta, GA', 'United States'),
('AZS', 'Samana El Catey Airport', 'El Catey/Samana', 'Dominica'),
('BGI', 'Grantley Adams International Airport', 'Bridgetown', 'Barbados'),
('BOS', 'Logan International Airport', 'Halifax, NS', 'Canada'),
('BTV', 'Burlington International Airport', 'Burlington, VT', 'United States'),
('BWI', 'Baltimore/Wash International Thurgood Marshall Airport', 'Baltimore, MD', 'United States'),
('CCC', 'Jardines del Rey Airport', 'Cayo Coco', 'Cuba'),
('CDG', 'Charles de Gaulle Airport', 'Paris', 'France'),
('CLT', 'Charlotte Douglas International Airport', 'Charlotte, NC', 'United States'),
('CMN', 'Mohamed V International Airport', 'Casablanca', 'Madagascar'),
('CTG', 'Rafael Nunez International Airport', 'Cartagena', 'Colombia'),
('CUN', 'Cancun International Airport', 'Sept-Iles, QC', 'Canada'),
('CYO', 'Cayo Largo Del Sur Airport', 'Puerto Plata', 'Dominica'),
('DEN', 'Denver International Airport', 'Denver, CO', 'United States'),
('DFW', 'Dallas/Fort Worth International Airport', 'Dallas, TX', 'United States'),
('DTW', 'Detroit Metropolitan Wayne County Airport', 'Detroit, MI', 'United States'),
('EWR', 'Newark Liberty International Airport', 'Newark, NJ', 'United States'),
('FDF', 'Martinique Aime Cesaire International Airport', 'Fort De France', 'Midway Islands'),
('FLL', 'Fort Lauderdale-Hollywood International Airport', 'Fort Lauderdale, FL', 'United States'),
('FPO', 'Grand Bahama International Airport', 'Frankfurt', 'UNKNOWN COUNTRY'),
('FRA', 'Frankfurt Airport', 'Frankfurt', 'UNKNOWN COUNTRY'),
('HAG', 'Houari', 'Casablanca', 'Madagascar'),
('HOG', 'Frank Pais Airport', 'Holguin', 'Cuba'),
('IAD', 'Washington Dulles International Airport', 'Trois-Rivieres, QC', 'Canada'),
('IAH', 'George Bush Intercontinental Airport', 'Houston, TX', 'United States'),
('JFK', 'John F. Kennedy International Airport', 'New York, NY', 'United States'),
('LAS', 'McCarran International Airport', 'Chicago, IL', 'United States'),
('LAX', 'Los Angeles International Airport', 'Los Angeles, CA', 'United States'),
('LGA', 'LaGuardia Airport', 'New York, NY', 'United States'),
('LHR', 'London Heathrow Airport', 'London, EN', 'Gabon'),
('LRM', 'La Romana Airport', 'La Romana', 'Dominica'),
('MBJ', 'Sangster International Airport', 'Montego Bay', 'Jamaica'),
('MCO', 'Orlando International Airport', 'Orlando, FL', 'United States'),
('MEX', 'Benito Juarez International Airport', 'Povungnituk, QC', 'Canada'),
('MIA', 'Miami International Airport', 'Miami, FL', 'United States'),
('MSP', 'Minneapolis-St. Paul International Airport', 'Minneapolis, MN', 'United States'),
('NAS', 'Lynden Pindling International Airport', 'Dulles, VA', 'United States'),
('ORD', 'O Hare International Airport', 'Bathurst, NB', 'Canada'),
('PHL', 'Philadelphia International Airport', 'Nassau', 'Bassas da India'),
('POP', 'La Union Airport', 'Puerto Plata', 'Dominica'),
('PTP', 'Pointe-a-Pitre Le Raizet Airport', 'Pointe-a-Pitre', 'Guadeloupe'),
('PUJ', 'Punta Cana International Airport', 'Punta Cana', 'Dominica'),
('PVR', 'Gustavo Diaz Ordaz International Airport', 'Puerto Vallarta', 'Mexico'),
('RIH', 'Scarlett Martinez International Airport', 'Rio Hato', 'Paraguay'),
('ROC', 'Greater Rochester International Airport', 'Rochester, NY', 'United States'),
('SDQ', 'Las Americas International Airport', 'Santo Domingo', 'Dominica'),
('SJO', 'Juan Santamaria International Airport', 'San Jose', 'Coral Sea Islands'),
('SJU', 'Luis Munoz Marin International Airport', 'San Juan', 'UNKNOWN COUNTRY'),
('SNU', 'Santa Clara Airport', 'Santa Clara', 'Cuba'),
('SUA', 'Witham Field', 'Stuart, FL', 'United States'),
('SXM', 'Princess Juliana International Airport', 'Sint Maarten', 'South Georgia and the Islands'),
('TEB', 'Teterboro Airport', 'Teterboro, NJ', 'United States'),
('TPA', 'Tampa International Airport', 'Tampa, FL', 'United States'),
('TUN', 'Tunis-Carthage International Airport', 'Philadelphia, PA', 'United States'),
('UVF', 'Hewanorra Airport', 'Saint Lucia', 'UNKNOWN COUNTRY'),
('VRA', 'Juan Gualberto Gomez Airport', 'Varadero', 'Cuba'),
('YBC', 'Baie-Comeau Airport', 'Baie Comeau, QC', 'Canada'),
('YBG', 'Saguenay-Bagotville Airport', 'La Baie, QC', 'Canada'),
('YCL', 'Charlo Airport', 'Charlo, NB', 'Canada'),
('YEG', 'Edmonton International Airport', 'Cancun', 'Mexico'),
('YFC', 'Fredericton International Airport', 'Fredericton, NB', 'Canada'),
('YGK', 'Kingston/Norman Rogers Airport', 'Kingston, ON', 'Canada'),
('YGL', 'La Grande Airport', 'La Grande, QC', 'Canada'),
('YGW', 'Kuujjuarapik Airport', 'Kuujjuarapik, QC', 'Canada'),
('YHZ', 'Halifax Stanfield International Airport', 'Edmonton, AB', 'Canada'),
('YOW', 'Ottawa/Macdonald-Cartier International Airport', 'Ottawa, ON', 'Canada'),
('YQB', 'Quebec City Jean Lesage International Airport', 'Quebec, QC', 'Canada'),
('YQM', 'Greater Moncton International Airport', 'Moncton, NB', 'Canada'),
('YTZ', 'Billy Bishop Toronto City Airport', 'Toronto, ON', 'Canada'),
('YUL', 'Montreal-Pierre Elliott Trudeau International Airport', 'Frankfurt', 'UNKNOWN COUNTRY'),
('YVO', 'Val-d Or Airport', 'Val D Or, QC', 'Canada'),
('YVP', 'Kuujjuaq Airport', 'Kuujjuaq, QC', 'Canada'),
('YVR', 'Vancouver International Airport', 'Vancouver, BC', 'Canada'),
('YWG', 'Winnipeg James Armstrong Richardson International Airport', 'Winnipeg, MB', 'Canada'),
('YWK', 'Wabush Airport', 'Wabush, NL', 'Canada'),
('YYC', 'Calgary International Airport', 'Calgary, AB', 'Canada'),
('YYG', 'Charlottetown Airport', 'Charlottetown, PE', 'Canada'),
('YYT', 'St. John s International Airport', 'Philadelphia, PA', 'United States'),
('YYY', 'Mont Joli Airport', 'Mont Joli, QC', 'Canada'),
('YYZ', 'Pearson International Airport', 'Toronto, ON', 'Canada'),
('YZV', 'Sept-Iles Airport', 'Panama City', 'Paraguay'),
('ZIH', 'Ixtapa/Zihuatanejo Internacional Airport', 'Ixtapa/Zihuatanejo', 'Mexico');

-- --------------------------------------------------------

--
-- Table structure for table `compagnies`
--

CREATE TABLE `compagnies` (
  `CompagnieId` varchar(5) CHARACTER SET utf16 COLLATE utf16_general_ci NOT NULL,
  `NomCompagnie` varchar(60) CHARACTER SET utf16 COLLATE utf16_general_ci DEFAULT NULL,
  `logoUri` varchar(80) CHARACTER SET utf16 COLLATE utf16_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf16;

--
-- Dumping data for table `compagnies`
--

INSERT INTO `compagnies` (`CompagnieId`, `NomCompagnie`, `logoUri`) VALUES
('0Q', 'Hydro - Quebec', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/0q-logo.png'),
('3H', 'Air Inuit', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/3h-logo.png'),
('4O', 'Interjet', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/4o-logo.png'),
('5T', 'Canadian North', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/5t-logo.png'),
('7F', 'First Air', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/7f-logo.png'),
('AA', 'American Airlines', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/aa-logo.png'),
('AC', 'Air Canada', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/ac-logo.png'),
('AF', 'Air France', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/af-logo.png'),
('AH', 'Air Algerie', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/ah-logo.png'),
('AI', 'Air India', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/ai-logo.png'),
('AM', 'Aeromexico', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/am-logo.png'),
('AS', 'Alaska Airlines', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/as-logo.png'),
('ASP', 'AirSprint', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/asp-logo.png'),
('AT', 'Royal Air Maroc', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/at-logo.png'),
('AV', 'SA AVIANCA', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/av-logo.png'),
('AZ', 'Alitalia', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/az-logo.png'),
('BR', 'EVA Air', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/br-logo.png'),
('CA', 'Air China LTD', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/ca-logo.png'),
('CM', 'Copa Airlines', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/cm-logo.png'),
('CX', 'Cathay Pacific', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/cx-logo.png'),
('DL', 'Delta Air Lines', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/dl-logo.png'),
('EK', 'Emirates', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/ek-logo.png'),
('EY', 'Etihad Airways', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/ey-logo.png'),
('G3', 'Gol', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/g3-logo.png'),
('HU', 'Hainan Airlines', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/hu-logo.png'),
('IB', 'Iberia', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/ib-logo.png'),
('KE', 'Korean Air', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/ke-logo.png'),
('KL', 'KLM', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/kl-logo.png'),
('LA', 'LATAM Airlines', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/la-logo.png'),
('LH', 'Lufthansa', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/lh-logo.png'),
('LO', 'LOT - Polish Airlines', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/lo-logo.png'),
('LX', 'SWISS', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/lx-logo.png'),
('LXJ', 'Flexjet', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/lxj-logo.png'),
('ME', 'Middle East Airlines', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/me-logo.png'),
('MS', 'EgyptAir', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/ms-logo.png'),
('MU', 'China Eastern Airlines', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/mu-logo.png'),
('N5*', 'Nolinor', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/n5*-logo.png'),
('NDL', 'Chrono Aviation', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/ndl-logo.png'),
('NH', 'ANA', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/nh-logo.png'),
('NZ', 'Air New Zealand', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/nz-logo.png'),
('OS', 'Austrian', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/os-logo.png'),
('OZ', 'Asiana Airlines', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/oz-logo.png'),
('PB', 'PAL Airlines', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/pb-logo.png'),
('PD', 'Porter Airlines', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/pd-logo.png'),
('PR', 'Philippine Airlines', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/pr-logo.png'),
('QF', 'Qantas', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/qf-logo.png'),
('QUE', 'Gouvernement Du Quebec', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/que-logo.png'),
('S4', 'Azores Airlines', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/s4-logo.png'),
('SA', 'South African Airways', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/sa-logo.png'),
('SK', 'SAS', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/sk-logo.png'),
('SN', 'Brussels Airlines', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/sn-logo.png'),
('SWG', 'Sunwing', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/swg-logo.png'),
('TGO', 'Transport Canada', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/tgo-logo.png'),
('TK', 'Turkish Airlines', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/tk-logo.png'),
('TP', 'TAP Air Portugal', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/tp-logo.png'),
('TS', 'Air Transat', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/ts-logo.png'),
('TU', 'Tunisair', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/tu-logo.png'),
('UA', 'United Airlines', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/ua-logo.png'),
('VA', 'Virgin Australia', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/va-logo.png'),
('VS', 'Virgin Atlantic', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/vs-logo.png'),
('WS', 'WestJet', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/ws-logo.png'),
('YN', 'Air Creebec', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/yn-logo.png');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `VolCeduleId` int(11) NOT NULL,
  `NumTel` varchar(20) CHARACTER SET utf16 COLLATE utf16_general_ci NOT NULL,
  `DateInscription` datetime NOT NULL,
  `DateArret` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf16;

-- --------------------------------------------------------

--
-- Table structure for table `utilisateurs`
--

CREATE TABLE `utilisateurs` (
  `NomUtilisateur` varchar(30) CHARACTER SET utf16 COLLATE utf16_general_ci NOT NULL,
  `MotDePasse` varchar(20) NOT NULL,
  `Role` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf16;

--
-- Dumping data for table `utilisateurs`
--

INSERT INTO `utilisateurs` (`NomUtilisateur`, `MotDePasse`, `Role`) VALUES
('admin1', '1234', 127),
('admin2', 'abcd', 127),
('user1', 'abcd', 0);

-- --------------------------------------------------------

--
-- Table structure for table `volcedules`
--

CREATE TABLE `volcedules` (
  `VolCeduleId` int(11) NOT NULL,
  `VolGeneriqueId` varchar(10) NOT NULL,
  `DatePrevue` datetime NOT NULL,
  `DateRevisee` datetime NOT NULL,
  `Statut` tinyint(2) NOT NULL DEFAULT '0',
  `Porte` varchar(5) CHARACTER SET utf16 COLLATE utf16_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf16;

--
-- Dumping data for table `volcedules`
--

INSERT INTO `volcedules` (`VolCeduleId`, `VolGeneriqueId`, `DatePrevue`, `DateRevisee`, `Statut`, `Porte`) VALUES
(62, 'DL5520', '2019-12-20 05:35:00', '2019-12-20 05:35:00', 2, 'C86'),
(63, 'AM3125', '2019-12-20 05:35:00', '2019-12-20 05:35:00', 2, 'C86'),
(64, 'WS7922', '2019-12-20 05:35:00', '2019-12-20 05:35:00', 2, 'C86'),
(65, 'AM4012', '2019-12-20 05:50:00', '2019-12-20 05:50:00', 2, 'C80'),
(66, 'KE3836', '2019-12-20 05:50:00', '2019-12-20 05:50:00', 2, 'C80'),
(67, 'WS6446', '2019-12-20 05:50:00', '2019-12-20 05:50:00', 2, 'C80'),
(68, 'DL5479', '2019-12-20 05:50:00', '2019-12-20 05:50:00', 2, 'C80'),
(69, 'VS3788', '2019-12-20 05:50:00', '2019-12-20 05:50:00', 2, 'C80'),
(70, 'TS216', '2019-12-20 06:00:00', '2019-12-20 06:00:00', 2, 'A64'),
(71, 'SWG652', '2019-12-20 06:00:00', '2019-12-20 06:00:00', 2, 'A55'),
(72, 'OS8390', '2019-12-20 06:00:00', '2019-12-20 06:00:00', 2, 'A47'),
(73, 'AC1600', '2019-12-20 06:00:00', '2019-12-20 06:00:00', 2, 'C58'),
(74, 'UA8705', '2019-12-20 06:00:00', '2019-12-20 06:00:00', 2, 'C58'),
(75, 'WS3513', '2019-12-20 06:00:00', '2019-12-20 06:00:00', 2, 'A4'),
(76, 'AM7322', '2019-12-20 06:00:00', '2019-12-20 06:00:00', 2, 'A4'),
(77, 'DL7204', '2019-12-20 06:00:00', '2019-12-20 06:00:00', 2, 'A4'),
(78, 'KE6530', '2019-12-20 06:00:00', '2019-12-20 06:00:00', 2, 'A4'),
(79, 'LA5218', '2019-12-20 06:00:00', '2019-12-20 06:00:00', 2, 'A4'),
(80, 'QF3975', '2019-12-20 06:00:00', '2019-12-20 06:00:00', 2, 'A4'),
(81, 'AA3981', '2019-12-20 06:00:00', '2019-12-20 06:00:00', 2, 'C83'),
(82, 'AA1516', '2019-12-20 06:00:00', '2019-12-20 06:00:00', 2, 'C81'),
(83, 'LA6634', '2019-12-20 06:00:00', '2019-12-20 06:00:00', 2, 'C81'),
(84, 'SWG638', '2019-12-20 06:00:00', '2019-12-20 06:00:00', 2, 'A65'),
(85, 'TS902', '2019-12-20 06:00:00', '2019-12-20 06:00:00', 2, 'A66'),
(86, 'AC481', '2019-12-20 06:00:00', '2019-12-20 06:00:00', 2, 'A47'),
(87, 'SWG408', '2019-12-20 06:00:00', '2019-12-20 06:00:00', 2, ''),
(88, 'SWG258', '2019-12-20 06:00:00', '2019-12-20 06:00:00', 2, 'A63'),
(89, 'YN703', '2019-12-20 06:00:00', '2019-12-20 06:00:00', 2, ''),
(90, 'SWG248', '2019-12-20 06:00:00', '2019-12-20 06:00:00', 2, 'A61'),
(91, 'AC485', '2019-12-20 06:30:00', '2019-12-20 06:30:00', 2, 'A49'),
(92, 'AC7630', '2019-12-20 06:30:00', '2019-12-20 06:30:00', 2, 'C74'),
(93, 'AC808', '2019-12-19 19:10:00', '2019-12-19 19:10:00', 4, 'A50'),
(94, 'UA8647', '2019-12-19 19:10:00', '2019-12-19 19:10:00', 4, 'A50'),
(95, 'AI7306', '2019-12-19 19:50:00', '2019-12-19 19:50:00', 2, 'A52'),
(96, 'ME4506', '2019-12-19 19:50:00', '2019-12-19 19:50:00', 2, 'A52'),
(97, 'MS9601', '2019-12-19 19:50:00', '2019-12-19 19:50:00', 2, 'A52'),
(98, 'OS8240', '2019-12-19 19:50:00', '2019-12-19 19:50:00', 2, 'A52'),
(99, 'SA7317', '2019-12-19 19:50:00', '2019-12-19 19:50:00', 2, 'A52'),
(100, 'TP8263', '2019-12-19 19:50:00', '2019-12-19 19:50:00', 2, 'A52'),
(101, 'UA8296', '2019-12-19 19:50:00', '2019-12-19 19:50:00', 2, 'A52'),
(102, 'AC864', '2019-12-19 19:50:00', '2019-12-19 19:50:00', 2, 'A52'),
(103, 'LH6839', '2019-12-19 19:50:00', '2019-12-19 19:50:00', 2, 'A52'),
(104, 'AC8686', '2019-12-19 20:45:00', '2019-12-19 20:45:00', 2, 'A27'),
(105, 'UA8164', '2019-12-19 21:20:00', '2019-12-19 21:20:00', 2, 'A49'),
(106, 'AC8506', '2019-12-19 21:20:00', '2019-12-19 21:20:00', 2, 'A49'),
(107, 'AC8732', '2019-12-19 21:50:00', '2019-12-19 21:50:00', 2, 'A2'),
(108, 'QUE10', '2019-12-20 02:20:00', '2019-12-20 02:20:00', 2, ''),
(109, 'AC8831', '2019-12-20 05:30:00', '2019-12-20 05:30:00', 2, 'A2'),
(110, 'ASP822', '2019-12-20 08:00:00', '2019-12-20 08:00:00', 2, ''),
(111, 'AC2426', '2019-12-20 11:00:00', '2019-12-20 11:00:00', 1, 'A51'),
(112, 'AT207', '2019-12-20 11:25:00', '2019-12-20 11:25:00', 1, 'A57'),
(113, 'AC411', '2019-12-20 12:00:00', '2019-12-20 12:00:00', 2, 'A1'),
(114, 'AV6917', '2019-12-20 12:00:00', '2019-12-20 12:00:00', 2, 'A1'),
(115, 'AZ5851', '2019-12-20 12:04:00', '2019-12-20 12:04:00', 2, 'C85'),
(116, 'G38340', '2019-12-20 12:04:00', '2019-12-20 12:04:00', 2, 'C85'),
(117, 'KL5585', '2019-12-20 12:04:00', '2019-12-20 12:04:00', 2, 'C85'),
(118, 'VS4684', '2019-12-20 12:04:00', '2019-12-20 12:04:00', 2, 'C85'),
(119, 'WS6434', '2019-12-20 12:04:00', '2019-12-20 12:04:00', 2, 'C85'),
(120, 'AF8875', '2019-12-20 12:04:00', '2019-12-20 12:04:00', 2, 'C85'),
(121, 'DL5517', '2019-12-20 12:04:00', '2019-12-20 12:04:00', 2, 'C85'),
(122, 'KE7379', '2019-12-20 12:04:00', '2019-12-20 12:04:00', 2, 'C85'),
(123, 'PD466', '2019-12-20 12:15:00', '2019-12-20 12:15:00', 2, 'A7'),
(124, 'IB4284', '2019-12-20 12:22:00', '2019-12-20 12:22:00', 2, 'C79'),
(125, 'AS4367', '2019-12-20 12:22:00', '2019-12-20 12:22:00', 2, 'C79'),
(126, 'QF3332', '2019-12-20 12:22:00', '2019-12-20 12:22:00', 2, 'C79'),
(127, 'AA3102', '2019-12-20 12:22:00', '2019-12-20 12:22:00', 2, 'C79'),
(128, 'AC7963', '2019-12-20 12:30:00', '2019-12-20 12:30:00', 2, 'A2'),
(129, 'AC8712', '2019-12-20 12:30:00', '2019-12-20 12:30:00', 2, 'A10'),
(130, 'SN9605', '2019-12-20 12:30:00', '2019-12-20 12:30:00', 2, 'A10'),
(131, 'VS3352', '2019-12-20 12:40:00', '2019-12-20 12:40:00', 2, 'C80'),
(132, 'DL5498', '2019-12-20 12:40:00', '2019-12-20 12:40:00', 2, 'C80'),
(133, 'AF2116', '2019-12-20 12:40:00', '2019-12-20 12:40:00', 2, 'C80'),
(134, 'KL7123', '2019-12-20 12:40:00', '2019-12-20 12:40:00', 2, 'C80'),
(135, 'WS7839', '2019-12-20 12:40:00', '2019-12-20 12:40:00', 2, 'C80'),
(136, 'G38314', '2019-12-20 12:43:00', '2019-12-20 12:43:00', 2, 'C84'),
(137, 'WS7767', '2019-12-20 12:43:00', '2019-12-20 12:43:00', 2, 'C84'),
(138, 'AM4240', '2019-12-20 12:43:00', '2019-12-20 12:43:00', 2, 'C84'),
(139, 'DL5525', '2019-12-20 12:43:00', '2019-12-20 12:43:00', 2, 'C84'),
(140, 'AC8014', '2019-12-20 12:45:00', '2019-12-20 12:45:00', 2, 'A9'),
(141, 'TU203', '2019-12-20 15:15:00', '2019-12-20 15:15:00', 4, 'A58'),
(142, 'AA4845', '2019-12-20 17:40:00', '2019-12-20 17:40:00', 4, 'C79'),
(143, 'CA7499', '2019-12-20 17:45:00', '2019-12-20 17:45:00', 4, 'A25'),
(144, 'LX4684', '2019-12-20 17:45:00', '2019-12-20 17:45:00', 4, 'A25'),
(145, 'AC8985', '2019-12-20 17:45:00', '2019-12-20 17:45:00', 4, 'A25'),
(146, 'AC7640', '2019-12-20 17:45:00', '2019-12-20 17:45:00', 4, 'C80'),
(147, 'AC8753', '2019-12-20 17:50:00', '2019-12-20 17:50:00', 4, 'A30'),
(148, 'EY3859', '2019-12-20 18:00:00', '2019-12-20 18:00:00', 4, 'A1'),
(149, 'CA7525', '2019-12-20 18:00:00', '2019-12-20 18:00:00', 4, 'A28'),
(150, 'LX4652', '2019-12-20 18:00:00', '2019-12-20 18:00:00', 4, 'A28'),
(151, 'AC2008', '2019-12-20 18:00:00', '2019-12-20 18:00:00', 4, 'A51'),
(152, 'OS8396', '2019-12-20 18:00:00', '2019-12-20 18:00:00', 4, 'A1'),
(153, 'AC423', '2019-12-20 18:00:00', '2019-12-20 18:00:00', 4, 'A1'),
(154, 'AC8726', '2019-12-20 18:00:00', '2019-12-20 18:00:00', 4, 'A28'),
(155, 'KL2389', '2019-12-20 18:10:00', '2019-12-20 18:10:00', 4, 'A55'),
(156, 'ME4345', '2019-12-20 18:10:00', '2019-12-20 18:10:00', 4, 'A55'),
(157, 'VS6795', '2019-12-20 18:10:00', '2019-12-20 18:10:00', 4, 'A55'),
(158, 'AZ2695', '2019-12-20 18:10:00', '2019-12-20 18:10:00', 4, 'A55'),
(159, 'AF345', '2019-12-20 18:10:00', '2019-12-20 18:10:00', 4, 'A55'),
(160, 'DL8262', '2019-12-20 18:10:00', '2019-12-20 18:10:00', 4, 'A55'),
(161, 'AM7392', '2019-12-20 18:15:00', '2019-12-20 18:15:00', 4, 'A8'),
(162, 'VS8138', '2019-12-20 18:15:00', '2019-12-20 18:15:00', 4, 'A8'),
(163, 'DL5524', '2019-12-20 18:15:00', '2019-12-20 18:15:00', 4, 'C84'),
(164, 'AM4039', '2019-12-20 18:15:00', '2019-12-20 18:15:00', 4, 'C84'),
(165, 'KE3794', '2019-12-20 18:15:00', '2019-12-20 18:15:00', 4, 'C84'),
(166, 'WS7765', '2019-12-20 18:15:00', '2019-12-20 18:15:00', 4, 'C84'),
(167, 'DL5501', '2019-12-20 18:15:00', '2019-12-20 18:15:00', 4, 'C82'),
(168, 'WS3535', '2019-12-20 18:15:00', '2019-12-20 18:15:00', 4, 'A8'),
(169, 'WS7920', '2019-12-20 18:15:00', '2019-12-20 18:15:00', 4, 'C82'),
(170, 'PD481', '2019-12-20 18:15:00', '2019-12-20 18:15:00', 4, 'A12'),
(171, 'AC874', '2019-12-20 18:15:00', '2019-12-20 18:15:00', 4, 'A66'),
(172, 'YN922', '2019-12-19 17:50:00', '2019-12-19 17:50:00', 2, ''),
(173, 'TS761', '2019-12-19 17:00:00', '2019-12-19 17:00:00', 2, ''),
(174, 'LA6684', '2019-12-19 19:43:00', '2019-12-19 19:43:00', 2, 'CE9'),
(175, 'AA2702', '2019-12-19 19:43:00', '2019-12-19 19:43:00', 2, 'CE9'),
(176, 'WS6441', '2019-12-19 21:59:00', '2019-12-19 21:59:00', 2, 'DD9'),
(177, 'AC1615', '2019-12-19 20:15:00', '2019-12-19 20:15:00', 2, ''),
(178, 'DL5470', '2019-12-19 21:59:00', '2019-12-19 21:59:00', 2, 'DD9'),
(179, 'AC1568', '2019-12-19 17:50:00', '2019-12-19 17:50:00', 2, 'C50'),
(180, 'WS7924', '2019-12-19 21:15:00', '2019-12-19 21:15:00', 2, 'ID9A'),
(181, 'DL5455', '2019-12-19 21:15:00', '2019-12-19 21:15:00', 2, 'ID9A'),
(182, 'KE3793', '2019-12-19 21:15:00', '2019-12-19 21:15:00', 2, 'ID9A'),
(183, 'UA4979', '2019-12-19 22:10:00', '2019-12-19 22:10:00', 2, 'A5F'),
(184, 'AC3818', '2019-12-19 22:10:00', '2019-12-19 22:10:00', 2, 'A5F'),
(185, 'AV2164', '2019-12-19 22:10:00', '2019-12-19 22:10:00', 2, 'A5F'),
(186, 'AC1241', '2019-12-19 20:05:00', '2019-12-19 20:05:00', 2, '3'),
(187, 'TS705', '2019-12-19 21:10:00', '2019-12-19 21:10:00', 2, '80'),
(188, 'SWG309', '2019-12-19 20:40:00', '2019-12-19 20:40:00', 2, ''),
(189, 'CM422', '2019-12-19 18:36:00', '2019-12-19 18:36:00', 2, '1125'),
(190, 'CX1618', '2019-12-19 23:10:00', '2019-12-19 23:10:00', 2, '1'),
(191, 'OS8334', '2019-12-19 23:10:00', '2019-12-19 23:10:00', 2, '1'),
(192, 'TS531', '2019-12-19 20:35:00', '2019-12-19 20:35:00', 2, ''),
(193, 'BR3092', '2019-12-19 23:10:00', '2019-12-19 23:10:00', 2, '1'),
(194, 'AC430', '2019-12-19 23:10:00', '2019-12-19 23:10:00', 2, '1'),
(195, 'LO4127', '2019-12-19 23:10:00', '2019-12-19 23:10:00', 2, '1'),
(196, 'AV6952', '2019-12-19 21:10:00', '2019-12-19 21:10:00', 2, 'SJ5'),
(197, 'AC1653', '2019-12-19 21:10:00', '2019-12-19 21:10:00', 2, 'SJ5'),
(198, 'PR1934', '2019-12-19 23:15:00', '2019-12-19 23:15:00', 2, '3B25'),
(199, 'AC1609', '2019-12-19 21:20:00', '2019-12-19 21:20:00', 2, '2'),
(200, 'AF3001', '2019-12-19 23:15:00', '2019-12-19 23:15:00', 2, '3B25'),
(201, 'WS594', '2019-12-19 23:15:00', '2019-12-19 23:15:00', 2, '3B25'),
(202, 'LA5232', '2019-12-19 23:15:00', '2019-12-19 23:15:00', 2, '3B25'),
(203, 'AC8781', '2019-12-20 06:05:00', '2019-12-20 06:05:00', 2, ''),
(204, 'AC8970', '2019-12-20 06:18:00', '2019-12-20 06:18:00', 2, ''),
(205, 'AC8681', '2019-12-20 06:19:00', '2019-12-20 06:19:00', 2, ''),
(206, 'AC8701', '2019-12-20 06:24:00', '2019-12-20 06:24:00', 2, ''),
(207, 'AC8015', '2019-12-20 06:30:00', '2019-12-20 06:30:00', 2, ''),
(208, 'AC8512', '2019-12-20 06:46:00', '2019-12-20 06:46:00', 2, ''),
(209, 'UA8193', '2019-12-20 06:46:00', '2019-12-20 06:46:00', 2, ''),
(210, 'AC8901', '2019-12-20 06:52:00', '2019-12-20 06:52:00', 2, ''),
(212, 'AC396', '2019-12-20 07:10:00', '2019-12-20 07:10:00', 2, ''),
(213, 'AC661', '2019-12-20 07:10:00', '2019-12-20 07:10:00', 2, ''),
(214, 'AC1558', '2019-12-20 07:10:00', '2019-12-20 07:10:00', 2, ''),
(215, 'NZ4542', '2019-12-20 07:12:00', '2019-12-20 07:12:00', 2, ''),
(216, 'CX1510', '2019-12-20 07:12:00', '2019-12-20 07:12:00', 2, ''),
(217, 'AC308', '2019-12-20 07:12:00', '2019-12-20 07:12:00', 2, ''),
(218, 'UA8290', '2019-12-20 07:13:00', '2019-12-20 07:13:00', 2, ''),
(219, 'AC1858', '2019-12-20 07:13:00', '2019-12-20 07:13:00', 2, ''),
(220, 'ASP822', '2019-12-20 07:15:00', '2019-12-20 07:15:00', 2, ''),
(221, 'WS6105', '2019-12-20 07:25:00', '2019-12-20 07:25:00', 2, '61'),
(222, 'PD452', '2019-12-20 07:25:00', '2019-12-20 07:25:00', 2, 'A7'),
(223, 'AM680', '2019-12-20 07:25:00', '2019-12-20 07:25:00', 2, '61'),
(224, 'AC480', '2019-12-20 07:35:00', '2019-12-20 07:35:00', 2, ''),
(225, 'UA8123', '2019-12-20 07:41:00', '2019-12-20 07:41:00', 2, ''),
(226, 'AC8455', '2019-12-20 07:41:00', '2019-12-20 07:41:00', 2, ''),
(227, 'WS3514', '2019-12-20 07:52:00', '2019-12-20 07:52:00', 2, 'A6'),
(228, 'AM7290', '2019-12-20 07:52:00', '2019-12-20 07:52:00', 2, 'A6'),
(229, 'AC8703', '2019-12-20 07:54:00', '2019-12-20 07:54:00', 2, ''),
(230, 'PD453', '2019-12-20 07:55:00', '2019-12-20 07:55:00', 2, 'A7'),
(231, 'UA8149', '2019-12-20 08:00:00', '2019-12-20 08:00:00', 2, ''),
(232, 'AC7737', '2019-12-20 08:00:00', '2019-12-20 08:00:00', 2, ''),
(233, 'QUE10', '2019-12-21 02:50:00', '2019-12-21 02:50:00', 2, ''),
(234, 'AC8831', '2019-12-21 05:30:00', '2019-12-21 05:30:00', 2, 'A15'),
(235, 'DL5520', '2019-12-21 05:35:00', '2019-12-21 05:35:00', 2, 'C88'),
(236, 'AM3523', '2019-12-21 05:35:00', '2019-12-21 05:35:00', 2, 'C88'),
(237, 'WS7922', '2019-12-21 05:35:00', '2019-12-21 05:35:00', 2, 'C88'),
(238, 'SWG710', '2019-12-21 05:45:00', '2019-12-21 05:45:00', 2, 'A55'),
(239, 'DL5479', '2019-12-21 05:52:00', '2019-12-21 05:52:00', 2, 'C87'),
(240, 'KE3836', '2019-12-21 05:52:00', '2019-12-21 05:52:00', 2, 'C87'),
(241, 'VS3788', '2019-12-21 05:52:00', '2019-12-21 05:52:00', 2, 'C87'),
(242, 'WS6446', '2019-12-21 05:52:00', '2019-12-21 05:52:00', 2, 'C87'),
(243, 'AC481', '2019-12-21 06:00:00', '2019-12-21 06:00:00', 2, 'A47'),
(244, 'OS8390', '2019-12-21 06:00:00', '2019-12-21 06:00:00', 2, 'A47'),
(245, 'AA3981', '2019-12-21 06:00:00', '2019-12-21 06:00:00', 4, 'C83'),
(246, 'LA6634', '2019-12-21 06:00:00', '2019-12-21 06:00:00', 2, 'C81'),
(247, 'AC1600', '2019-12-21 06:00:00', '2019-12-21 06:00:00', 2, 'C60'),
(248, 'UA8705', '2019-12-21 06:00:00', '2019-12-21 06:00:00', 2, 'C60'),
(249, 'TS2486', '2019-12-21 06:00:00', '2019-12-21 06:00:00', 1, 'A63'),
(250, 'SWG414', '2019-12-21 06:00:00', '2019-12-21 06:00:00', 2, 'A61'),
(251, 'SWG688', '2019-12-21 06:00:00', '2019-12-21 06:00:00', 2, 'A57'),
(252, 'WS3513', '2019-12-21 06:00:00', '2019-12-21 06:00:00', 2, 'A4'),
(253, 'AM7322', '2019-12-21 06:00:00', '2019-12-21 06:00:00', 2, 'A4'),
(254, 'DL7204', '2019-12-21 06:00:00', '2019-12-21 06:00:00', 2, 'A4'),
(255, 'KE6528', '2019-12-21 06:00:00', '2019-12-21 06:00:00', 2, 'A4'),
(256, 'LA5224', '2019-12-21 06:00:00', '2019-12-21 06:00:00', 2, 'A4'),
(257, 'QF3430', '2019-12-21 06:00:00', '2019-12-21 06:00:00', 2, 'A4'),
(258, 'AA1516', '2019-12-21 06:00:00', '2019-12-21 06:00:00', 2, 'C81'),
(259, 'SWG792', '2019-12-21 06:00:00', '2019-12-21 06:00:00', 2, 'A59'),
(260, 'AC426', '2019-12-20 21:45:00', '2019-12-20 21:45:00', 2, ''),
(261, 'OZ6115', '2019-12-20 21:45:00', '2019-12-20 21:45:00', 2, ''),
(262, 'AA4127', '2019-12-20 22:57:00', '2019-12-20 22:57:00', 2, ''),
(263, 'AC1568', '2019-12-20 23:50:00', '2019-12-20 23:50:00', 2, ''),
(264, 'AM5564', '2019-12-20 23:55:00', '2019-12-20 23:55:00', 2, 'C87'),
(265, 'DL5455', '2019-12-20 23:55:00', '2019-12-20 23:55:00', 2, 'C87'),
(266, 'KE3793', '2019-12-20 23:55:00', '2019-12-20 23:55:00', 2, 'C87'),
(267, 'WS7924', '2019-12-20 23:55:00', '2019-12-20 23:55:00', 2, 'C87'),
(268, 'AC1241', '2019-12-21 00:10:00', '2019-12-21 00:10:00', 4, ''),
(269, 'CX1618', '2019-12-21 00:25:00', '2019-12-21 00:25:00', 2, ''),
(270, 'LO4127', '2019-12-21 00:25:00', '2019-12-21 00:25:00', 2, ''),
(271, 'AC430', '2019-12-21 00:25:00', '2019-12-21 00:25:00', 2, ''),
(272, 'OS8334', '2019-12-21 00:25:00', '2019-12-21 00:25:00', 2, ''),
(273, 'BR3092', '2019-12-21 00:25:00', '2019-12-21 00:25:00', 2, ''),
(274, 'SWG477', '2019-12-21 00:30:00', '2019-12-21 00:30:00', 2, ''),
(275, 'AC1653', '2019-12-21 00:31:00', '2019-12-21 00:31:00', 2, ''),
(276, 'AV6952', '2019-12-21 00:31:00', '2019-12-21 00:31:00', 2, ''),
(277, 'QF3431', '2019-12-21 00:35:00', '2019-12-21 00:35:00', 2, 'A6'),
(278, 'DL7194', '2019-12-21 00:35:00', '2019-12-21 00:35:00', 2, 'A6'),
(279, 'CX7098', '2019-12-21 00:35:00', '2019-12-21 00:35:00', 2, 'A6'),
(280, 'WS594', '2019-12-21 00:35:00', '2019-12-21 00:35:00', 2, 'A6'),
(281, 'AC1751', '2019-12-21 00:35:00', '2019-12-21 00:35:00', 2, ''),
(282, 'PR1934', '2019-12-21 00:35:00', '2019-12-21 00:35:00', 2, 'A6'),
(283, 'LA5208', '2019-12-21 00:35:00', '2019-12-21 00:35:00', 2, 'A6'),
(284, 'AC1609', '2019-12-21 00:35:00', '2019-12-21 00:35:00', 2, ''),
(285, 'UA8693', '2019-12-21 00:35:00', '2019-12-21 00:35:00', 2, ''),
(286, 'S47029', '2019-12-21 00:35:00', '2019-12-21 00:35:00', 2, 'A6'),
(287, 'AC1747', '2019-12-21 00:40:00', '2019-12-21 00:40:00', 2, ''),
(288, 'TS2555', '2019-12-21 00:40:00', '2019-12-21 00:40:00', 2, ''),
(289, 'CA7469', '2019-12-21 00:43:00', '2019-12-21 00:43:00', 2, ''),
(290, 'CX1508', '2019-12-21 00:43:00', '2019-12-21 00:43:00', 2, ''),
(291, 'AC8781', '2019-12-21 06:05:00', '2019-12-21 06:05:00', 2, ''),
(292, 'AC8970', '2019-12-21 06:18:00', '2019-12-21 06:18:00', 2, ''),
(293, 'AC8681', '2019-12-21 06:19:00', '2019-12-21 06:19:00', 2, ''),
(294, 'AC8701', '2019-12-21 06:24:00', '2019-12-21 06:24:00', 2, ''),
(295, 'CA7538', '2019-12-21 06:30:00', '2019-12-21 06:30:00', 2, ''),
(296, 'AC8015', '2019-12-21 06:30:00', '2019-12-21 06:30:00', 2, ''),
(297, 'AC8512', '2019-12-21 06:46:00', '2019-12-21 06:46:00', 2, ''),
(298, 'UA8193', '2019-12-21 06:46:00', '2019-12-21 06:46:00', 2, ''),
(299, 'AC8901', '2019-12-21 06:52:00', '2019-12-21 06:52:00', 2, ''),
(301, 'AC1558', '2019-12-21 07:10:00', '2019-12-21 07:10:00', 2, ''),
(302, 'AC396', '2019-12-21 07:10:00', '2019-12-21 07:10:00', 2, ''),
(303, 'CX1510', '2019-12-21 07:12:00', '2019-12-21 07:12:00', 2, ''),
(304, 'AC308', '2019-12-21 07:12:00', '2019-12-21 07:12:00', 2, ''),
(305, 'NZ4542', '2019-12-21 07:12:00', '2019-12-21 07:12:00', 2, ''),
(306, 'UA8290', '2019-12-21 07:13:00', '2019-12-21 07:13:00', 2, ''),
(307, 'CA7528', '2019-12-21 07:13:00', '2019-12-21 07:13:00', 2, ''),
(308, 'AC1858', '2019-12-21 07:13:00', '2019-12-21 07:13:00', 2, ''),
(309, 'AC1545', '2019-12-21 07:13:00', '2019-12-21 07:13:00', 2, ''),
(310, 'PD452', '2019-12-21 07:25:00', '2019-12-21 07:25:00', 2, 'A6'),
(311, 'AM680', '2019-12-21 07:25:00', '2019-12-21 07:25:00', 2, '61'),
(312, 'WS6105', '2019-12-21 07:25:00', '2019-12-21 07:25:00', 2, '61'),
(313, 'AC480', '2019-12-21 07:35:00', '2019-12-21 07:35:00', 2, ''),
(314, 'UA8123', '2019-12-21 07:41:00', '2019-12-21 07:41:00', 2, ''),
(315, 'AC8455', '2019-12-21 07:41:00', '2019-12-21 07:41:00', 2, ''),
(316, 'AC8703', '2019-12-21 07:54:00', '2019-12-21 07:54:00', 2, ''),
(317, 'CA7526', '2019-12-21 07:54:00', '2019-12-21 07:54:00', 2, ''),
(318, 'PD453', '2019-12-21 07:55:00', '2019-12-21 07:55:00', 2, 'A12'),
(319, 'UA8149', '2019-12-21 08:00:00', '2019-12-21 08:00:00', 2, ''),
(320, 'AC7737', '2019-12-21 08:00:00', '2019-12-21 08:00:00', 2, ''),
(321, 'AC8750', '2019-12-21 08:04:00', '2019-12-21 08:04:00', 2, '');

-- --------------------------------------------------------

--
-- Table structure for table `volgeneriques`
--

CREATE TABLE `volgeneriques` (
  `VolGeneriqueId` varchar(10) CHARACTER SET utf16 COLLATE utf16_general_ci NOT NULL,
  `AeroportId` varchar(5) CHARACTER SET utf16 COLLATE utf16_general_ci NOT NULL,
  `CompagnieId` varchar(5) CHARACTER SET utf16 COLLATE utf16_general_ci NOT NULL,
  `HeurePrevue` datetime NOT NULL DEFAULT '0001-01-01 00:00:00',
  `Direction` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf16;

--
-- Dumping data for table `volgeneriques`
--

INSERT INTO `volgeneriques` (`VolGeneriqueId`, `AeroportId`, `CompagnieId`, `HeurePrevue`, `Direction`) VALUES
('AA1516', 'MIA', 'AA', '0001-01-01 06:00:00', 0),
('AA2702', 'YUL', 'AA', '0001-01-01 19:43:00', 1),
('AA3102', 'ORD', 'AA', '0001-01-01 12:22:00', 0),
('AA3981', 'DFW', 'AA', '0001-01-01 06:00:00', 0),
('AA3989', 'LGA', 'AA', '0001-01-01 09:44:00', 0),
('AA4127', 'LGA', 'AA', '0001-01-01 22:57:00', 1),
('AA4845', 'PHL', 'AA', '0001-01-01 17:40:00', 0),
('AA5702', 'CLT', 'AA', '0001-01-01 07:15:00', 0),
('AC1241', 'YUL', 'AC', '0001-01-01 20:05:00', 1),
('AC1545', 'YHZ', 'AC', '0001-01-01 07:13:00', 1),
('AC1558', 'YEG', 'AC', '0001-01-01 07:10:00', 1),
('AC1568', 'YUL', 'AC', '0001-01-01 17:50:00', 1),
('AC1589', 'YEG', 'AC', '0001-01-01 07:55:00', 0),
('AC1600', 'FLL', 'AC', '0001-01-01 06:00:00', 0),
('AC1609', 'YUL', 'AC', '0001-01-01 21:20:00', 1),
('AC1615', 'YUL', 'AC', '0001-01-01 20:15:00', 1),
('AC1618', 'TPA', 'AC', '0001-01-01 07:10:00', 0),
('AC1634', 'MCO', 'AC', '0001-01-01 07:50:00', 0),
('AC1650', 'MIA', 'AC', '0001-01-01 07:40:00', 0),
('AC1653', 'YUL', 'AC', '0001-01-01 21:10:00', 1),
('AC1710', 'ZIH', 'AC', '0001-01-01 07:20:00', 0),
('AC1724', 'BGI', 'AC', '0001-01-01 07:50:00', 0),
('AC1726', 'PTP', 'AC', '0001-01-01 08:35:00', 0),
('AC1744', 'AZS', 'AC', '0001-01-01 08:15:00', 0),
('AC1747', 'VRA', 'AC', '0001-01-01 00:40:00', 1),
('AC1751', 'CCC', 'AC', '0001-01-01 00:35:00', 1),
('AC1824', 'NAS', 'AC', '0001-01-01 09:40:00', 0),
('AC1855', 'LAS', 'AC', '0001-01-01 08:40:00', 0),
('AC1858', 'LAS', 'AC', '0001-01-01 07:13:00', 1),
('AC1986', 'PUJ', 'AC', '0001-01-01 07:00:00', 0),
('AC2008', 'CMN', 'AC', '0001-01-01 18:00:00', 0),
('AC2426', 'CUN', 'AC', '0001-01-01 11:00:00', 0),
('AC2436', 'SJO', 'AC', '0001-01-01 07:05:00', 0),
('AC301', 'YVR', 'AC', '0001-01-01 07:15:00', 0),
('AC307', 'YVR', 'AC', '0001-01-01 10:00:00', 0),
('AC308', 'YVR', 'AC', '0001-01-01 07:12:00', 1),
('AC319', 'YYC', 'AC', '0001-01-01 07:20:00', 0),
('AC371', 'YWG', 'AC', '0001-01-01 08:00:00', 0),
('AC3818', 'YUL', 'AC', '0001-01-01 22:10:00', 1),
('AC396', 'YYC', 'AC', '0001-01-01 07:10:00', 1),
('AC401', 'YYZ', 'AC', '0001-01-01 07:00:00', 0),
('AC403', 'YYZ', 'AC', '0001-01-01 08:00:00', 0),
('AC405', 'YYZ', 'AC', '0001-01-01 09:00:00', 0),
('AC407', 'YYZ', 'AC', '0001-01-01 10:00:00', 0),
('AC411', 'YYZ', 'AC', '0001-01-01 12:00:00', 0),
('AC423', 'YYZ', 'AC', '0001-01-01 18:00:00', 0),
('AC426', 'YYZ', 'AC', '0001-01-01 21:45:00', 1),
('AC430', 'YUL', 'AC', '0001-01-01 23:10:00', 1),
('AC4594', 'EWR', 'AC', '0001-01-01 06:33:00', 0),
('AC480', 'YYZ', 'AC', '0001-01-01 07:35:00', 1),
('AC481', 'YYZ', 'AC', '0001-01-01 06:00:00', 0),
('AC485', 'YYZ', 'AC', '0001-01-01 06:30:00', 0),
('AC4927', 'IAD', 'AC', '0001-01-01 09:30:00', 0),
('AC661', 'YHZ', 'AC', '0001-01-01 07:10:00', 1),
('AC7591', 'ORD', 'AC', '0001-01-01 08:40:00', 0),
('AC7630', 'LGA', 'AC', '0001-01-01 06:30:00', 0),
('AC7632', 'LGA', 'AC', '0001-01-01 08:45:00', 0),
('AC7634', 'LGA', 'AC', '0001-01-01 10:45:00', 0),
('AC7640', 'LGA', 'AC', '0001-01-01 17:45:00', 0),
('AC7703', 'IAH', 'AC', '0001-01-01 07:50:00', 0),
('AC7737', 'EWR', 'AC', '0001-01-01 08:00:00', 1),
('AC7953', 'YTZ', 'AC', '0001-01-01 07:30:00', 0),
('AC7955', 'YTZ', 'AC', '0001-01-01 08:30:00', 0),
('AC7963', 'YTZ', 'AC', '0001-01-01 12:30:00', 0),
('AC797', 'LAX', 'AC', '0001-01-01 07:00:00', 0),
('AC7991', 'DEN', 'AC', '0001-01-01 07:45:00', 0),
('AC8014', 'YYT', 'AC', '0001-01-01 12:45:00', 0),
('AC8015', 'YYT', 'AC', '0001-01-01 06:30:00', 1),
('AC808', 'CMN', 'AC', '0001-01-01 19:10:00', 0),
('AC8454', 'BOS', 'AC', '0001-01-01 08:30:00', 0),
('AC8455', 'BOS', 'AC', '0001-01-01 07:41:00', 1),
('AC8500', 'YFC', 'AC', '0001-01-01 08:15:00', 0),
('AC8506', 'YFC', 'AC', '0001-01-01 21:20:00', 0),
('AC8511', 'YYG', 'AC', '0001-01-01 07:55:00', 0),
('AC8512', 'YYG', 'AC', '0001-01-01 06:46:00', 1),
('AC864', 'LHR', 'AC', '0001-01-01 19:50:00', 0),
('AC8671', 'YOW', 'AC', '0001-01-01 07:30:00', 0),
('AC8681', 'YBG', 'AC', '0001-01-01 06:19:00', 1),
('AC8682', 'YBG', 'AC', '0001-01-01 09:20:00', 0),
('AC8686', 'YBG', 'AC', '0001-01-01 20:45:00', 0),
('AC8701', 'YQB', 'AC', '0001-01-01 06:24:00', 1),
('AC8703', 'YQB', 'AC', '0001-01-01 07:54:00', 1),
('AC8704', 'YQB', 'AC', '0001-01-01 08:15:00', 0),
('AC8708', 'YQB', 'AC', '0001-01-01 10:00:00', 0),
('AC8712', 'YQB', 'AC', '0001-01-01 12:30:00', 0),
('AC8726', 'YQB', 'AC', '0001-01-01 18:00:00', 0),
('AC8732', 'YQB', 'AC', '0001-01-01 21:50:00', 0),
('AC874', 'FRA', 'AC', '0001-01-01 18:15:00', 0),
('AC8750', 'YVO', 'AC', '0001-01-01 08:04:00', 1),
('AC8751', 'YVO', 'AC', '0001-01-01 07:15:00', 0),
('AC8753', 'YVO', 'AC', '0001-01-01 17:50:00', 0),
('AC8781', 'YHZ', 'AC', '0001-01-01 06:05:00', 1),
('AC8784', 'YHZ', 'AC', '0001-01-01 08:15:00', 0),
('AC8831', 'YYZ', 'AC', '0001-01-01 05:30:00', 0),
('AC8900', 'YQM', 'AC', '0001-01-01 07:40:00', 0),
('AC8901', 'YQM', 'AC', '0001-01-01 06:52:00', 1),
('AC8960', 'YBC', 'AC', '0001-01-01 08:00:00', 0),
('AC8970', 'YOW', 'AC', '0001-01-01 06:18:00', 1),
('AC8978', 'YZV', 'AC', '0001-01-01 08:15:00', 0),
('AC8985', 'YOW', 'AC', '0001-01-01 17:45:00', 0),
('AC912', 'FLL', 'AC', '0001-01-01 08:05:00', 0),
('AC958', 'SJU', 'AC', '0001-01-01 09:15:00', 0),
('AF2116', 'DTW', 'AF', '0001-01-01 12:40:00', 0),
('AF3001', 'YUL', 'AF', '0001-01-01 23:15:00', 1),
('AF345', 'CDG', 'AF', '0001-01-01 18:10:00', 0),
('AF8875', 'JFK', 'AF', '0001-01-01 12:04:00', 0),
('AI7306', 'LHR', 'AI', '0001-01-01 19:50:00', 0),
('AM3125', 'ATL', 'AM', '0001-01-01 05:35:00', 0),
('AM3523', 'ATL', 'AM', '0001-01-01 05:35:00', 0),
('AM3609', 'ATL', 'AM', '0001-01-01 07:15:00', 0),
('AM3616', 'DTW', 'AM', '0001-01-01 06:50:00', 0),
('AM4012', 'MSP', 'AM', '0001-01-01 05:50:00', 0),
('AM4039', 'ATL', 'AM', '0001-01-01 18:15:00', 0),
('AM4240', 'ATL', 'AM', '0001-01-01 12:43:00', 0),
('AM5564', 'ATL', 'AM', '0001-01-01 23:55:00', 1),
('AM680', 'MEX', 'AM', '0001-01-01 07:25:00', 1),
('AM681', 'MEX', 'AM', '0001-01-01 09:01:00', 0),
('AM7137', 'YHZ', 'AM', '0001-01-01 10:00:00', 0),
('AM7290', 'YYZ', 'AM', '0001-01-01 07:52:00', 1),
('AM7322', 'YYZ', 'AM', '0001-01-01 06:00:00', 0),
('AM7366', 'YYZ', 'AM', '0001-01-01 10:15:00', 0),
('AM7392', 'YYZ', 'AM', '0001-01-01 18:15:00', 0),
('AS4367', 'ORD', 'AS', '0001-01-01 12:22:00', 0),
('ASP567', 'ROC', 'ASP', '0001-01-01 10:30:00', 0),
('ASP822', 'BWI', 'ASP', '0001-01-01 08:00:00', 0),
('AT207', 'CMN', 'AT', '0001-01-01 11:25:00', 0),
('AV2164', 'YUL', 'AV', '0001-01-01 22:10:00', 1),
('AV2167', 'IAD', 'AV', '0001-01-01 09:30:00', 0),
('AV6907', 'YYZ', 'AV', '0001-01-01 10:00:00', 0),
('AV6917', 'YYZ', 'AV', '0001-01-01 12:00:00', 0),
('AV6951', 'MIA', 'AV', '0001-01-01 07:40:00', 0),
('AV6952', 'YUL', 'AV', '0001-01-01 21:10:00', 1),
('AZ2695', 'CDG', 'AZ', '0001-01-01 18:10:00', 0),
('AZ5851', 'JFK', 'AZ', '0001-01-01 12:04:00', 0),
('BR3092', 'YUL', 'BR', '0001-01-01 23:10:00', 1),
('CA7468', 'YVR', 'CA', '0001-01-01 07:15:00', 0),
('CA7469', 'YVR', 'CA', '0001-01-01 00:43:00', 1),
('CA7499', 'YOW', 'CA', '0001-01-01 17:45:00', 0),
('CA7525', 'YQB', 'CA', '0001-01-01 18:00:00', 0),
('CA7526', 'YQB', 'CA', '0001-01-01 07:54:00', 1),
('CA7528', 'YHZ', 'CA', '0001-01-01 07:13:00', 1),
('CA7538', 'YYT', 'CA', '0001-01-01 06:30:00', 1),
('CM422', 'YUL', 'CM', '0001-01-01 18:36:00', 1),
('CX1508', 'YVR', 'CX', '0001-01-01 00:43:00', 1),
('CX1509', 'YVR', 'CX', '0001-01-01 07:15:00', 0),
('CX1510', 'YVR', 'CX', '0001-01-01 07:12:00', 1),
('CX1618', 'YUL', 'CX', '0001-01-01 23:10:00', 1),
('CX7098', 'YYZ', 'CX', '0001-01-01 00:35:00', 1),
('DL5455', 'YUL', 'DL', '0001-01-01 21:15:00', 1),
('DL5470', 'YUL', 'DL', '0001-01-01 21:59:00', 1),
('DL5479', 'MSP', 'DL', '0001-01-01 05:50:00', 0),
('DL5497', 'DTW', 'DL', '0001-01-01 06:50:00', 0),
('DL5498', 'DTW', 'DL', '0001-01-01 12:40:00', 0),
('DL5501', 'DTW', 'DL', '0001-01-01 18:15:00', 0),
('DL5517', 'JFK', 'DL', '0001-01-01 12:04:00', 0),
('DL5520', 'ATL', 'DL', '0001-01-01 05:35:00', 0),
('DL5522', 'ATL', 'DL', '0001-01-01 07:15:00', 0),
('DL5524', 'ATL', 'DL', '0001-01-01 18:15:00', 0),
('DL5525', 'ATL', 'DL', '0001-01-01 12:43:00', 0),
('DL7194', 'YYZ', 'DL', '0001-01-01 00:35:00', 1),
('DL7197', 'YYZ', 'DL', '0001-01-01 07:00:00', 0),
('DL7204', 'YYZ', 'DL', '0001-01-01 06:00:00', 0),
('DL7580', 'YYZ', 'DL', '0001-01-01 10:15:00', 0),
('DL8262', 'CDG', 'DL', '0001-01-01 18:10:00', 0),
('EK4690', 'YYZ', 'EK', '0001-01-01 07:00:00', 0),
('EY3859', 'YYZ', 'EY', '0001-01-01 18:00:00', 0),
('G38314', 'ATL', 'G3', '0001-01-01 12:43:00', 0),
('G38326', 'ATL', 'G3', '0001-01-01 07:15:00', 0),
('G38340', 'JFK', 'G3', '0001-01-01 12:04:00', 0),
('HU8697', 'YYZ', 'HU', '0001-01-01 10:15:00', 0),
('IB4284', 'ORD', 'IB', '0001-01-01 12:22:00', 0),
('KE3362', 'DTW', 'KE', '0001-01-01 06:50:00', 0),
('KE3771', 'ATL', 'KE', '0001-01-01 07:15:00', 0),
('KE3793', 'YUL', 'KE', '0001-01-01 21:15:00', 1),
('KE3794', 'ATL', 'KE', '0001-01-01 18:15:00', 0),
('KE3836', 'MSP', 'KE', '0001-01-01 05:50:00', 0),
('KE6528', 'YYZ', 'KE', '0001-01-01 06:00:00', 0),
('KE6530', 'YYZ', 'KE', '0001-01-01 06:00:00', 0),
('KE7379', 'JFK', 'KE', '0001-01-01 12:04:00', 0),
('KL2389', 'CDG', 'KL', '0001-01-01 18:10:00', 0),
('KL5585', 'JFK', 'KL', '0001-01-01 12:04:00', 0),
('KL7123', 'DTW', 'KL', '0001-01-01 12:40:00', 0),
('LA5208', 'YYZ', 'LA', '0001-01-01 00:35:00', 1),
('LA5212', 'YYZ', 'LA', '0001-01-01 07:00:00', 0),
('LA5218', 'YYZ', 'LA', '0001-01-01 06:00:00', 0),
('LA5224', 'YYZ', 'LA', '0001-01-01 06:00:00', 0),
('LA5232', 'YUL', 'LA', '0001-01-01 23:15:00', 1),
('LA6634', 'MIA', 'LA', '0001-01-01 06:00:00', 0),
('LA6684', 'YUL', 'LA', '0001-01-01 19:43:00', 1),
('LH6839', 'LHR', 'LH', '0001-01-01 19:50:00', 0),
('LO4127', 'YUL', 'LO', '0001-01-01 23:10:00', 1),
('LX4652', 'YQB', 'LX', '0001-01-01 18:00:00', 0),
('LX4684', 'YOW', 'LX', '0001-01-01 17:45:00', 0),
('LXJ450', 'SUA', 'LXJ', '0001-01-01 09:30:00', 0),
('ME4345', 'CDG', 'ME', '0001-01-01 18:10:00', 0),
('ME4506', 'LHR', 'ME', '0001-01-01 19:50:00', 0),
('MS9601', 'LHR', 'MS', '0001-01-01 19:50:00', 0),
('MS9603', 'YYZ', 'MS', '0001-01-01 09:00:00', 0),
('MS9607', 'YYZ', 'MS', '0001-01-01 10:00:00', 0),
('MS9621', 'YYZ', 'MS', '0001-01-01 07:00:00', 0),
('MS9623', 'YYZ', 'MS', '0001-01-01 08:00:00', 0),
('MU8034', 'YYZ', 'MU', '0001-01-01 10:15:00', 0),
('N5*480', 'TEB', 'N5*', '0001-01-01 09:00:00', 0),
('NDL654', 'BTV', 'NDL', '0001-01-01 08:45:00', 0),
('NH6819', 'YVR', 'NH', '0001-01-01 10:00:00', 0),
('NZ4542', 'YVR', 'NZ', '0001-01-01 07:12:00', 1),
('NZ4741', 'YVR', 'NZ', '0001-01-01 07:15:00', 0),
('NZ4767', 'YVR', 'NZ', '0001-01-01 10:00:00', 0),
('NZ4787', 'LAX', 'NZ', '0001-01-01 07:00:00', 0),
('OS8240', 'LHR', 'OS', '0001-01-01 19:50:00', 0),
('OS8334', 'YUL', 'OS', '0001-01-01 23:10:00', 1),
('OS8390', 'YYZ', 'OS', '0001-01-01 06:00:00', 0),
('OS8396', 'YYZ', 'OS', '0001-01-01 18:00:00', 0),
('OZ6105', 'YVR', 'OZ', '0001-01-01 07:15:00', 0),
('OZ6115', 'YYZ', 'OZ', '0001-01-01 21:45:00', 1),
('OZ6116', 'YYZ', 'OZ', '0001-01-01 08:00:00', 0),
('OZ6124', 'YYZ', 'OZ', '0001-01-01 07:00:00', 0),
('PB920', 'YQB', 'PB', '0001-01-01 07:40:00', 0),
('PD450', 'YTZ', 'PD', '0001-01-01 06:30:00', 0),
('PD452', 'YHZ', 'PD', '0001-01-01 07:25:00', 1),
('PD453', 'YTZ', 'PD', '0001-01-01 07:55:00', 1),
('PD460', 'YTZ', 'PD', '0001-01-01 10:10:00', 0),
('PD466', 'YTZ', 'PD', '0001-01-01 12:15:00', 0),
('PD481', 'YHZ', 'PD', '0001-01-01 18:15:00', 0),
('PR1934', 'YUL', 'PR', '0001-01-01 23:15:00', 1),
('QF3332', 'ORD', 'QF', '0001-01-01 12:22:00', 0),
('QF3430', 'YYZ', 'QF', '0001-01-01 06:00:00', 0),
('QF3431', 'YYZ', 'QF', '0001-01-01 00:35:00', 1),
('QF3975', 'YYZ', 'QF', '0001-01-01 06:00:00', 0),
('QUE10', 'YQB', 'QUE', '0001-01-01 02:20:00', 0),
('S47029', 'YYZ', 'S4', '0001-01-01 00:35:00', 1),
('SA7317', 'LHR', 'SA', '0001-01-01 19:50:00', 0),
('SN9605', 'YQB', 'SN', '0001-01-01 12:30:00', 0),
('SWG248', 'CCC', 'SWG', '0001-01-01 06:00:00', 0),
('SWG258', 'SNU', 'SWG', '0001-01-01 06:00:00', 0),
('SWG309', 'YUL', 'SWG', '0001-01-01 20:40:00', 1),
('SWG408', 'LRM', 'SWG', '0001-01-01 06:00:00', 0),
('SWG414', 'POP', 'SWG', '0001-01-01 06:00:00', 0),
('SWG424', 'PUJ', 'SWG', '0001-01-01 08:00:00', 0),
('SWG477', 'VRA', 'SWG', '0001-01-01 00:30:00', 1),
('SWG519', 'CUN', 'SWG', '0001-01-01 09:30:00', 0),
('SWG638', 'HOG', 'SWG', '0001-01-01 06:00:00', 0),
('SWG652', 'VRA', 'SWG', '0001-01-01 06:00:00', 0),
('SWG688', 'VRA', 'SWG', '0001-01-01 06:00:00', 0),
('SWG710', 'FPO', 'SWG', '0001-01-01 05:45:00', 0),
('SWG754', 'UVF', 'SWG', '0001-01-01 06:45:00', 0),
('SWG792', 'MBJ', 'SWG', '0001-01-01 06:00:00', 0),
('SWG86', 'MIA', 'SWG', '0001-01-01 08:00:00', 0),
('TK8640', 'YQM', 'TK', '0001-01-01 07:40:00', 0),
('TK9102', 'YYC', 'TK', '0001-01-01 07:20:00', 0),
('TK9108', 'YHZ', 'TK', '0001-01-01 08:15:00', 0),
('TK9128', 'YVO', 'TK', '0001-01-01 07:15:00', 0),
('TK9130', 'YZV', 'TK', '0001-01-01 08:15:00', 0),
('TP8263', 'LHR', 'TP', '0001-01-01 19:50:00', 0),
('TS128', 'POP', 'TS', '0001-01-01 09:00:00', 0),
('TS138', 'SNU', 'TS', '0001-01-01 10:00:00', 0),
('TS198', 'CTG', 'TS', '0001-01-01 08:05:00', 0),
('TS216', 'AZS', 'TS', '0001-01-01 06:00:00', 0),
('TS2486', 'MBJ', 'TS', '0001-01-01 06:00:00', 0),
('TS2555', 'CYO', 'TS', '0001-01-01 00:40:00', 1),
('TS288', 'SXM', 'TS', '0001-01-01 10:45:00', 0),
('TS342', 'PVR', 'TS', '0001-01-01 07:30:00', 0),
('TS398', 'PUJ', 'TS', '0001-01-01 08:50:00', 0),
('TS531', 'YUL', 'TS', '0001-01-01 20:35:00', 1),
('TS560', 'CUN', 'TS', '0001-01-01 09:30:00', 0),
('TS586', 'SDQ', 'TS', '0001-01-01 06:20:00', 0),
('TS705', 'YUL', 'TS', '0001-01-01 21:10:00', 1),
('TS761', 'YUL', 'TS', '0001-01-01 17:00:00', 1),
('TS902', 'MBJ', 'TS', '0001-01-01 06:00:00', 0),
('TS938', 'MCO', 'TS', '0001-01-01 07:15:00', 0),
('TS942', 'FLL', 'TS', '0001-01-01 07:25:00', 0),
('TS962', 'FDF', 'TS', '0001-01-01 07:15:00', 0),
('TU203', 'TUN', 'TU', '0001-01-01 15:15:00', 0),
('UA4341', 'EWR', 'UA', '0001-01-01 06:33:00', 0),
('UA4956', 'IAD', 'UA', '0001-01-01 09:30:00', 0),
('UA4961', 'EWR', 'UA', '0001-01-01 10:48:00', 0),
('UA4979', 'YUL', 'UA', '0001-01-01 22:10:00', 1),
('UA8123', 'BOS', 'UA', '0001-01-01 07:41:00', 1),
('UA8149', 'EWR', 'UA', '0001-01-01 08:00:00', 1),
('UA8164', 'YFC', 'UA', '0001-01-01 21:20:00', 0),
('UA8171', 'LAS', 'UA', '0001-01-01 08:40:00', 0),
('UA8180', 'LGA', 'UA', '0001-01-01 06:30:00', 0),
('UA8182', 'LGA', 'UA', '0001-01-01 08:45:00', 0),
('UA8193', 'YYG', 'UA', '0001-01-01 06:46:00', 1),
('UA8290', 'LAS', 'UA', '0001-01-01 07:13:00', 1),
('UA8296', 'LHR', 'UA', '0001-01-01 19:50:00', 0),
('UA8347', 'LAX', 'UA', '0001-01-01 07:00:00', 0),
('UA8371', 'ORD', 'UA', '0001-01-01 08:40:00', 0),
('UA8416', 'BOS', 'UA', '0001-01-01 08:30:00', 0),
('UA8625', 'LGA', 'UA', '0001-01-01 10:45:00', 0),
('UA8644', 'FLL', 'UA', '0001-01-01 08:05:00', 0),
('UA8647', 'CMN', 'UA', '0001-01-01 19:10:00', 0),
('UA8665', 'DEN', 'UA', '0001-01-01 07:45:00', 0),
('UA8693', 'FLL', 'UA', '0001-01-01 00:35:00', 1),
('UA8705', 'FLL', 'UA', '0001-01-01 06:00:00', 0),
('UA8706', 'IAH', 'UA', '0001-01-01 07:50:00', 0),
('VA5155', 'LAX', 'VA', '0001-01-01 07:00:00', 0),
('VS3352', 'DTW', 'VS', '0001-01-01 12:40:00', 0),
('VS3660', 'DTW', 'VS', '0001-01-01 06:50:00', 0),
('VS3788', 'MSP', 'VS', '0001-01-01 05:50:00', 0),
('VS4684', 'JFK', 'VS', '0001-01-01 12:04:00', 0),
('VS6795', 'CDG', 'VS', '0001-01-01 18:10:00', 0),
('VS8138', 'YYZ', 'VS', '0001-01-01 18:15:00', 0),
('WS3482', 'YHZ', 'WS', '0001-01-01 10:00:00', 0),
('WS3513', 'YYZ', 'WS', '0001-01-01 06:00:00', 0),
('WS3514', 'YYZ', 'WS', '0001-01-01 07:52:00', 1),
('WS3523', 'YYZ', 'WS', '0001-01-01 10:15:00', 0),
('WS3535', 'YYZ', 'WS', '0001-01-01 18:15:00', 0),
('WS594', 'YUL', 'WS', '0001-01-01 23:15:00', 1),
('WS595', 'YYZ', 'WS', '0001-01-01 07:00:00', 0),
('WS6104', 'MEX', 'WS', '0001-01-01 09:01:00', 0),
('WS6105', 'MEX', 'WS', '0001-01-01 07:25:00', 1),
('WS6301', 'ATL', 'WS', '0001-01-01 07:15:00', 0),
('WS6434', 'JFK', 'WS', '0001-01-01 12:04:00', 0),
('WS6441', 'YUL', 'WS', '0001-01-01 21:59:00', 1),
('WS6446', 'MSP', 'WS', '0001-01-01 05:50:00', 0),
('WS7687', 'DTW', 'WS', '0001-01-01 06:50:00', 0),
('WS7765', 'ATL', 'WS', '0001-01-01 18:15:00', 0),
('WS7767', 'ATL', 'WS', '0001-01-01 12:43:00', 0),
('WS7839', 'DTW', 'WS', '0001-01-01 12:40:00', 0),
('WS7920', 'DTW', 'WS', '0001-01-01 18:15:00', 0),
('WS7922', 'ATL', 'WS', '0001-01-01 05:35:00', 0),
('WS7924', 'YUL', 'WS', '0001-01-01 21:15:00', 1),
('YN530', 'YYY', 'YN', '0001-01-01 08:15:00', 0),
('YN703', 'YGK', 'YN', '0001-01-01 06:00:00', 0),
('YN905', 'YVO', 'YN', '0001-01-01 07:45:00', 0),
('YN922', 'YUL', 'YN', '0001-01-01 17:50:00', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `aeroports`
--
ALTER TABLE `aeroports`
  ADD PRIMARY KEY (`AeroportId`);

--
-- Indexes for table `compagnies`
--
ALTER TABLE `compagnies`
  ADD PRIMARY KEY (`CompagnieId`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`VolCeduleId`,`NumTel`);

--
-- Indexes for table `utilisateurs`
--
ALTER TABLE `utilisateurs`
  ADD PRIMARY KEY (`NomUtilisateur`);

--
-- Indexes for table `volcedules`
--
ALTER TABLE `volcedules`
  ADD PRIMARY KEY (`VolCeduleId`),
  ADD KEY `VolGeneriqueId` (`VolGeneriqueId`);

--
-- Indexes for table `volgeneriques`
--
ALTER TABLE `volgeneriques`
  ADD PRIMARY KEY (`VolGeneriqueId`),
  ADD KEY `AeroportId` (`AeroportId`),
  ADD KEY `CompagnieId` (`CompagnieId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `volcedules`
--
ALTER TABLE `volcedules`
  MODIFY `VolCeduleId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=322;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`VolCeduleId`) REFERENCES `volcedules` (`VolCeduleId`);

--
-- Constraints for table `volcedules`
--
ALTER TABLE `volcedules`
  ADD CONSTRAINT `volcedules_ibfk_1` FOREIGN KEY (`VolGeneriqueId`) REFERENCES `volgeneriques` (`VolGeneriqueId`);

--
-- Constraints for table `volgeneriques`
--
ALTER TABLE `volgeneriques`
  ADD CONSTRAINT `volgeneriques_ibfk_1` FOREIGN KEY (`AeroportId`) REFERENCES `aeroports` (`AeroportId`),
  ADD CONSTRAINT `volgeneriques_ibfk_2` FOREIGN KEY (`CompagnieId`) REFERENCES `compagnies` (`CompagnieId`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
