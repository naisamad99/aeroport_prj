-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jan 17, 2020 at 06:17 AM
-- Server version: 8.0.18
-- PHP Version: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `controltowerdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `airlines`
--

CREATE TABLE `airlines` (
  `iata` varchar(5) CHARACTER SET utf16 COLLATE utf16_general_ci NOT NULL,
  `name` varchar(100) CHARACTER SET utf16 COLLATE utf16_general_ci NOT NULL,
  `oaci` varchar(5) CHARACTER SET utf16 COLLATE utf16_general_ci NOT NULL,
  `country_iso_code` varchar(3) CHARACTER SET utf16 COLLATE utf16_general_ci DEFAULT NULL,
  `url_icon` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf16;

--
-- Dumping data for table `airlines`
--

INSERT INTO `airlines` (`iata`, `name`, `oaci`, `country_iso_code`, `url_icon`) VALUES
('3H', 'Air Inuit', 'AIE', 'CA', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/3h-logo.png'),
('5T', 'Canadian North', 'MPE', 'CA', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/5t-logo.png'),
('A3', 'Aegean Airlines S.A.', 'AEE', 'GR', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/a3-logo.png'),
('AA', 'American Airlines', 'AAL', 'US', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/aa-logo.png'),
('AC', 'Air Canada', 'ACA', 'CA', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/ac-logo.png'),
('AF', 'Air France', 'AFR', 'FR', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/af-logo.png'),
('AH', 'Air Algerie', 'DAH', 'AG', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/ah-logo.png'),
('AI', 'Air India Limited', 'AIC', 'IN', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/ai-logo.png'),
('AM', 'AeroMéxico', 'AMX', 'MX', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/am-logo.png'),
('AS', 'Alaska Airlines', 'ASA', 'US', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/as-logo.png'),
('AT', 'Royal Air Maroc', 'RAM', 'MO', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/at-logo.png'),
('AY', 'Finnair', 'FIN', 'FI', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/ay-logo.png'),
('AZ', 'Alitalia', 'AZA', 'IT', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/az-logo.png'),
('BA', 'British Airways', 'BAW', 'UK', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/ba-logo.png'),
('CA', 'Air China LTD', 'CCA', 'CH', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/ca-logo.png'),
('CI', 'China Airlines', 'CAL', 'TW', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/ci-logo.png'),
('CM', 'Copa Airlines', 'CMP', 'PM', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/cm-logo.png'),
('CZ', 'China Southern Airlines', 'CSN', 'CH', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/cz-logo.png'),
('DL', 'Delta Air Lines', 'DAL', 'US', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/dl-logo.png'),
('EY', 'Etihad Airways', 'ETD', 'AE', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/ey-logo.png'),
('G3', 'Gol Transportes Aéreos', 'GLO', 'BR', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/g3-logo.png'),
('HU', 'Hainan Airlines', 'CHH', 'CH', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/hu-logo.png'),
('IB', 'Iberia Airlines', 'IBE', 'SP', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/ib-logo.png'),
('KE', 'Korean Air', 'KAL', 'KS', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/ke-logo.png'),
('LA', 'LAN Airlines', 'LAN', 'CI', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/la-logo.png'),
('LH', 'Lufthansa', 'DLH', 'GM', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/lh-logo.png'),
('LO', 'LOT Polish Airlines', 'LOT', 'PL', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/lo-logo.png'),
('LV', 'Level', 'LVL', 'ES', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/ec-logo.png'),
('LX', 'Swiss International Air Lines', 'SWR', 'SZ', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/lx-logo.png'),
('ME', 'Middle East Airlines', 'MEA', 'LE', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/me-logo.png'),
('MS', 'Egyptair', 'MSR', 'EG', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/ms-logo.png'),
('MU', 'China Eastern Airlines', 'CES', 'CH', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/mu-logo.png'),
('NH', 'All Nippon Airways', 'ANA', 'JA', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/nh-logo.png'),
('NZ', 'Air New Zealand', 'ANZ', 'NZ', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/nz-logo.png'),
('OS', 'Austrian Airlines', 'AUA', 'AU', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/os-logo.png'),
('OU', 'Croatia Airlines D.D.', 'CTN', 'HR', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/ou-logo.png'),
('OZ', 'Asiana Airlines', 'AAR', 'KS', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/oz-logo.png'),
('PB', 'PAL Airlines', 'PVL', 'CA', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/pb-logo.png'),
('PD', 'Porter Airlines', 'POE', 'CA', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/pd-logo.png'),
('QF', 'Qantas', 'QFA', 'AS', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/qf-logo.png'),
('QR', 'Qatar Airways', 'QTR', 'QA', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/qr-logo.png'),
('QUE', ' Gouvernement Du Quebec', 'QUE', 'CA', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/que-logo.png'),
('RJ', 'Royal Jordanian', 'RJA', 'JO', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/rj-logo.png'),
('SA', 'South African Airways', 'SAA', 'SF', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/sa-logo.png'),
('SN', 'Brussels Airlines', 'DAT', 'BE', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/sn-logo.png'),
('SQ', 'Singapore Airlines', 'SIA', 'SN', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/sq-logo.png'),
('SWG', 'Sunwing', 'SWG', 'CA', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/swg-logo.png'),
('TG', 'Thai Airways International', 'THA', 'TH', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/tg-logo.png'),
('TK', 'Turkish Airlines', 'THY', 'TU', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/tk-logo.png'),
('TS', 'Air Transat', 'TSC', 'CA', ''),
('UA', 'United Airlines', 'UAL', 'US', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/ua-logo.png'),
('VA', 'Virgin Australia', 'VOZ', 'AS', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/va-logo.png'),
('VS', 'Virgin Atlantic Airways', 'VIR', 'UK', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/vs-logo.png'),
('WG', 'Sunwing Airlines', 'SWG', 'CA', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/swg-logo.png'),
('WS', 'WestJet', 'WJA', 'CA', ''),
('XOJ', 'XOJET', 'XOJ', 'US', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/xoj-logo.png'),
('YN', 'Air Creebec', 'CRQ', 'CA', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/yn-logo.png');

-- --------------------------------------------------------

--
-- Table structure for table `airports`
--

CREATE TABLE `airports` (
  `iata` varchar(5) CHARACTER SET utf16 COLLATE utf16_general_ci NOT NULL,
  `name` varchar(60) CHARACTER SET utf16 COLLATE utf16_general_ci NOT NULL,
  `city_id` int(11) NOT NULL,
  `url_logo` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf16;

--
-- Dumping data for table `airports`
--

INSERT INTO `airports` (`iata`, `name`, `city_id`, `url_logo`) VALUES
('ANU', 'V.C. Bird International Airport', 27, ''),
('ATL', 'Hartsfield-Jackson Atlanta International Airport', 10, ''),
('BOS', 'Logan International Airport', 23, ''),
('BRU', 'Brussels Airport', 32, ''),
('CDG', 'Charles de Gaulle Airport', 31, ''),
('CLT', 'Charlotte Douglas International Airport', 29, ''),
('CUN', 'Cancun International Airport', 15, ''),
('DFW', 'Dallas/Fort Worth International Airport', 16, ''),
('FLL', 'Fort Lauderdale-Hollywood International Airport', 11, ''),
('FRA', 'Frankfurt Airport', 7, ''),
('HOG', 'Frank Pais Airport', 17, ''),
('JFK', 'John F. Kennedy International Airport', 18, ''),
('LGA', 'LaGuardia Airport', 18, ''),
('MSP', 'Minneapolis-St. Paul International Airport', 12, ''),
('ORD', 'O Hare International Airport', 6, ''),
('PHL', 'Philadelphia International Airport', 24, ''),
('PIT', 'Pittsburgh International Airport', 9, ''),
('POP', 'La Union Airport', 1, ''),
('PUJ', 'Punta Cana International Airport', 22, ''),
('PVR', 'Gustavo Diaz Ordaz International Airport', 28, ''),
('VRA', 'Juan Gualberto Gomez Airport', 26, ''),
('YBG', 'Saguenay-Bagotville Airport', 13, ''),
('YFC', 'Fredericton International Airport', 19, ''),
('YHZ', 'Halifax Stanfield International Airport', 3, ''),
('YOW', 'Ottawa/Macdonald-Cartier International Airport', 5, ''),
('YQB', 'Quebec City Jean Lesage International Airport', 8, ''),
('YQM', 'Greater Moncton International Airport', 4, ''),
('YTZ', 'Billy Bishop Toronto City Airport', 2, ''),
('YVO', 'Val-d Or Airport', 25, ''),
('YVR', 'Vancouver International Airport', 33, ''),
('YYC', 'Calgary International Airport', 30, ''),
('YYG', 'Charlottetown Airport', 21, ''),
('YYT', 'St. John s International Airport', 14, ''),
('YYZ', 'Pearson International Airport', 2, ''),
('ZSA', 'San Salvador Airport', 20, '');

-- --------------------------------------------------------

--
-- Table structure for table `alerts`
--

CREATE TABLE `alerts` (
  `phone` varchar(20) NOT NULL,
  `flight_id` int(11) NOT NULL,
  `datetime_subscription` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `datetime_unsubscription` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf16;

-- --------------------------------------------------------

--
-- Table structure for table `cities`
--

CREATE TABLE `cities` (
  `id` int(11) NOT NULL,
  `name` varchar(60) NOT NULL,
  `state` varchar(30) CHARACTER SET utf16 COLLATE utf16_general_ci DEFAULT NULL,
  `country_iso_code` varchar(3) CHARACTER SET utf16 COLLATE utf16_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf16;

--
-- Dumping data for table `cities`
--

INSERT INTO `cities` (`id`, `name`, `state`, `country_iso_code`) VALUES
(1, 'Puerto Plata', '', 'DO'),
(2, 'Toronto', 'ON', 'CA'),
(3, 'Halifax', 'NS', 'CA'),
(4, 'Moncton', 'NB', 'CA'),
(5, 'Ottawa', 'ON', 'CA'),
(6, 'Chicago', 'IL', 'US'),
(7, 'Frankfurt', '', 'UNK'),
(8, 'Quebec', 'QC', 'CA'),
(9, 'Pittsburgh', 'PA', 'US'),
(10, 'Atlanta', 'GA', 'US'),
(11, 'Fort Lauderdale', 'FL', 'US'),
(12, 'Minneapolis', 'MN', 'US'),
(13, 'La Baie', 'QC', 'CA'),
(14, 'St. John s', 'NL', 'CA'),
(15, 'Cancun', '', 'MX'),
(16, 'Dallas', 'TX', 'US'),
(17, 'Holguin', '', 'CU'),
(18, 'New York', 'NY', 'US'),
(19, 'Fredericton', 'NB', 'CA'),
(20, 'San Salvador', '', 'BS'),
(21, 'Charlottetown', 'PE', 'CA'),
(22, 'Punta Cana', '', 'DO'),
(23, 'Boston', 'MA', 'US'),
(24, 'Philadelphia', 'PA', 'US'),
(25, 'Val D Or', 'QC', 'CA'),
(26, 'Varadero', '', 'CU'),
(27, 'Antigua', '', 'AG'),
(28, 'Puerto Vallarta', '', 'MX'),
(29, 'Charlotte', 'NC', 'US'),
(30, 'Calgary', 'AB', 'CA'),
(31, 'Paris', '', 'FR'),
(32, 'Brussels', '', 'BE'),
(33, 'Vancouver', 'BC', 'CA');

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE `countries` (
  `name` varchar(60) NOT NULL,
  `iso_alpha2_code` varchar(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf16;

--
-- Dumping data for table `countries`
--

INSERT INTO `countries` (`name`, `iso_alpha2_code`) VALUES
('Aruba', 'AA'),
('Antigua and Barbuda', 'AC'),
('United Arab Emirates', 'AE'),
('Afghanistan', 'AF'),
('Algeria', 'AG'),
('Azerbaijan', 'AJ'),
('Albania', 'AL'),
('Armenia', 'AM'),
('Angola', 'AO'),
('American Samoa', 'AQ'),
('Argentina', 'AR'),
('Australia', 'AS'),
('Ashmore and Cartier Islands', 'AT'),
('Austria', 'AU'),
('Anguilla', 'AV'),
('Antarctica', 'AY'),
('Bahrain', 'BA'),
('Barbados', 'BB'),
('Botswana', 'BC'),
('Bermuda', 'BD'),
('Belgium', 'BE'),
('Bahamas', 'BF'),
('Bangladesh', 'BG'),
('Belize', 'BH'),
('Bosnia and Herzegovina', 'BK'),
('Bolivia', 'BL'),
('Burma', 'BM'),
('Benin', 'BN'),
('Belarus', 'BO'),
('Solomon Islands', 'BP'),
('Navassa Island', 'BQ'),
('Brazil', 'BR'),
('Bassas da India', 'BS'),
('Bhutan', 'BT'),
('Bulgaria', 'BU'),
('Bouvet Island', 'BV'),
('Brunei', 'BX'),
('Burundi', 'BY'),
('Canada', 'CA'),
('Chad', 'CD'),
('Sri Lanka', 'CE'),
('Congo (Kinshasa)', 'CF'),
('Congo (Brazzaville)', 'CG'),
('China', 'CH'),
('Chile', 'CI'),
('Cayman Islands', 'CJ'),
('Cocos (Keeling) Islands', 'CK'),
('Cameroon', 'CM'),
('Comoros', 'CN'),
('Colombia', 'CO'),
('Northern Mariana Islands', 'CQ'),
('Coral Sea Islands', 'CR'),
('Costa Rica', 'CS'),
('Central African Republic', 'CT'),
('Cuba', 'CU'),
('Cape Verde', 'CV'),
('Cook Islands', 'CW'),
('Cyprus', 'CY'),
('Denmark', 'DA'),
('Djibouti', 'DJ'),
('Dominica', 'DO'),
('Jarvis Island', 'DQ'),
('Dominican Republic', 'DR'),
('Ecuador', 'EC'),
('Egypt', 'EG'),
('Ireland', 'EI'),
('Equatorial Guinea', 'EK'),
('Estonia', 'EN'),
('Eritrea', 'ER'),
('El Salvador', 'ES'),
('Ethiopia', 'ET'),
('Europa Island', 'EU'),
('Czech Republic', 'EZ'),
('French Guiana', 'FG'),
('Finland', 'FI'),
('Fiji', 'FJ'),
('Falkland Islands', 'FK'),
('Micronesia', 'FM'),
('Faroe Islands', 'FO'),
('French Polynesia', 'FP'),
('Baker Island', 'FQ'),
('France', 'FR'),
('French Southern and Antarctic Lands', 'FS'),
('Gambia', 'GA'),
('Gabon', 'GB'),
('Georgia', 'GG'),
('Ghana', 'GH'),
('Gibraltar', 'GI'),
('Grenada', 'GJ'),
('Guernsey', 'GK'),
('Greenland', 'GL'),
('Germany', 'GM'),
('Glorioso Islands', 'GO'),
('Guadeloupe', 'GP'),
('Guam', 'GQ'),
('Greece', 'GR'),
('Guatemala', 'GT'),
('Guinea', 'GV'),
('Guyana', 'GY'),
('Gaza Strip', 'GZ'),
('Haiti', 'HA'),
('Hong Kong', 'HK'),
('Heard Island and McDonald Islands', 'HM'),
('Honduras', 'HO'),
('Howland Island', 'HQ'),
('Croatia', 'HR'),
('Hungary', 'HU'),
('Iceland', 'IC'),
('Indonesia', 'ID'),
('Isle of Man', 'IM'),
('India', 'IN'),
('British Indian Ocean Territory', 'IO'),
('Clipperton Island', 'IP'),
('Iran', 'IR'),
('Israel', 'IS'),
('Italy', 'IT'),
('Cote d\'Ivoire', 'IV'),
('Iraq', 'IZ'),
('Japan', 'JA'),
('Jersey', 'JE'),
('Jamaica', 'JM'),
('Jan Mayen', 'JN'),
('Jordan', 'JO'),
('Johnston Atoll', 'JQ'),
('Juan de Nova Island', 'JU'),
('Kenya', 'KE'),
('Kyrgyzstan', 'KG'),
('Cambodia', 'KH'),
('North Korea', 'KN'),
('Kingman Reef', 'KQ'),
('Kiribati', 'KR'),
('South Korea', 'KS'),
('Christmas Island', 'KT'),
('Kuwait', 'KU'),
('Kazakhstan', 'KZ'),
('Laos', 'LA'),
('Lebanon', 'LE'),
('Latvia', 'LG'),
('Lithuania', 'LH'),
('Liberia', 'LI'),
('Slovakia', 'LO'),
('Palmyra Atoll', 'LQ'),
('Lesotho', 'LT'),
('Luxembourg', 'LU'),
('Libya', 'LY'),
('Madagascar', 'MA'),
('Martinique', 'MB'),
('Macau', 'MC'),
('Moldova', 'MD'),
('Mayotte', 'MF'),
('Mongolia', 'MG'),
('Montserrat', 'MH'),
('Malawi', 'MI'),
('Montenegro', 'MJ'),
('Macedonia', 'MK'),
('Mali', 'ML'),
('Myanmar', 'MM'),
('Monaco', 'MN'),
('Morocco', 'MO'),
('Mauritius', 'MP'),
('Midway Islands', 'MQ'),
('Mauritania', 'MR'),
('Malta', 'MT'),
('Oman', 'MU'),
('Maldives', 'MV'),
('Mexico', 'MX'),
('Malaysia', 'MY'),
('Mozambique', 'MZ'),
('New Caledonia', 'NC'),
('Niue', 'NE'),
('Norfolk Island', 'NF'),
('Niger', 'NG'),
('Vanuatu', 'NH'),
('Nigeria', 'NI'),
('Netherlands', 'NL'),
('Norway', 'NO'),
('Nepal', 'NP'),
('Nauru', 'NR'),
('Suriname', 'NS'),
('Netherlands Antilles', 'NT'),
('Nicaragua', 'NU'),
('New Zealand', 'NZ'),
('Paraguay', 'PA'),
('Pitcairn Islands', 'PC'),
('Peru', 'PE'),
('Paracel Islands', 'PF'),
('Spratly Islands', 'PG'),
('Pakistan', 'PK'),
('Poland', 'PL'),
('Panama', 'PM'),
('Portugal', 'PO'),
('Papua New Guinea', 'PP'),
('Palau', 'PS'),
('Guinea-Bissau', 'PU'),
('Qatar', 'QA'),
('Serbia', 'RB'),
('Reunion', 'RE'),
('Marshall Islands', 'RM'),
('Romania', 'RO'),
('Philippines', 'RP'),
('Puerto Rico', 'RQ'),
('Russia', 'RS'),
('Rwanda', 'RW'),
('Saudi Arabia', 'SA'),
('Saint Pierre and Miquelon', 'SB'),
('Saint Kitts and Nevis', 'SC'),
('Seychelles', 'SE'),
('South Africa', 'SF'),
('Senegal', 'SG'),
('Saint Helena', 'SH'),
('Slovenia', 'SI'),
('Sierra Leone', 'SL'),
('Singapore', 'SN'),
('Somalia', 'SO'),
('Spain', 'SP'),
('South Sudan', 'SS'),
('Saint Lucia', 'ST'),
('Sudan', 'SU'),
('Svalbard', 'SV'),
('Sweden', 'SW'),
('South Georgia and the Islands', 'SX'),
('Syria', 'SY'),
('Switzerland', 'SZ'),
('Trinidad and Tobago', 'TD'),
('Tromelin Island', 'TE'),
('Thailand', 'TH'),
('Tajikistan', 'TI'),
('Turks and Caicos Islands', 'TK'),
('Tokelau', 'TL'),
('Tonga', 'TN'),
('Togo', 'TO'),
('Sao Tome and Principe', 'TP'),
('Tunisia', 'TS'),
('Timor-Leste', 'TT'),
('Turkey', 'TU'),
('Tuvalu', 'TV'),
('Taiwan', 'TW'),
('Turkmenistan', 'TX'),
('Tanzania', 'TZ'),
('Uganda', 'UG'),
('United Kingdom', 'UK'),
('UNKNOWN COUNTRY', 'UNK'),
('Ukraine', 'UP'),
('United States', 'US'),
('Burkina Faso', 'UV'),
('Uruguay', 'UY'),
('Uzbekistan', 'UZ'),
('Saint Vincent and the Grenadines', 'VC'),
('Venezuela', 'VE'),
('British Virgin Islands', 'VI'),
('Vietnam', 'VM'),
('Virgin Islands', 'VQ'),
('Namibia', 'WA'),
('West Bank', 'WE'),
('Wallis and Futuna', 'WF'),
('Western Sahara', 'WI'),
('Wake Island', 'WQ'),
('Samoa', 'WS'),
('Swaziland', 'WZ'),
('Yemen', 'YM'),
('Zambia', 'ZA'),
('Zimbabwe', 'ZI');

-- --------------------------------------------------------

--
-- Table structure for table `flightreferences`
--

CREATE TABLE `flightreferences` (
  `flightnumber` varchar(10) CHARACTER SET utf16 COLLATE utf16_general_ci NOT NULL,
  `airline_iata` varchar(5) NOT NULL,
  `airport_iata` varchar(5) NOT NULL,
  `direction` int(1) NOT NULL DEFAULT '0' COMMENT '0:Departures, 1:Arrivals',
  `time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf16;

--
-- Dumping data for table `flightreferences`
--

INSERT INTO `flightreferences` (`flightnumber`, `airline_iata`, `airport_iata`, `direction`, `time`) VALUES
('A33078', 'A3', 'FRA', 1, '2001-01-01 12:05:00'),
('AA3981', 'AA', 'DFW', 0, '2001-01-01 06:00:00'),
('AA4845', 'AA', 'PHL', 0, '2001-01-01 17:40:00'),
('AA5137', 'AA', 'CLT', 1, '2001-01-01 22:36:00'),
('AC1600', 'AC', 'FLL', 0, '2001-01-01 06:00:00'),
('AC1801', 'AC', 'ZSA', 1, '2001-01-01 18:00:00'),
('AC3054', 'AC', 'ORD', 0, '2001-01-01 07:00:00'),
('AC314', 'AC', 'YVR', 1, '2001-01-01 17:07:00'),
('AC322', 'AC', 'YYC', 1, '2001-01-01 23:21:00'),
('AC3335', 'AC', 'ORD', 1, '2001-01-01 18:02:00'),
('AC406', 'AC', 'YYZ', 1, '2001-01-01 11:15:00'),
('AC411', 'AC', 'YYZ', 0, '2001-01-01 12:00:00'),
('AC415', 'AC', 'YYZ', 0, '2001-01-01 14:00:00'),
('AC423', 'AC', 'YYZ', 0, '2001-01-01 18:00:00'),
('AC429', 'AC', 'YYZ', 0, '2001-01-01 21:30:00'),
('AC481', 'AC', 'YYZ', 0, '2001-01-01 06:00:00'),
('AC7597', 'AC', 'ORD', 0, '2001-01-01 17:15:00'),
('AC7598', 'AC', 'ORD', 1, '2001-01-01 22:32:00'),
('AC7958', 'AC', 'YTZ', 1, '2001-01-01 11:25:00'),
('AC8015', 'AC', 'YYT', 1, '2001-01-01 06:30:00'),
('AC8031', 'AC', 'PHL', 1, '2001-01-01 10:02:00'),
('AC8171', 'AC', 'PIT', 1, '2001-01-01 18:00:00'),
('AC833', 'AC', 'BRU', 1, '2001-01-01 11:30:00'),
('AC8460', 'AC', 'BOS', 0, '2001-01-01 16:50:00'),
('AC8461', 'AC', 'BOS', 1, '2001-01-01 17:11:00'),
('AC8505', 'AC', 'YFC', 1, '2001-01-01 11:51:00'),
('AC8549', 'AC', 'YYG', 0, '2001-01-01 20:05:00'),
('AC8681', 'AC', 'YBG', 1, '2001-01-01 06:29:00'),
('AC8701', 'AC', 'YQB', 1, '2001-01-01 06:24:00'),
('AC8726', 'AC', 'YQB', 0, '2001-01-01 18:00:00'),
('AC8732', 'AC', 'YQB', 0, '2001-01-01 21:50:00'),
('AC8753', 'AC', 'YVO', 0, '2001-01-01 17:50:00'),
('AC8781', 'AC', 'YHZ', 1, '2001-01-01 05:55:00'),
('AC8783', 'AC', 'YHZ', 1, '2001-01-01 12:05:00'),
('AC8831', 'AC', 'YYZ', 0, '2001-01-01 05:30:00'),
('AC8901', 'AC', 'YQM', 1, '2001-01-01 06:07:00'),
('AC8956', 'AC', 'YOW', 1, '2001-01-01 11:50:00'),
('AC8970', 'AC', 'YOW', 1, '2001-01-01 06:18:00'),
('AF5756', 'AF', 'MSP', 1, '2001-01-01 00:05:00'),
('AF8875', 'AF', 'JFK', 0, '2001-01-01 11:56:00'),
('AM3544', 'AM', 'ATL', 0, '2001-01-01 05:40:00'),
('AM4189', 'AM', 'MSP', 0, '2001-01-01 05:47:00'),
('AM4637', 'AM', 'MSP', 1, '2001-01-01 00:05:00'),
('AM7322', 'AM', 'YYZ', 0, '2001-01-01 06:00:00'),
('AS4027', 'AS', 'ORD', 0, '2001-01-01 12:23:00'),
('CA7462', 'CA', 'YOW', 1, '2001-01-01 11:50:00'),
('DL5471', 'DL', 'LGA', 0, '2001-01-01 11:15:00'),
('DL5503', 'DL', 'MSP', 1, '2001-01-01 00:05:00'),
('DL5517', 'DL', 'JFK', 0, '2001-01-01 11:56:00'),
('DL5520', 'DL', 'ATL', 0, '2001-01-01 05:40:00'),
('DL7204', 'DL', 'YYZ', 0, '2001-01-01 06:00:00'),
('EY3859', 'EY', 'YYZ', 0, '2001-01-01 18:00:00'),
('G38326', 'G3', 'ATL', 0, '2001-01-01 05:40:00'),
('G38340', 'G3', 'JFK', 0, '2001-01-01 11:56:00'),
('IB4284', 'IB', 'ORD', 0, '2001-01-01 12:23:00'),
('KE3771', 'KE', 'ATL', 0, '2001-01-01 05:40:00'),
('KE3835', 'KE', 'MSP', 1, '2001-01-01 00:05:00'),
('KE3836', 'KE', 'MSP', 0, '2001-01-01 05:47:00'),
('KE6528', 'KE', 'YYZ', 0, '2001-01-01 06:00:00'),
('KE7379', 'KE', 'JFK', 0, '2001-01-01 11:56:00'),
('LH6570', 'LH', 'YYZ', 0, '2001-01-01 14:00:00'),
('LH6571', 'LH', 'YVR', 1, '2001-01-01 17:07:00'),
('LH6794', 'LH', 'FRA', 1, '2001-01-01 12:05:00'),
('LX4652', 'LX', 'YQB', 0, '2001-01-01 18:00:00'),
('LX4654', 'LX', 'YYZ', 0, '2001-01-01 14:00:00'),
('LX4685', 'LX', 'YOW', 1, '2001-01-01 11:50:00'),
('MS9602', 'MS', 'YYZ', 1, '2001-01-01 11:15:00'),
('NH7431', 'NH', 'ORD', 0, '2001-01-01 07:00:00'),
('NH7804', 'NH', 'ORD', 1, '2001-01-01 18:02:00'),
('NZ9806', 'NZ', 'ORD', 0, '2001-01-01 07:00:00'),
('NZ9856', 'NZ', 'ORD', 1, '2001-01-01 18:02:00'),
('OS8205', 'OS', 'FRA', 1, '2001-01-01 12:05:00'),
('OS8246', 'OS', 'YYZ', 0, '2001-01-01 14:00:00'),
('OS8360', 'OS', 'YVR', 1, '2001-01-01 17:07:00'),
('OS8390', 'OS', 'YYZ', 0, '2001-01-01 06:00:00'),
('OS8396', 'OS', 'YYZ', 0, '2001-01-01 18:00:00'),
('PD466', 'PD', 'YTZ', 0, '2001-01-01 12:00:00'),
('SN9551', 'SN', 'BRU', 1, '2001-01-01 11:30:00'),
('SN9556', 'SN', 'YVR', 1, '2001-01-01 17:07:00'),
('SN9618', 'SN', 'BOS', 1, '2001-01-01 17:11:00'),
('SQ1019', 'SQ', 'FRA', 1, '2001-01-01 12:05:00'),
('SWG115', 'SWG', 'ANU', 1, '2001-01-01 20:20:00'),
('SWG426', 'SWG', 'PUJ', 0, '2001-01-01 09:20:00'),
('SWG470', 'SWG', 'POP', 0, '2001-01-01 06:00:00'),
('SWG471', 'SWG', 'POP', 1, '2001-01-01 15:45:00'),
('SWG526', 'SWG', 'PVR', 1, '2001-01-01 21:35:00'),
('SWG555', 'SWG', 'CUN', 0, '2001-01-01 06:00:00'),
('SWG650', 'SWG', 'HOG', 0, '2001-01-01 06:00:00'),
('TG5822', 'TG', 'FRA', 1, '2001-01-01 12:05:00'),
('TK8691', 'TK', 'YYZ', 0, '2001-01-01 18:00:00'),
('TK9110', 'TK', 'YQB', 0, '2001-01-01 21:50:00'),
('TS221', 'TS', 'CDG', 1, '2001-01-01 11:15:00'),
('TS474', 'TS', 'YYZ', 0, '2001-01-01 18:00:00'),
('TS493', 'TS', 'VRA', 1, '2001-01-01 18:30:00'),
('UA3495', 'UA', 'ORD', 1, '2001-01-01 18:02:00'),
('UA3615', 'UA', 'ORD', 0, '2001-01-01 07:00:00'),
('UA8033', 'UA', 'YFC', 1, '2001-01-01 11:51:00'),
('UA8193', 'UA', 'YYG', 1, '2001-01-01 06:46:00'),
('UA8364', 'UA', 'YYG', 0, '2001-01-01 20:05:00'),
('UA8424', 'UA', 'BOS', 0, '2001-01-01 16:50:00'),
('UA8483', 'UA', 'BOS', 1, '2001-01-01 17:11:00'),
('UA8579', 'UA', 'FRA', 1, '2001-01-01 12:05:00'),
('UA8705', 'UA', 'FLL', 0, '2001-01-01 06:00:00'),
('WS6442', 'WS', 'LGA', 0, '2001-01-01 11:15:00'),
('WS6449', 'WS', 'MSP', 1, '2001-01-01 00:05:00'),
('WS7922', 'WS', 'ATL', 0, '2001-01-01 05:40:00');

-- --------------------------------------------------------

--
-- Table structure for table `flights`
--

CREATE TABLE `flights` (
  `id` int(11) NOT NULL,
  `flightref_number` varchar(10) NOT NULL,
  `scheduled_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `estimated_time` datetime DEFAULT NULL,
  `status` int(2) NOT NULL COMMENT '0:Schedule, ',
  `terminal` varchar(2) CHARACTER SET utf16 COLLATE utf16_general_ci DEFAULT NULL,
  `gate` varchar(3) CHARACTER SET utf16 COLLATE utf16_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf16;

--
-- Dumping data for table `flights`
--

INSERT INTO `flights` (`id`, `flightref_number`, `scheduled_time`, `estimated_time`, `status`, `terminal`, `gate`) VALUES
(1020, 'SWG470', '2020-01-14 06:00:00', '2020-01-14 18:08:00', 2, '', 'A59'),
(1021, 'AC415', '2020-01-14 14:00:00', '2020-01-14 19:59:00', 2, '', 'A11'),
(1022, 'LH6570', '2020-01-14 14:00:00', '2020-01-14 19:59:00', 2, '', 'A11'),
(1023, 'LX4654', '2020-01-14 14:00:00', '2020-01-14 19:59:00', 2, '', 'A11'),
(1024, 'OS8246', '2020-01-14 14:00:00', '2020-01-14 19:59:00', 2, '', 'A11'),
(1025, 'AC8781', '2020-01-13 05:55:00', '2020-01-13 20:35:00', 2, '', NULL),
(1026, 'AC8901', '2020-01-12 06:07:00', '2020-01-12 19:23:00', 2, '', NULL),
(1027, 'AC8956', '2020-01-14 11:50:00', '2020-01-14 18:23:00', 2, '', NULL),
(1028, 'CA7462', '2020-01-14 11:50:00', '2020-01-14 18:23:00', 2, '', NULL),
(1029, 'LX4685', '2020-01-14 11:50:00', '2020-01-14 18:23:00', 2, '', NULL),
(1030, 'AC411', '2020-01-16 12:00:00', '2020-01-16 12:00:00', 0, '', NULL),
(1031, 'PD466', '2020-01-16 12:00:00', '2020-01-16 12:00:00', 0, '', NULL),
(1032, 'AS4027', '2020-01-16 12:23:00', '2020-01-16 12:23:00', 0, '', NULL),
(1033, 'IB4284', '2020-01-16 12:23:00', '2020-01-16 12:23:00', 0, '', NULL),
(1034, 'UA8579', '2020-01-16 12:05:00', '2020-01-16 12:05:00', 0, '', NULL),
(1035, 'AC8783', '2020-01-16 12:05:00', '2020-01-16 12:05:00', 0, '', NULL),
(1036, 'A33078', '2020-01-16 12:05:00', '2020-01-16 12:05:00', 0, '', NULL),
(1037, 'LH6794', '2020-01-16 12:05:00', '2020-01-16 12:05:00', 0, '', NULL),
(1038, 'OS8205', '2020-01-16 12:05:00', '2020-01-16 12:05:00', 0, '', NULL),
(1039, 'AC8726', '2020-01-16 18:00:00', '2020-01-16 18:00:00', 0, '', NULL),
(1040, 'LX4652', '2020-01-16 18:00:00', '2020-01-16 18:00:00', 0, '', NULL),
(1041, 'AC423', '2020-01-16 18:00:00', '2020-01-16 18:00:00', 0, '', NULL),
(1042, 'OS8396', '2020-01-16 18:00:00', '2020-01-16 18:00:00', 0, '', NULL),
(1043, 'TK8691', '2020-01-16 18:00:00', '2020-01-16 18:00:00', 0, '', NULL),
(1044, 'AC8171', '2020-01-16 18:00:00', '2020-01-16 18:00:00', 0, '', NULL),
(1045, 'NH7804', '2020-01-16 18:02:00', '2020-01-16 18:02:00', 0, '', NULL),
(1046, 'AC3335', '2020-01-16 18:02:00', '2020-01-16 18:02:00', 0, '', NULL),
(1047, 'UA3495', '2020-01-16 18:02:00', '2020-01-16 18:02:00', 0, '', NULL),
(1048, 'NZ9856', '2020-01-16 18:02:00', '2020-01-16 18:02:00', 0, '', NULL),
(1049, 'AC8831', '2020-01-16 05:30:00', '2020-01-16 05:30:00', 0, '', NULL),
(1050, 'DL5520', '2020-01-16 05:40:00', '2020-01-16 05:40:00', 0, '', 'C84'),
(1051, 'G38326', '2020-01-16 05:40:00', '2020-01-16 05:40:00', 0, '', 'C84'),
(1052, 'KE3771', '2020-01-16 05:40:00', '2020-01-16 05:40:00', 0, '', 'C84'),
(1053, 'WS7922', '2020-01-16 05:40:00', '2020-01-16 05:40:00', 0, '', 'C84'),
(1054, 'AC1600', '2020-01-16 06:00:00', '2020-01-16 06:00:00', 0, '', NULL),
(1055, 'UA8705', '2020-01-16 06:00:00', '2020-01-16 06:00:00', 0, '', NULL),
(1056, 'AM7322', '2020-01-16 06:00:00', '2020-01-16 06:00:00', 0, '', NULL),
(1057, 'DL7204', '2020-01-16 06:00:00', '2020-01-16 06:00:00', 0, '', NULL),
(1058, 'KE6528', '2020-01-16 06:00:00', '2020-01-16 06:00:00', 0, '', NULL),
(1059, 'WS6449', '2020-01-16 00:05:00', '2020-01-16 00:05:00', 0, '', 'C84'),
(1060, 'KE3835', '2020-01-16 00:05:00', '2020-01-16 00:05:00', 0, '', 'C84'),
(1061, 'AM4637', '2020-01-16 00:05:00', '2020-01-16 00:05:00', 0, '', 'C84'),
(1062, 'AF5756', '2020-01-16 00:05:00', '2020-01-16 00:05:00', 0, '', 'C84'),
(1063, 'DL5503', '2020-01-16 00:05:00', '2020-01-16 00:05:00', 0, '', 'C84'),
(1064, 'AC8901', '2020-01-16 06:07:00', '2020-01-16 06:07:00', 0, '', NULL),
(1065, 'AC8970', '2020-01-16 06:18:00', '2020-01-16 06:18:00', 0, '', NULL),
(1066, 'AC8701', '2020-01-16 06:24:00', '2020-01-16 06:24:00', 0, '', NULL),
(1067, 'AC8681', '2020-01-16 06:29:00', '2020-01-16 06:29:00', 0, '', NULL),
(1068, 'AC8015', '2020-01-16 06:30:00', '2020-01-16 06:30:00', 0, '', NULL),
(1069, 'AC8831', '2020-01-15 05:30:00', '2020-01-15 05:30:00', 0, '', 'A2'),
(1070, 'DL5520', '2020-01-15 05:40:00', '2020-01-15 05:40:00', 0, '', 'C84'),
(1071, 'G38326', '2020-01-15 05:40:00', '2020-01-15 05:40:00', 0, '', 'C84'),
(1072, 'KE3771', '2020-01-15 05:40:00', '2020-01-15 05:40:00', 0, '', 'C84'),
(1073, 'WS7922', '2020-01-15 05:40:00', '2020-01-15 05:40:00', 0, '', 'C84'),
(1074, 'AC481', '2020-01-15 06:00:00', '2020-01-15 06:00:00', 0, '', 'A47'),
(1075, 'OS8390', '2020-01-15 06:00:00', '2020-01-15 06:00:00', 0, '', 'A47'),
(1076, 'SWG555', '2020-01-15 06:00:00', '2020-01-15 06:00:00', 0, '', 'A61'),
(1077, 'AA3981', '2020-01-15 06:00:00', '2020-01-15 06:00:00', 0, '', 'C85'),
(1078, 'SWG650', '2020-01-15 06:00:00', '2020-01-15 06:00:00', 0, '', 'A63'),
(1079, 'DL5517', '2020-01-15 11:56:00', '2020-01-15 11:56:00', 0, '', 'C87'),
(1080, 'AF8875', '2020-01-15 11:56:00', '2020-01-15 11:56:00', 0, '', 'C87'),
(1081, 'G38340', '2020-01-15 11:56:00', '2020-01-15 11:56:00', 0, '', 'C87'),
(1082, 'KE7379', '2020-01-15 11:56:00', '2020-01-15 11:56:00', 0, '', 'C87'),
(1083, 'AC8726', '2020-01-15 18:00:00', '2020-01-15 18:00:00', 0, '', NULL),
(1084, 'LX4652', '2020-01-15 18:00:00', '2020-01-15 18:00:00', 0, '', NULL),
(1085, 'AC423', '2020-01-15 18:00:00', '2020-01-15 18:00:00', 0, '', NULL),
(1086, 'EY3859', '2020-01-15 18:00:00', '2020-01-15 18:00:00', 0, '', NULL),
(1087, 'OS8396', '2020-01-15 18:00:00', '2020-01-15 18:00:00', 0, '', NULL),
(1088, 'AM4637', '2020-01-15 00:05:00', '2020-01-15 00:05:00', 0, '', 'C84'),
(1089, 'AF5756', '2020-01-15 00:05:00', '2020-01-15 00:05:00', 0, '', 'C84'),
(1090, 'DL5503', '2020-01-15 00:05:00', '2020-01-15 00:05:00', 0, '', 'C84'),
(1091, 'KE3835', '2020-01-15 00:05:00', '2020-01-15 00:05:00', 0, '', 'C84'),
(1092, 'WS6449', '2020-01-15 00:05:00', '2020-01-15 00:05:00', 0, '', 'C84'),
(1093, 'AC8901', '2020-01-15 06:07:00', '2020-01-15 06:07:00', 0, '', NULL),
(1094, 'AC8970', '2020-01-15 06:18:00', '2020-01-15 06:18:00', 0, '', NULL),
(1095, 'AC8701', '2020-01-15 06:24:00', '2020-01-15 06:24:00', 0, '', NULL),
(1096, 'AC8681', '2020-01-15 06:29:00', '2020-01-15 06:29:00', 0, '', NULL),
(1097, 'AC8015', '2020-01-15 06:30:00', '2020-01-15 06:30:00', 0, '', NULL),
(1098, 'UA8033', '2020-01-15 11:51:00', '2020-01-15 11:51:00', 0, '', NULL),
(1099, 'AC8505', '2020-01-15 11:51:00', '2020-01-15 11:51:00', 0, '', NULL),
(1100, 'SQ1019', '2020-01-15 12:05:00', '2020-01-15 12:05:00', 0, '', NULL),
(1101, 'TG5822', '2020-01-15 12:05:00', '2020-01-15 12:05:00', 0, '', NULL),
(1102, 'UA8579', '2020-01-15 12:05:00', '2020-01-15 12:05:00', 0, '', NULL),
(1103, 'AC1801', '2020-01-15 18:00:00', '2020-01-15 18:00:00', 0, '', NULL),
(1104, 'AC8171', '2020-01-15 18:00:00', '2020-01-15 18:00:00', 0, '', NULL),
(1105, 'UA3495', '2020-01-15 18:02:00', '2020-01-15 18:02:00', 0, '', NULL),
(1106, 'AC3335', '2020-01-15 18:02:00', '2020-01-15 18:02:00', 0, '', NULL),
(1107, 'NZ9856', '2020-01-15 18:02:00', '2020-01-15 18:02:00', 0, '', NULL),
(1108, 'AC8549', '2020-01-14 20:05:00', '2020-01-14 20:05:00', 0, '', NULL),
(1109, 'UA8364', '2020-01-14 20:05:00', '2020-01-14 20:05:00', 0, '', NULL),
(1110, 'AC429', '2020-01-14 21:30:00', '2020-01-14 21:30:00', 0, '', 'A48'),
(1111, 'AC8732', '2020-01-14 21:50:00', '2020-01-14 21:50:00', 0, '', 'A25'),
(1112, 'TK9110', '2020-01-14 21:50:00', '2020-01-14 21:50:00', 0, '', 'A25'),
(1113, 'DL5520', '2020-01-14 05:40:00', '2020-01-14 05:35:00', 2, '', 'C84'),
(1114, 'AM3544', '2020-01-15 05:40:00', '2020-01-15 05:40:00', 0, '', 'C84'),
(1115, 'KE3771', '2020-01-14 05:40:00', '2020-01-14 05:35:00', 2, '', 'C84'),
(1116, 'WS7922', '2020-01-14 05:40:00', '2020-01-14 05:35:00', 2, '', 'C84'),
(1117, 'G38326', '2020-01-14 05:40:00', '2020-01-14 05:35:00', 2, '', 'C84'),
(1118, 'AM4189', '2020-01-15 05:47:00', '2020-01-15 05:47:00', 0, '', 'C86'),
(1119, 'KE3836', '2020-01-15 05:47:00', '2020-01-15 05:47:00', 0, '', 'C86'),
(1120, 'UA3615', '2020-01-14 07:00:00', '2020-01-14 07:00:00', 1, '', 'C83'),
(1121, 'AC3054', '2020-01-14 07:00:00', '2020-01-14 07:00:00', 1, '', 'C83'),
(1122, 'NZ9806', '2020-01-14 07:00:00', '2020-01-14 07:00:00', 1, '', 'C83'),
(1123, 'NH7431', '2020-01-14 07:00:00', '2020-01-14 07:00:00', 1, '', 'C83'),
(1124, 'SWG426', '2020-01-14 09:20:00', '2020-01-14 09:20:00', 1, '', 'A58'),
(1125, 'DL5471', '2020-01-15 11:15:00', '2020-01-15 11:15:00', 0, '', 'C86'),
(1126, 'WS6442', '2020-01-15 11:15:00', '2020-01-15 11:15:00', 0, '', 'C86'),
(1127, 'AC8460', '2020-01-14 16:50:00', '2020-01-14 16:50:00', 0, '', 'C83'),
(1128, 'UA8424', '2020-01-14 16:50:00', '2020-01-14 16:50:00', 0, '', 'C83'),
(1129, 'AC7597', '2020-01-14 17:15:00', '2020-01-14 17:15:00', 0, '', 'C81'),
(1130, 'AA4845', '2020-01-14 17:40:00', '2020-01-14 17:40:00', 0, '', 'C79'),
(1131, 'AC8753', '2020-01-14 17:50:00', '2020-01-14 17:50:00', 0, '', 'A28'),
(1132, 'TK8691', '2020-01-14 18:00:00', '2020-01-14 18:00:00', 0, '', 'A49'),
(1133, 'TS474', '2020-01-14 18:00:00', '2020-01-14 18:00:00', 0, '', 'A11'),
(1134, 'SWG471', '2020-01-14 15:45:00', '2020-01-14 15:45:00', 0, '', NULL),
(1135, 'TS493', '2020-01-14 18:30:00', '2020-01-14 18:30:00', 0, '', NULL),
(1136, 'SWG115', '2020-01-14 20:20:00', '2020-01-14 20:20:00', 0, '', NULL),
(1137, 'SWG526', '2020-01-14 21:35:00', '2020-01-14 21:35:00', 0, '', NULL),
(1138, 'AC7598', '2020-01-14 22:32:00', '2020-01-14 22:32:00', 0, '', NULL),
(1139, 'AA5137', '2020-01-14 22:36:00', '2020-01-14 22:36:00', 0, '', 'C85'),
(1140, 'AC322', '2020-01-14 23:21:00', '2020-01-14 23:21:00', 0, '', NULL),
(1141, 'AC8781', '2020-01-15 05:55:00', '2020-01-15 05:55:00', 0, '', NULL),
(1142, 'AC8901', '2020-01-14 06:07:00', '2020-01-14 07:42:00', 2, '', NULL),
(1143, 'AC8970', '2020-01-14 06:18:00', '2020-01-14 06:15:00', 2, '', NULL),
(1144, 'AC8701', '2020-01-14 06:24:00', '2020-01-14 09:29:00', 2, '', NULL),
(1145, 'AC8681', '2020-01-14 06:29:00', '2020-01-14 06:36:00', 2, '', NULL),
(1146, 'AC8015', '2020-01-14 06:30:00', '2020-01-14 07:30:00', 2, '', NULL),
(1147, 'UA8193', '2020-01-15 06:46:00', '2020-01-15 06:46:00', 0, '', NULL),
(1148, 'AC8031', '2020-01-15 10:02:00', '2020-01-15 10:02:00', 0, '', NULL),
(1149, 'TS221', '2020-01-15 11:15:00', '2020-01-15 11:15:00', 0, '', NULL),
(1150, 'MS9602', '2020-01-15 11:15:00', '2020-01-15 11:15:00', 0, '', NULL),
(1151, 'AC406', '2020-01-15 11:15:00', '2020-01-15 11:15:00', 0, '', NULL),
(1152, 'AC7958', '2020-01-15 11:25:00', '2020-01-15 11:25:00', 0, '', NULL),
(1153, 'SN9551', '2020-01-15 11:30:00', '2020-01-15 11:30:00', 0, '', NULL),
(1154, 'AC833', '2020-01-15 11:30:00', '2020-01-15 11:30:00', 0, '', NULL),
(1155, 'AC314', '2020-01-14 17:07:00', '2020-01-14 17:07:00', 0, '', NULL),
(1156, 'LH6571', '2020-01-14 17:07:00', '2020-01-14 17:07:00', 0, '', NULL),
(1157, 'OS8360', '2020-01-14 17:07:00', '2020-01-14 17:07:00', 0, '', NULL),
(1158, 'SN9556', '2020-01-14 17:07:00', '2020-01-14 17:07:00', 0, '', NULL),
(1159, 'AC8461', '2020-01-14 17:11:00', '2020-01-14 17:11:00', 0, '', NULL),
(1160, 'SN9618', '2020-01-14 17:11:00', '2020-01-14 17:11:00', 0, '', NULL),
(1161, 'UA8483', '2020-01-14 17:11:00', '2020-01-14 17:11:00', 0, '', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `updatedflights`
--

CREATE TABLE `updatedflights` (
  `id` int(11) NOT NULL,
  `flightId` int(11) NOT NULL,
  `active` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(60) NOT NULL,
  `password` varchar(60) NOT NULL,
  `role` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf16;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `airlines`
--
ALTER TABLE `airlines`
  ADD PRIMARY KEY (`iata`),
  ADD KEY `country_iso_code` (`country_iso_code`);

--
-- Indexes for table `airports`
--
ALTER TABLE `airports`
  ADD PRIMARY KEY (`iata`),
  ADD KEY `city_id` (`city_id`);

--
-- Indexes for table `alerts`
--
ALTER TABLE `alerts`
  ADD PRIMARY KEY (`phone`),
  ADD KEY `FK_ALERTS_FLIGHT_ID` (`flight_id`);

--
-- Indexes for table `cities`
--
ALTER TABLE `cities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `countries`
--
ALTER TABLE `countries`
  ADD PRIMARY KEY (`iso_alpha2_code`) USING BTREE;

--
-- Indexes for table `flightreferences`
--
ALTER TABLE `flightreferences`
  ADD PRIMARY KEY (`flightnumber`),
  ADD KEY `airline_iata` (`airline_iata`),
  ADD KEY `airport_iata` (`airport_iata`);

--
-- Indexes for table `flights`
--
ALTER TABLE `flights`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UQ_FLLIGHTS_FLIGHT_NUMBER_SCHEDUKED_TIME` (`flightref_number`,`scheduled_time`);

--
-- Indexes for table `updatedflights`
--
ALTER TABLE `updatedflights`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `flights`
--
ALTER TABLE `flights`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1162;

--
-- AUTO_INCREMENT for table `updatedflights`
--
ALTER TABLE `updatedflights`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `airlines`
--
ALTER TABLE `airlines`
  ADD CONSTRAINT `airlines_ibfk_1` FOREIGN KEY (`country_iso_code`) REFERENCES `countries` (`iso_alpha2_code`);

--
-- Constraints for table `airports`
--
ALTER TABLE `airports`
  ADD CONSTRAINT `airports_ibfk_1` FOREIGN KEY (`city_id`) REFERENCES `cities` (`id`);

--
-- Constraints for table `alerts`
--
ALTER TABLE `alerts`
  ADD CONSTRAINT `FK_ALERTS_FLIGHT_ID` FOREIGN KEY (`flight_id`) REFERENCES `flights` (`id`);

--
-- Constraints for table `flightreferences`
--
ALTER TABLE `flightreferences`
  ADD CONSTRAINT `flightreferences_ibfk_1` FOREIGN KEY (`airline_iata`) REFERENCES `airlines` (`iata`),
  ADD CONSTRAINT `flightreferences_ibfk_2` FOREIGN KEY (`airport_iata`) REFERENCES `airports` (`iata`);

--
-- Constraints for table `flights`
--
ALTER TABLE `flights`
  ADD CONSTRAINT `FK_FLIGHTS_FLIGHTREF_NUMBER` FOREIGN KEY (`flightref_number`) REFERENCES `flightreferences` (`flightnumber`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `flights_ibfk_1` FOREIGN KEY (`flightref_number`) REFERENCES `flightreferences` (`flightnumber`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
