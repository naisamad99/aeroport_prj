-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jan 17, 2020 at 06:18 AM
-- Server version: 8.0.18
-- PHP Version: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `aeroportdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `aeroports`
--

CREATE TABLE `aeroports` (
  `AeroportId` varchar(5) CHARACTER SET utf16 COLLATE utf16_general_ci NOT NULL,
  `NomAeroport` varchar(60) CHARACTER SET utf16 COLLATE utf16_general_ci DEFAULT NULL,
  `Ville` varchar(50) CHARACTER SET utf16 COLLATE utf16_general_ci DEFAULT NULL,
  `Pays` varchar(50) CHARACTER SET utf16 COLLATE utf16_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf16;

--
-- Dumping data for table `aeroports`
--

INSERT INTO `aeroports` (`AeroportId`, `NomAeroport`, `Ville`, `Pays`) VALUES
('ANU', 'V.C. Bird International Airport', 'Antigua', 'Algeria'),
('ATL', 'Hartsfield-Jackson Atlanta International Airport', 'Atlanta, GA', 'United States'),
('BOS', 'Logan International Airport', 'Boston, MA', 'United States'),
('BRU', 'Brussels Airport', 'Brussels', 'Belgium'),
('CDG', 'Charles de Gaulle Airport', 'Paris', 'France'),
('CLT', 'Charlotte Douglas International Airport', 'Charlotte, NC', 'United States'),
('CUN', 'Cancun International Airport', 'Cancun', 'Mexico'),
('DFW', 'Dallas/Fort Worth International Airport', 'Dallas, TX', 'United States'),
('FLL', 'Fort Lauderdale-Hollywood International Airport', 'Fort Lauderdale, FL', 'United States'),
('FRA', 'Frankfurt Airport', 'Frankfurt', 'UNKNOWN COUNTRY'),
('HOG', 'Frank Pais Airport', 'Holguin', 'Cuba'),
('JFK', 'John F. Kennedy International Airport', 'New York, NY', 'United States'),
('LGA', 'LaGuardia Airport', 'New York, NY', 'United States'),
('MSP', 'Minneapolis-St. Paul International Airport', 'Minneapolis, MN', 'United States'),
('ORD', 'O Hare International Airport', 'Chicago, IL', 'United States'),
('PHL', 'Philadelphia International Airport', 'Philadelphia, PA', 'United States'),
('PIT', 'Pittsburgh International Airport', 'Pittsburgh, PA', 'United States'),
('POP', 'La Union Airport', 'Puerto Plata', 'Dominica'),
('PUJ', 'Punta Cana International Airport', 'Punta Cana', 'Dominica'),
('PVR', 'Gustavo Diaz Ordaz International Airport', 'Puerto Vallarta', 'Mexico'),
('VRA', 'Juan Gualberto Gomez Airport', 'Varadero', 'Cuba'),
('YBG', 'Saguenay-Bagotville Airport', 'La Baie, QC', 'Canada'),
('YFC', 'Fredericton International Airport', 'Fredericton, NB', 'Canada'),
('YHZ', 'Halifax Stanfield International Airport', 'Halifax, NS', 'Canada'),
('YOW', 'Ottawa/Macdonald-Cartier International Airport', 'Ottawa, ON', 'Canada'),
('YQB', 'Quebec City Jean Lesage International Airport', 'Quebec, QC', 'Canada'),
('YQM', 'Greater Moncton International Airport', 'Moncton, NB', 'Canada'),
('YTZ', 'Billy Bishop Toronto City Airport', 'Toronto, ON', 'Canada'),
('YVO', 'Val-d Or Airport', 'Val D Or, QC', 'Canada'),
('YVR', 'Vancouver International Airport', 'Vancouver, BC', 'Canada'),
('YYC', 'Calgary International Airport', 'Calgary, AB', 'Canada'),
('YYG', 'Charlottetown Airport', 'Charlottetown, PE', 'Canada'),
('YYT', 'St. John s International Airport', 'St. John s, NL', 'Canada'),
('YYZ', 'Pearson International Airport', 'Toronto, ON', 'Canada'),
('ZSA', 'San Salvador Airport', 'San Salvador', 'Bassas da India');

-- --------------------------------------------------------

--
-- Table structure for table `compagnies`
--

CREATE TABLE `compagnies` (
  `CompagnieId` varchar(5) CHARACTER SET utf16 COLLATE utf16_general_ci NOT NULL,
  `NomCompagnie` varchar(60) CHARACTER SET utf16 COLLATE utf16_general_ci DEFAULT NULL,
  `logoUri` varchar(80) CHARACTER SET utf16 COLLATE utf16_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf16;

--
-- Dumping data for table `compagnies`
--

INSERT INTO `compagnies` (`CompagnieId`, `NomCompagnie`, `logoUri`) VALUES
('3H', 'Air Inuit', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/3h-logo.png'),
('5T', 'Canadian North', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/5t-logo.png'),
('A3', 'Aegean Airlines S.A.', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/a3-logo.png'),
('AA', 'American Airlines', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/aa-logo.png'),
('AC', 'Air Canada', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/ac-logo.png'),
('AF', 'Air France', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/af-logo.png'),
('AH', 'Air Algerie', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/ah-logo.png'),
('AI', 'Air India Limited', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/ai-logo.png'),
('AM', 'AeroMéxico', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/am-logo.png'),
('AS', 'Alaska Airlines', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/as-logo.png'),
('AT', 'Royal Air Maroc', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/at-logo.png'),
('AY', 'Finnair', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/ay-logo.png'),
('AZ', 'Alitalia', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/az-logo.png'),
('BA', 'British Airways', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/ba-logo.png'),
('CA', 'Air China LTD', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/ca-logo.png'),
('CI', 'China Airlines', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/ci-logo.png'),
('CM', 'Copa Airlines', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/cm-logo.png'),
('CZ', 'China Southern Airlines', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/cz-logo.png'),
('DL', 'Delta Air Lines', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/dl-logo.png'),
('EY', 'Etihad Airways', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/ey-logo.png'),
('G3', 'Gol Transportes Aéreos', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/g3-logo.png'),
('HU', 'Hainan Airlines', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/hu-logo.png'),
('IB', 'Iberia Airlines', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/ib-logo.png'),
('KE', 'Korean Air', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/ke-logo.png'),
('LA', 'LAN Airlines', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/la-logo.png'),
('LH', 'Lufthansa', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/lh-logo.png'),
('LO', 'LOT Polish Airlines', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/lo-logo.png'),
('LV', 'Level', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/ec-logo.png'),
('LX', 'Swiss International Air Lines', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/lx-logo.png'),
('ME', 'Middle East Airlines', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/me-logo.png'),
('MS', 'Egyptair', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/ms-logo.png'),
('MU', 'China Eastern Airlines', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/mu-logo.png'),
('NH', 'All Nippon Airways', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/nh-logo.png'),
('NZ', 'Air New Zealand', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/nz-logo.png'),
('OS', 'Austrian Airlines', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/os-logo.png'),
('OU', 'Croatia Airlines D.D.', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/ou-logo.png'),
('OZ', 'Asiana Airlines', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/oz-logo.png'),
('PB', 'PAL Airlines', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/pb-logo.png'),
('PD', 'Porter Airlines', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/pd-logo.png'),
('QF', 'Qantas', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/qf-logo.png'),
('QR', 'Qatar Airways', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/qr-logo.png'),
('QUE', ' Gouvernement Du Quebec', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/que-logo.png'),
('RJ', 'Royal Jordanian', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/rj-logo.png'),
('SA', 'South African Airways', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/sa-logo.png'),
('SN', 'Brussels Airlines', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/sn-logo.png'),
('SQ', 'Singapore Airlines', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/sq-logo.png'),
('SWG', 'Sunwing', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/swg-logo.png'),
('TG', 'Thai Airways International', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/tg-logo.png'),
('TK', 'Turkish Airlines', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/tk-logo.png'),
('TS', 'Air Transat', ''),
('UA', 'United Airlines', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/ua-logo.png'),
('VA', 'Virgin Australia', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/va-logo.png'),
('VS', 'Virgin Atlantic Airways', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/vs-logo.png'),
('WG', 'Sunwing Airlines', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/swg-logo.png'),
('WS', 'WestJet', ''),
('XOJ', 'XOJET', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/xoj-logo.png'),
('YN', 'Air Creebec', 'https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/yn-logo.png');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `VolCeduleId` int(11) NOT NULL,
  `NumTel` varchar(20) CHARACTER SET utf16 COLLATE utf16_general_ci NOT NULL,
  `DateInscription` datetime NOT NULL,
  `DateArret` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf16;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`VolCeduleId`, `NumTel`, `DateInscription`, `DateArret`) VALUES
(1128, '5147720280', '2020-01-14 15:41:08', NULL),
(1159, '5147720280', '2020-01-14 15:41:59', '2020-01-14 20:55:00');

-- --------------------------------------------------------

--
-- Table structure for table `utilisateurs`
--

CREATE TABLE `utilisateurs` (
  `NomUtilisateur` varchar(30) CHARACTER SET utf16 COLLATE utf16_general_ci NOT NULL,
  `MotDePasse` varchar(20) NOT NULL,
  `Role` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf16;

--
-- Dumping data for table `utilisateurs`
--

INSERT INTO `utilisateurs` (`NomUtilisateur`, `MotDePasse`, `Role`) VALUES
('admin1', '1234', 127),
('admin2', 'abcd', 127),
('user1', 'abcd', 0);

-- --------------------------------------------------------

--
-- Table structure for table `volcedules`
--

CREATE TABLE `volcedules` (
  `VolCeduleId` int(11) NOT NULL,
  `VolGeneriqueId` varchar(10) NOT NULL,
  `DatePrevue` datetime NOT NULL,
  `DateRevisee` datetime DEFAULT NULL,
  `Statut` tinyint(2) NOT NULL DEFAULT '0',
  `Porte` varchar(5) CHARACTER SET utf16 COLLATE utf16_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf16;

--
-- Dumping data for table `volcedules`
--

INSERT INTO `volcedules` (`VolCeduleId`, `VolGeneriqueId`, `DatePrevue`, `DateRevisee`, `Statut`, `Porte`) VALUES
(1020, 'SWG470', '2020-01-14 06:00:00', '2020-01-14 18:08:00', 2, 'A59'),
(1021, 'AC415', '2020-01-14 14:00:00', '2020-01-14 19:59:00', 2, 'A11'),
(1022, 'LH6570', '2020-01-14 14:00:00', '2020-01-14 19:59:00', 2, 'A11'),
(1023, 'LX4654', '2020-01-14 14:00:00', '2020-01-14 19:59:00', 2, 'A11'),
(1024, 'OS8246', '2020-01-14 14:00:00', '2020-01-14 19:59:00', 2, 'A11'),
(1025, 'AC8781', '2020-01-13 05:55:00', '2020-01-13 20:35:00', 2, 'null'),
(1026, 'AC8901', '2020-01-12 06:07:00', '2020-01-12 19:23:00', 2, 'null'),
(1027, 'AC8956', '2020-01-14 11:50:00', '2020-01-14 18:23:00', 2, 'null'),
(1028, 'CA7462', '2020-01-14 11:50:00', '2020-01-14 18:23:00', 2, 'null'),
(1029, 'LX4685', '2020-01-14 11:50:00', '2020-01-14 18:23:00', 2, 'null'),
(1030, 'AC411', '2020-01-16 12:00:00', '2020-01-16 12:00:00', 0, 'null'),
(1031, 'PD466', '2020-01-16 12:00:00', '2020-01-16 12:00:00', 0, 'null'),
(1032, 'AS4027', '2020-01-16 12:23:00', '2020-01-16 12:23:00', 0, 'null'),
(1033, 'IB4284', '2020-01-16 12:23:00', '2020-01-16 12:23:00', 0, 'null'),
(1034, 'UA8579', '2020-01-16 12:05:00', '2020-01-16 12:05:00', 0, 'null'),
(1035, 'AC8783', '2020-01-16 12:05:00', '2020-01-16 12:05:00', 0, 'null'),
(1036, 'A33078', '2020-01-16 12:05:00', '2020-01-16 12:05:00', 0, 'null'),
(1037, 'LH6794', '2020-01-16 12:05:00', '2020-01-16 12:05:00', 0, 'null'),
(1038, 'OS8205', '2020-01-16 12:05:00', '2020-01-16 12:05:00', 0, 'null'),
(1039, 'AC8726', '2020-01-16 18:00:00', '2020-01-16 18:00:00', 0, 'null'),
(1040, 'LX4652', '2020-01-16 18:00:00', '2020-01-16 18:00:00', 0, 'null'),
(1041, 'AC423', '2020-01-16 18:00:00', '2020-01-16 18:00:00', 0, 'null'),
(1042, 'OS8396', '2020-01-16 18:00:00', '2020-01-16 18:00:00', 0, 'null'),
(1043, 'TK8691', '2020-01-16 18:00:00', '2020-01-16 18:00:00', 0, 'null'),
(1044, 'AC8171', '2020-01-16 18:00:00', '2020-01-16 18:00:00', 0, 'null'),
(1045, 'NH7804', '2020-01-16 18:02:00', '2020-01-16 18:02:00', 0, 'null'),
(1046, 'AC3335', '2020-01-16 18:02:00', '2020-01-16 18:02:00', 0, 'null'),
(1047, 'UA3495', '2020-01-16 18:02:00', '2020-01-16 18:02:00', 0, 'null'),
(1048, 'NZ9856', '2020-01-16 18:02:00', '2020-01-16 18:02:00', 0, 'null'),
(1049, 'AC8831', '2020-01-16 05:30:00', '2020-01-16 05:30:00', 0, 'null'),
(1050, 'DL5520', '2020-01-16 05:40:00', '2020-01-16 05:40:00', 0, 'C84'),
(1051, 'G38326', '2020-01-16 05:40:00', '2020-01-16 05:40:00', 0, 'C84'),
(1052, 'KE3771', '2020-01-16 05:40:00', '2020-01-16 05:40:00', 0, 'C84'),
(1053, 'WS7922', '2020-01-16 05:40:00', '2020-01-16 05:40:00', 0, 'C84'),
(1054, 'AC1600', '2020-01-16 06:00:00', '2020-01-16 06:00:00', 0, 'null'),
(1055, 'UA8705', '2020-01-16 06:00:00', '2020-01-16 06:00:00', 0, 'null'),
(1056, 'AM7322', '2020-01-16 06:00:00', '2020-01-16 06:00:00', 0, 'null'),
(1057, 'DL7204', '2020-01-16 06:00:00', '2020-01-16 06:00:00', 0, 'null'),
(1058, 'KE6528', '2020-01-16 06:00:00', '2020-01-16 06:00:00', 0, 'null'),
(1059, 'WS6449', '2020-01-16 00:05:00', '2020-01-16 00:05:00', 0, 'C84'),
(1060, 'KE3835', '2020-01-16 00:05:00', '2020-01-16 00:05:00', 0, 'C84'),
(1061, 'AM4637', '2020-01-16 00:05:00', '2020-01-16 00:05:00', 0, 'C84'),
(1062, 'AF5756', '2020-01-16 00:05:00', '2020-01-16 00:05:00', 0, 'C84'),
(1063, 'DL5503', '2020-01-16 00:05:00', '2020-01-16 00:05:00', 0, 'C84'),
(1064, 'AC8901', '2020-01-16 06:07:00', '2020-01-16 06:07:00', 0, 'null'),
(1065, 'AC8970', '2020-01-16 06:18:00', '2020-01-16 06:18:00', 0, 'null'),
(1066, 'AC8701', '2020-01-16 06:24:00', '2020-01-16 06:24:00', 0, 'null'),
(1067, 'AC8681', '2020-01-16 06:29:00', '2020-01-16 06:29:00', 0, 'null'),
(1068, 'AC8015', '2020-01-16 06:30:00', '2020-01-16 06:30:00', 0, 'null'),
(1069, 'AC8831', '2020-01-15 05:30:00', '2020-01-15 05:30:00', 0, 'A2'),
(1070, 'DL5520', '2020-01-15 05:40:00', '2020-01-15 05:40:00', 0, 'C84'),
(1071, 'G38326', '2020-01-15 05:40:00', '2020-01-15 05:40:00', 0, 'C84'),
(1072, 'KE3771', '2020-01-15 05:40:00', '2020-01-15 05:40:00', 0, 'C84'),
(1073, 'WS7922', '2020-01-15 05:40:00', '2020-01-15 05:40:00', 0, 'C84'),
(1074, 'AC481', '2020-01-15 06:00:00', '2020-01-15 06:00:00', 0, 'A47'),
(1075, 'OS8390', '2020-01-15 06:00:00', '2020-01-15 06:00:00', 0, 'A47'),
(1076, 'SWG555', '2020-01-15 06:00:00', '2020-01-15 06:00:00', 0, 'A61'),
(1077, 'AA3981', '2020-01-15 06:00:00', '2020-01-15 06:00:00', 0, 'C85'),
(1078, 'SWG650', '2020-01-15 06:00:00', '2020-01-15 06:00:00', 0, 'A63'),
(1079, 'DL5517', '2020-01-15 11:56:00', '2020-01-15 11:56:00', 0, 'C87'),
(1080, 'AF8875', '2020-01-15 11:56:00', '2020-01-15 11:56:00', 0, 'C87'),
(1081, 'G38340', '2020-01-15 11:56:00', '2020-01-15 11:56:00', 0, 'C87'),
(1082, 'KE7379', '2020-01-15 11:56:00', '2020-01-15 11:56:00', 0, 'C87'),
(1083, 'AC8726', '2020-01-15 18:00:00', '2020-01-15 18:00:00', 0, 'null'),
(1084, 'LX4652', '2020-01-15 18:00:00', '2020-01-15 18:00:00', 0, 'null'),
(1085, 'AC423', '2020-01-15 18:00:00', '2020-01-15 18:00:00', 0, 'null'),
(1086, 'EY3859', '2020-01-15 18:00:00', '2020-01-15 18:00:00', 0, 'null'),
(1087, 'OS8396', '2020-01-15 18:00:00', '2020-01-15 18:00:00', 0, 'null'),
(1088, 'AM4637', '2020-01-15 00:05:00', '2020-01-15 00:05:00', 0, 'C84'),
(1089, 'AF5756', '2020-01-15 00:05:00', '2020-01-15 00:05:00', 0, 'C84'),
(1090, 'DL5503', '2020-01-15 00:05:00', '2020-01-15 00:05:00', 0, 'C84'),
(1091, 'KE3835', '2020-01-15 00:05:00', '2020-01-15 00:05:00', 0, 'C84'),
(1092, 'WS6449', '2020-01-15 00:05:00', '2020-01-15 00:05:00', 0, 'C84'),
(1093, 'AC8901', '2020-01-15 06:07:00', '2020-01-15 06:07:00', 0, 'null'),
(1094, 'AC8970', '2020-01-15 06:18:00', '2020-01-15 06:18:00', 0, 'null'),
(1095, 'AC8701', '2020-01-15 06:24:00', '2020-01-15 06:24:00', 0, 'null'),
(1096, 'AC8681', '2020-01-15 06:29:00', '2020-01-15 06:29:00', 0, 'null'),
(1097, 'AC8015', '2020-01-15 06:30:00', '2020-01-15 06:30:00', 0, 'null'),
(1098, 'UA8033', '2020-01-15 11:51:00', '2020-01-15 11:51:00', 0, 'null'),
(1099, 'AC8505', '2020-01-15 11:51:00', '2020-01-15 11:51:00', 0, 'null'),
(1100, 'SQ1019', '2020-01-15 12:05:00', '2020-01-15 12:05:00', 0, 'null'),
(1101, 'TG5822', '2020-01-15 12:05:00', '2020-01-15 12:05:00', 0, 'null'),
(1102, 'UA8579', '2020-01-15 12:05:00', '2020-01-15 12:05:00', 0, 'null'),
(1103, 'AC1801', '2020-01-15 18:00:00', '2020-01-15 18:00:00', 0, 'null'),
(1104, 'AC8171', '2020-01-15 18:00:00', '2020-01-15 18:00:00', 0, 'null'),
(1105, 'UA3495', '2020-01-15 18:02:00', '2020-01-15 18:02:00', 0, 'null'),
(1106, 'AC3335', '2020-01-15 18:02:00', '2020-01-15 18:02:00', 0, 'null'),
(1107, 'NZ9856', '2020-01-15 18:02:00', '2020-01-15 18:02:00', 0, 'null'),
(1108, 'AC8549', '2020-01-14 20:05:00', '2020-01-14 20:05:00', 0, 'null'),
(1109, 'UA8364', '2020-01-14 20:05:00', '2020-01-14 20:05:00', 0, 'null'),
(1110, 'AC429', '2020-01-14 21:30:00', '2020-01-14 21:30:00', 0, 'A48'),
(1111, 'AC8732', '2020-01-14 21:50:00', '2020-01-14 21:50:00', 0, 'A25'),
(1112, 'TK9110', '2020-01-14 21:50:00', '2020-01-14 21:50:00', 0, 'A25'),
(1113, 'DL5520', '2020-01-14 05:40:00', '2020-01-14 05:35:00', 2, 'C84'),
(1114, 'AM3544', '2020-01-15 05:40:00', '2020-01-15 05:40:00', 0, 'C84'),
(1115, 'KE3771', '2020-01-14 05:40:00', '2020-01-14 05:35:00', 2, 'C84'),
(1116, 'WS7922', '2020-01-14 05:40:00', '2020-01-14 05:35:00', 2, 'C84'),
(1117, 'G38326', '2020-01-14 05:40:00', '2020-01-14 05:35:00', 2, 'C84'),
(1118, 'AM4189', '2020-01-15 05:47:00', '2020-01-15 05:47:00', 0, 'C86'),
(1119, 'KE3836', '2020-01-15 05:47:00', '2020-01-15 05:47:00', 0, 'C86'),
(1120, 'UA3615', '2020-01-14 07:00:00', '2020-01-14 07:00:00', 1, 'C83'),
(1121, 'AC3054', '2020-01-14 07:00:00', '2020-01-14 07:00:00', 1, 'C83'),
(1122, 'NZ9806', '2020-01-14 07:00:00', '2020-01-14 07:00:00', 1, 'C83'),
(1123, 'NH7431', '2020-01-14 07:00:00', '2020-01-14 07:00:00', 1, 'C83'),
(1124, 'SWG426', '2020-01-14 09:20:00', '2020-01-14 09:20:00', 1, 'A58'),
(1125, 'DL5471', '2020-01-15 11:15:00', '2020-01-15 11:15:00', 0, 'C86'),
(1126, 'WS6442', '2020-01-15 11:15:00', '2020-01-15 11:15:00', 0, 'C86'),
(1127, 'AC8460', '2020-01-14 16:50:00', '2020-01-14 17:50:00', 4, 'C99'),
(1128, 'UA8424', '2020-01-14 16:50:00', '2020-01-14 16:55:00', 4, 'C99'),
(1129, 'AC7597', '2020-01-14 17:15:00', '2020-01-14 17:15:00', 0, 'C81'),
(1130, 'AA4845', '2020-01-14 17:40:00', '2020-01-14 17:40:00', 0, 'C79'),
(1131, 'AC8753', '2020-01-14 17:50:00', '2020-01-14 17:50:00', 0, 'A28'),
(1132, 'TK8691', '2020-01-14 18:00:00', '2020-01-14 18:00:00', 0, 'A49'),
(1133, 'TS474', '2020-01-14 18:00:00', '2020-01-14 18:00:00', 0, 'A11'),
(1134, 'SWG471', '2020-01-14 15:45:00', '2020-01-14 15:45:00', 0, 'null'),
(1135, 'TS493', '2020-01-14 18:30:00', '2020-01-14 18:30:00', 0, 'null'),
(1136, 'SWG115', '2020-01-14 20:20:00', '2020-01-14 20:20:00', 0, 'null'),
(1137, 'SWG526', '2020-01-14 21:35:00', '2020-01-14 21:35:00', 0, 'null'),
(1138, 'AC7598', '2020-01-14 22:32:00', '2020-01-14 22:32:00', 0, 'null'),
(1139, 'AA5137', '2020-01-14 22:36:00', '2020-01-14 22:36:00', 0, 'C85'),
(1140, 'AC322', '2020-01-14 23:21:00', '2020-01-14 23:21:00', 0, 'null'),
(1141, 'AC8781', '2020-01-15 05:55:00', '2020-01-15 05:55:00', 0, 'null'),
(1142, 'AC8901', '2020-01-14 06:07:00', '2020-01-14 07:42:00', 2, 'null'),
(1143, 'AC8970', '2020-01-14 06:18:00', '2020-01-14 06:15:00', 2, 'null'),
(1144, 'AC8701', '2020-01-14 06:24:00', '2020-01-14 09:29:00', 2, 'null'),
(1145, 'AC8681', '2020-01-14 06:29:00', '2020-01-14 06:36:00', 2, 'null'),
(1146, 'AC8015', '2020-01-14 06:30:00', '2020-01-14 07:30:00', 2, 'null'),
(1147, 'UA8193', '2020-01-15 06:46:00', '2020-01-15 06:46:00', 0, 'null'),
(1148, 'AC8031', '2020-01-15 10:02:00', '2020-01-15 10:02:00', 0, 'null'),
(1149, 'TS221', '2020-01-15 11:15:00', '2020-01-15 11:15:00', 0, 'null'),
(1150, 'MS9602', '2020-01-15 11:15:00', '2020-01-15 11:15:00', 0, 'null'),
(1151, 'AC406', '2020-01-15 11:15:00', '2020-01-15 11:15:00', 0, 'null'),
(1152, 'AC7958', '2020-01-15 11:25:00', '2020-01-15 11:25:00', 0, 'null'),
(1153, 'SN9551', '2020-01-15 11:30:00', '2020-01-15 11:30:00', 0, 'null'),
(1154, 'AC833', '2020-01-15 11:30:00', '2020-01-15 11:30:00', 0, 'null'),
(1155, 'AC314', '2020-01-14 17:07:00', '2020-01-14 17:07:00', 5, 'C99'),
(1156, 'LH6571', '2020-01-14 17:07:00', '2020-01-14 17:07:00', 0, 'null'),
(1157, 'OS8360', '2020-01-14 17:07:00', '2020-01-14 17:07:00', 0, 'null'),
(1158, 'SN9556', '2020-01-14 17:07:00', '2020-01-14 17:07:00', 0, 'null'),
(1159, 'AC8461', '2020-01-14 17:11:00', '2020-01-14 16:45:00', 5, 'C99'),
(1160, 'SN9618', '2020-01-14 17:11:00', '2020-01-14 17:11:00', 0, 'null'),
(1161, 'UA8483', '2020-01-14 17:11:00', '2020-01-14 17:30:00', 3, 'C99');

-- --------------------------------------------------------

--
-- Table structure for table `volgeneriques`
--

CREATE TABLE `volgeneriques` (
  `VolGeneriqueId` varchar(10) CHARACTER SET utf16 COLLATE utf16_general_ci NOT NULL,
  `AeroportId` varchar(5) CHARACTER SET utf16 COLLATE utf16_general_ci NOT NULL,
  `CompagnieId` varchar(5) CHARACTER SET utf16 COLLATE utf16_general_ci NOT NULL,
  `HeurePrevue` datetime NOT NULL DEFAULT '0001-01-01 00:00:00',
  `Direction` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf16;

--
-- Dumping data for table `volgeneriques`
--

INSERT INTO `volgeneriques` (`VolGeneriqueId`, `AeroportId`, `CompagnieId`, `HeurePrevue`, `Direction`) VALUES
('A33078', 'FRA', 'A3', '2001-01-01 12:05:00', 1),
('AA3981', 'DFW', 'AA', '2001-01-01 06:00:00', 0),
('AA4845', 'PHL', 'AA', '2001-01-01 17:40:00', 0),
('AA5137', 'CLT', 'AA', '2001-01-01 22:36:00', 1),
('AC1600', 'FLL', 'AC', '2001-01-01 06:00:00', 0),
('AC1801', 'ZSA', 'AC', '2001-01-01 18:00:00', 1),
('AC3054', 'ORD', 'AC', '2001-01-01 07:00:00', 0),
('AC314', 'YVR', 'AC', '2001-01-01 17:07:00', 1),
('AC322', 'YYC', 'AC', '2001-01-01 23:21:00', 1),
('AC3335', 'ORD', 'AC', '2001-01-01 18:02:00', 1),
('AC406', 'YYZ', 'AC', '2001-01-01 11:15:00', 1),
('AC411', 'YYZ', 'AC', '2001-01-01 12:00:00', 0),
('AC415', 'YYZ', 'AC', '2001-01-01 14:00:00', 0),
('AC423', 'YYZ', 'AC', '2001-01-01 18:00:00', 0),
('AC429', 'YYZ', 'AC', '2001-01-01 21:30:00', 0),
('AC481', 'YYZ', 'AC', '2001-01-01 06:00:00', 0),
('AC7597', 'ORD', 'AC', '2001-01-01 17:15:00', 0),
('AC7598', 'ORD', 'AC', '2001-01-01 22:32:00', 1),
('AC7958', 'YTZ', 'AC', '2001-01-01 11:25:00', 1),
('AC8015', 'YYT', 'AC', '2001-01-01 06:30:00', 1),
('AC8031', 'PHL', 'AC', '2001-01-01 10:02:00', 1),
('AC8171', 'PIT', 'AC', '2001-01-01 18:00:00', 1),
('AC833', 'BRU', 'AC', '2001-01-01 11:30:00', 1),
('AC8460', 'BOS', 'AC', '2001-01-01 16:50:00', 0),
('AC8461', 'BOS', 'AC', '2001-01-01 17:11:00', 1),
('AC8505', 'YFC', 'AC', '2001-01-01 11:51:00', 1),
('AC8549', 'YYG', 'AC', '2001-01-01 20:05:00', 0),
('AC8681', 'YBG', 'AC', '2001-01-01 06:29:00', 1),
('AC8701', 'YQB', 'AC', '2001-01-01 06:24:00', 1),
('AC8726', 'YQB', 'AC', '2001-01-01 18:00:00', 0),
('AC8732', 'YQB', 'AC', '2001-01-01 21:50:00', 0),
('AC8753', 'YVO', 'AC', '2001-01-01 17:50:00', 0),
('AC8781', 'YHZ', 'AC', '2001-01-01 05:55:00', 1),
('AC8783', 'YHZ', 'AC', '2001-01-01 12:05:00', 1),
('AC8831', 'YYZ', 'AC', '2001-01-01 05:30:00', 0),
('AC8901', 'YQM', 'AC', '2001-01-01 06:07:00', 1),
('AC8956', 'YOW', 'AC', '2001-01-01 11:50:00', 1),
('AC8970', 'YOW', 'AC', '2001-01-01 06:18:00', 1),
('AF5756', 'MSP', 'AF', '2001-01-01 00:05:00', 1),
('AF8875', 'JFK', 'AF', '2001-01-01 11:56:00', 0),
('AM3544', 'ATL', 'AM', '2001-01-01 05:40:00', 0),
('AM4189', 'MSP', 'AM', '2001-01-01 05:47:00', 0),
('AM4637', 'MSP', 'AM', '2001-01-01 00:05:00', 1),
('AM7322', 'YYZ', 'AM', '2001-01-01 06:00:00', 0),
('AS4027', 'ORD', 'AS', '2001-01-01 12:23:00', 0),
('CA7462', 'YOW', 'CA', '2001-01-01 11:50:00', 1),
('DL5471', 'LGA', 'DL', '2001-01-01 11:15:00', 0),
('DL5503', 'MSP', 'DL', '2001-01-01 00:05:00', 1),
('DL5517', 'JFK', 'DL', '2001-01-01 11:56:00', 0),
('DL5520', 'ATL', 'DL', '2001-01-01 05:40:00', 0),
('DL7204', 'YYZ', 'DL', '2001-01-01 06:00:00', 0),
('EY3859', 'YYZ', 'EY', '2001-01-01 18:00:00', 0),
('G38326', 'ATL', 'G3', '2001-01-01 05:40:00', 0),
('G38340', 'JFK', 'G3', '2001-01-01 11:56:00', 0),
('IB4284', 'ORD', 'IB', '2001-01-01 12:23:00', 0),
('KE3771', 'ATL', 'KE', '2001-01-01 05:40:00', 0),
('KE3835', 'MSP', 'KE', '2001-01-01 00:05:00', 1),
('KE3836', 'MSP', 'KE', '2001-01-01 05:47:00', 0),
('KE6528', 'YYZ', 'KE', '2001-01-01 06:00:00', 0),
('KE7379', 'JFK', 'KE', '2001-01-01 11:56:00', 0),
('LH6570', 'YYZ', 'LH', '2001-01-01 14:00:00', 0),
('LH6571', 'YVR', 'LH', '2001-01-01 17:07:00', 1),
('LH6794', 'FRA', 'LH', '2001-01-01 12:05:00', 1),
('LX4652', 'YQB', 'LX', '2001-01-01 18:00:00', 0),
('LX4654', 'YYZ', 'LX', '2001-01-01 14:00:00', 0),
('LX4685', 'YOW', 'LX', '2001-01-01 11:50:00', 1),
('MS9602', 'YYZ', 'MS', '2001-01-01 11:15:00', 1),
('NH7431', 'ORD', 'NH', '2001-01-01 07:00:00', 0),
('NH7804', 'ORD', 'NH', '2001-01-01 18:02:00', 1),
('NZ9806', 'ORD', 'NZ', '2001-01-01 07:00:00', 0),
('NZ9856', 'ORD', 'NZ', '2001-01-01 18:02:00', 1),
('OS8205', 'FRA', 'OS', '2001-01-01 12:05:00', 1),
('OS8246', 'YYZ', 'OS', '2001-01-01 14:00:00', 0),
('OS8360', 'YVR', 'OS', '2001-01-01 17:07:00', 1),
('OS8390', 'YYZ', 'OS', '2001-01-01 06:00:00', 0),
('OS8396', 'YYZ', 'OS', '2001-01-01 18:00:00', 0),
('PD466', 'YTZ', 'PD', '2001-01-01 12:00:00', 0),
('SN9551', 'BRU', 'SN', '2001-01-01 11:30:00', 1),
('SN9556', 'YVR', 'SN', '2001-01-01 17:07:00', 1),
('SN9618', 'BOS', 'SN', '2001-01-01 17:11:00', 1),
('SQ1019', 'FRA', 'SQ', '2001-01-01 12:05:00', 1),
('SWG115', 'ANU', 'SWG', '2001-01-01 20:20:00', 1),
('SWG426', 'PUJ', 'SWG', '2001-01-01 09:20:00', 0),
('SWG470', 'POP', 'SWG', '2001-01-01 06:00:00', 0),
('SWG471', 'POP', 'SWG', '2001-01-01 15:45:00', 1),
('SWG526', 'PVR', 'SWG', '2001-01-01 21:35:00', 1),
('SWG555', 'CUN', 'SWG', '2001-01-01 06:00:00', 0),
('SWG650', 'HOG', 'SWG', '2001-01-01 06:00:00', 0),
('TG5822', 'FRA', 'TG', '2001-01-01 12:05:00', 1),
('TK8691', 'YYZ', 'TK', '2001-01-01 18:00:00', 0),
('TK9110', 'YQB', 'TK', '2001-01-01 21:50:00', 0),
('TS221', 'CDG', 'TS', '2001-01-01 11:15:00', 1),
('TS474', 'YYZ', 'TS', '2001-01-01 18:00:00', 0),
('TS493', 'VRA', 'TS', '2001-01-01 18:30:00', 1),
('UA3495', 'ORD', 'UA', '2001-01-01 18:02:00', 1),
('UA3615', 'ORD', 'UA', '2001-01-01 07:00:00', 0),
('UA8033', 'YFC', 'UA', '2001-01-01 11:51:00', 1),
('UA8193', 'YYG', 'UA', '2001-01-01 06:46:00', 1),
('UA8364', 'YYG', 'UA', '2001-01-01 20:05:00', 0),
('UA8424', 'BOS', 'UA', '2001-01-01 16:50:00', 0),
('UA8483', 'BOS', 'UA', '2001-01-01 17:11:00', 1),
('UA8579', 'FRA', 'UA', '2001-01-01 12:05:00', 1),
('UA8705', 'FLL', 'UA', '2001-01-01 06:00:00', 0),
('WS6442', 'LGA', 'WS', '2001-01-01 11:15:00', 0),
('WS6449', 'MSP', 'WS', '2001-01-01 00:05:00', 1),
('WS7922', 'ATL', 'WS', '2001-01-01 05:40:00', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `aeroports`
--
ALTER TABLE `aeroports`
  ADD PRIMARY KEY (`AeroportId`);

--
-- Indexes for table `compagnies`
--
ALTER TABLE `compagnies`
  ADD PRIMARY KEY (`CompagnieId`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`VolCeduleId`,`NumTel`);

--
-- Indexes for table `utilisateurs`
--
ALTER TABLE `utilisateurs`
  ADD PRIMARY KEY (`NomUtilisateur`);

--
-- Indexes for table `volcedules`
--
ALTER TABLE `volcedules`
  ADD PRIMARY KEY (`VolCeduleId`),
  ADD KEY `VolGeneriqueId` (`VolGeneriqueId`);

--
-- Indexes for table `volgeneriques`
--
ALTER TABLE `volgeneriques`
  ADD PRIMARY KEY (`VolGeneriqueId`),
  ADD KEY `AeroportId` (`AeroportId`),
  ADD KEY `CompagnieId` (`CompagnieId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `volcedules`
--
ALTER TABLE `volcedules`
  MODIFY `VolCeduleId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1162;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`VolCeduleId`) REFERENCES `volcedules` (`VolCeduleId`);

--
-- Constraints for table `volcedules`
--
ALTER TABLE `volcedules`
  ADD CONSTRAINT `volcedules_ibfk_1` FOREIGN KEY (`VolGeneriqueId`) REFERENCES `volgeneriques` (`VolGeneriqueId`);

--
-- Constraints for table `volgeneriques`
--
ALTER TABLE `volgeneriques`
  ADD CONSTRAINT `volgeneriques_ibfk_1` FOREIGN KEY (`AeroportId`) REFERENCES `aeroports` (`AeroportId`),
  ADD CONSTRAINT `volgeneriques_ibfk_2` FOREIGN KEY (`CompagnieId`) REFERENCES `compagnies` (`CompagnieId`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
