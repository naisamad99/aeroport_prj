<?php

class Collection implements IteratorAggregate {
    
    private $items; 
    
    public function __construct(iterable $items = null) {
        echo 'Constructor collection';
        $this->items = $items;
                      
    }

    public function getIterator() {
        return new ArrayIterator($this->items);
    }

}
