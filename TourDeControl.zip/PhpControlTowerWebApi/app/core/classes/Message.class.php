<?php

class Message {
    
    public static function set($code, $msgsuppl='') {
        if (!isset($_SESSION['msg_code'])) {
            $_SESSION['msg_code'] = $code;
            if (!empty($msgsuppl)) $_SESSION['msg_suppl'] = $msgsuppl;
        }
    }

    public static function get() {
        $msg = '';
        if (isset($_SESSION['msg_code'])) {
            if (array_key_exists($_SESSION['msg_code'], Message::_MESSAGES)) {
                $msg = Message::_MESSAGES[$_SESSION['msg_code']];
                if (isset($_SESSION['msg_suppl'])) $msg[0] .= ': '. $_SESSION['msg_suppl'];
            }
        }
        return $msg;
    }

    public static function clear() {
        if (isset($_SESSION['msg_code'])) {
            unset($_SESSION['msg_code']);
        }
        if (isset($_SESSION['msg_suppl'])) {
            unset($_SESSION['msg_suppl']);
        }
    }

    public static function display() {
        if (isset($_SESSION['msg_code'])) {
            $color = '';
            $background = '';
            $msg = Message::get()[0];
            $categ = Message::get()[1];
            switch ($categ) {
                case MessageCategory::Information : $color = 'lightgreen';
                    $background = 'darkgreen';
                    break;
                case MessageCategory::Avertissement : $color = 'lightorange';
                    $background = 'darkorange';
                    break;
                case MessageCategory::Erreur : $color = 'lightred';
                    $background = 'darkred';
                    break;
            }
            
            $div_st = '<div style="width:50%; margin:auto; padding:5px; background:' . $background . '; color:' . $color . '; border: 2px solid ' . $color . ';text-align:center">';
            $title = '<p>' . Enum('MessageCategory', $categ) . '</p><hr>';
            echo $div_st . $title . '<p>' . $msg . '</p>' . '</div>';
            
            Message::clear();
        }
    }

    // Categorie message : 0 : Erreur, 1: Avertissement, 2: Information
    const _MESSAGES = [
            'APP000' => ["", MessageCategory::Erreur], // custom message 
            'APP001' => ["This link does'nt exist", MessageCategory::Erreur],
            'APP002' => ["Une erreur inattendue s'est produite.", MessageCategory::Erreur],
        
            'DBS000' => ["Une erreur inattendue s'est produite.", MessageCategory::Erreur],
        
            'DBS001' => ["Echec de connexion a la base de données", MessageCategory::Erreur],
                
        
        
        
        // Not Set ou Indefini
                'SYS999' => ["Fatal error", MessageCategory::Erreur]
    ];

}
