<?php

class DataAccessObject2 {
    
    private $pdo;
    
    public function __construct($dataSourceName, $userName, $password) {
        $options = [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_EMULATE_PREPARES => true,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_OBJ
        ];

        $this->pdo = new PDO($dataSourceName, $userName, $password, $options);
        
    }

    public function query($query, $params = array()) {
        $query = trim($query, ' ');
        // A utiliser pour savoir si la commande SQL est un SELECT 
        $sqlCommand = strtoupper(substr($query, 0, 6));
        $objToReturn = new DAOReturnedObject();
        try {
            $statement = $this->pdo->prepare($query);
            $data = $statement->execute($params);
            if (strtoupper($sqlCommand) == 'SELECT') { $data = $statement->fetchAll(); }
                
            $objToReturn->data = $data;
            
        } catch (Exception $ex) {
            $objToReturn->code = $ex->getCode();
            if ($ex->getCode() == 23000) {
                $objToReturn->log = 'Duplicate';
            } 
            else {$objToReturn->log = $ex->getMessage() . ' ,  Params->' . var_dump($params);}
            //throw $ex;
        }
        return $objToReturn;
    }
    
    public function close() {
        unset($this->pdo);
    }

}

/*
 * 
 * PDO::ATTR_EMULATE_PREPARES: Active ou désactive la simulation des requêtes préparées. 
 * Certains pilotes ne supportent pas nativement les requêtes préparées ou en ont un support limité. 
 * Ce paramètre force PDO à émuler (TRUE et la simulation des requêtes préparées sont pris en charge par le pilote)
 * les requêtes préparées ou (FALSE) à utiliser l'interface native. 
 * Il tentera toujours une émulation si le pilote n'a pas de support natif. bool requis.
 * 
 * PDO::ATTR_DEFAULT_FETCH_MODE : Définit le mode de récupération par défaut. 
 * 
 */
