<?php

class DAOReturnedObject {
    public $code = 0;
    public $data = [];
    public $log = '';
}
