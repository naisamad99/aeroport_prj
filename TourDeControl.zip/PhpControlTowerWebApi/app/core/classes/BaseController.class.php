<?php

abstract class BaseController {

    protected $view;
    protected $model;
    protected $ctrl_action;
    

    /*****************************************************************************
    *** M O D E L 
    *****************************************************************************/

    protected function setModel($data = []) {
        
        $classname = $this->getRequeredFileName()['class_dir_name'].'Model';
        $this->model = new $classname();

    }
    
    protected function getModel() {
        return $this->model;
    }
    
    /*****************************************************************************
    *** V I E W 
    *****************************************************************************/
    
    protected function setView($data = [], $title = '') {
        
        $pathStruct = $this->getRequeredFileName();
        $requeredFile = VIEW_DIR . $pathStruct['class_dir_name'] . DIRECTORY_SEPARATOR . $pathStruct['method_file_name'] . '.phtml';
        $this->view = new View($requeredFile, $data, $title);
                
    }
    protected function getView() {
        return $this->view;
    }
    
    protected function redirectToUrl($url) {
        header('Location: '.$url);
    }

    protected function redirectToRoute($queryString = '') {
        //$url = $_SERVER['HTTP_HOST'].$_SERVER['SCRIPT_NAME'].'?q='.$queryString;
        if (empty($queryString)) $queryString = 'home';
        $url = './?q='.$queryString;
        header('Location: '.$url);
    }
    
    protected function setCtrlAction($classmethod) {
        $this->ctrl_action = $classmethod;
    } 
    
    /*****************************************************************************
    *** MTHODE PRIVEE QUI RECUPERE LE NAMESPACE, NOM DE LA CLASS ET LE NOM DE 
     *  LA METHODE QUI REPRESENTE L'ACTION A EXECUTER  
    *****************************************************************************/
    
    private function getRequeredFileName() {
        if (substr_count($this->ctrl_action, '::') != 1 || substr_count($this->ctrl_action, '\\') > 1) {
            return null;
        }

        $str_arr = explode('::', $this->ctrl_action);

        $method_name = $str_arr[1];
        $str_arr = explode('\\', $str_arr[0]);
        if (isset($str_arr[1])) {
            $namespace = $str_arr[0];
            $class_name = strtolower(substr_replace($str_arr[1],"", -10));
        }
        else {
            $namespace = '';
            $class_name = strtolower(substr_replace($str_arr[0],"", -10));
        }
            
        return ['namespace' => $namespace, 'class_dir_name' => $class_name, 'method_file_name' => $method_name];
    }

}
