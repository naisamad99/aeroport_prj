<?php

class Session {
    
    public static function connected() {
        return isset($_SESSION['is_connected']);
    }

    public static function set($username, $accounttype = 1) {
        if (!isset($_SESSION[$username])) {
            $_SESSION['is_connected'] = [$username, $accounttype];
        }
    }

    public static function getUserName() {
        if (isset($_SESSION['is_connected'])) {
            return $_SESSION['is_connected'][0];
        } else {
            return 'Login';
        }
    }

    public static function getUserType() {
        if (isset($_SESSION['is_connected'])) {
            return $_SESSION['is_connected'][1];
        } else {
            return 0;
        }
    }

}
