<?php

// Definition des Enumerations

class MessageCategory extends Enum {
    
    const __Default = self::Erreur;
    const Erreur = 0;
    const Avertissement = 1;
    const Information = 2;
    
}

