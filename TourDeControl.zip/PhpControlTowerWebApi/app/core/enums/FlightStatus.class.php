<?php

// Definition des Enumerations

class FlightStatus extends Enum {
    
    const __Default = self::Non_Commence;
    const Non_Commence = 0;
    const Retarde = 1;
    const Avance = 2;
    const Arrive = 3;
    const Parti = 4;
    const Annule = 5;
    
}

