<?php

//date_default_timezone_set("Canada/Montreal");
date_default_timezone_set("America/New_York");
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
set_time_limit(500);

// Definition des chemins des repertoires de l'application

define('APP_DIR', dirname(__DIR__) . DIRECTORY_SEPARATOR);
define('CORE_DIR', APP_DIR . 'core' . DIRECTORY_SEPARATOR);
define('MODEL_DIR', APP_DIR . 'model' . DIRECTORY_SEPARATOR);
define('CTRL_DIR', APP_DIR . 'controller' . DIRECTORY_SEPARATOR);
define('VIEW_DIR', APP_DIR . 'view' . DIRECTORY_SEPARATOR);
define('DATA_DIR', APP_DIR . 'data' . DIRECTORY_SEPARATOR);
define('RESSOURCES_DIR', str_replace($_SERVER["DOCUMENT_ROOT"], '/', str_replace('\\', '/', APP_DIR . 'ressources' . DIRECTORY_SEPARATOR)));

// Definition des constantes pour les parametre de connexion a BD
const DB_HOST = "localhost";
const DB_PORT = "";
const DB_USERNAME = "root";
const DB_PASSWORD = "123456";
const DB_NAME = "controltowerdb";
// Definition du Data Source Name
const DSN = 'mysql:host=' . DB_HOST . '; dbname=' . DB_NAME;


// Definition des paths de l'application et leurs ajout dans le path du systeme PHP

$app_paths = [APP_DIR, CORE_DIR, CORE_DIR . 'classes', CORE_DIR . 'enums', MODEL_DIR, MODEL_DIR . 'classes', VIEW_DIR, CTRL_DIR];
set_include_path(get_include_path() . PATH_SEPARATOR . implode(PATH_SEPARATOR, $app_paths));

// Definition de l'extenstion des fichiers classe
const CLASS_EXT = '.class.php';
// 
const DEFAULT_ACTION = 'index';
const DEFAULT_CONTROLLER = 'homeController';
const CLASS_SEPARATOR = '::';
const DEFAULT_PAGE = DEFAULT_CONTROLLER . CLASS_SEPARATOR . DEFAULT_ACTION;

// Fonctions globales

function println($str) {
    echo $str . '<br>';
}

function Enum($_enum, $value) {
    return new $_enum($value);
}

function sanitize_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

function webForm($controller, $action, $webform_name, $extention = '.phtml') {
    return VIEW_DIR . '_webforms' . DIRECTORY_SEPARATOR . $controller . DIRECTORY_SEPARATOR . 
            $action. DIRECTORY_SEPARATOR. $webform_name . $extention;
}

function component($compponent_name, $extention = '.phtml') {
    return VIEW_DIR . '_components' . DIRECTORY_SEPARATOR . $compponent_name . $extention;
    
}
function header_($header_name, $extention = '.phtml') {
    return VIEW_DIR . '_header'. DIRECTORY_SEPARATOR . $header_name . $extention;
}

function footer($footer_name, $extention = '.phtml') {
    return VIEW_DIR . '_footer'. DIRECTORY_SEPARATOR . $footer_name . $extention;
}

function css($css_name, $extention = '.css') {
    return VIEW_DIR . '_lib'. DIRECTORY_SEPARATOR  . 'css'. DIRECTORY_SEPARATOR . $css_name . $extention;
}

function printMessage($msg, $categ = MessageCategory::Information) {
    $color = ''; $background = '';
    switch ($categ) {
        case MessageCategory::Information : $color = 'lightgreen';
            $background = 'darkgreen';
            break;
        case MessageCategory::Avertissement : $color = 'lightorange';
            $background = 'darkorange';
            break;
        case MessageCategory::Erreur : $color = 'lightred';
            $background = 'darkred';
            break;
    }
    if (isset($msg)) {
        $div_st = '<div style="width:50%; margin:auto; padding:5px; background:' . $background . '; color:' . $color . '; border: 2px solid ' . $color . ';text-align:center">';
        if (!empty($categ)) {
            $title = '<p>' . Enum('MessageCategory',$categ) . '</p><hr>';
        } else {
            $title = '';
        }
        echo $div_st . $title . '<p>' . $msg . '</p>' . '</div>';
    }
}


