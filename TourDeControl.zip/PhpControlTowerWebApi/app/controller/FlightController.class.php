<?php

class FlightController extends BaseController {
    
    public function jsondata($datetime_start = '', $datetime_end = '') {

        $this->model = new AirportQueryInterface();

        if (empty($datetime_start)) {
            $flights = $this->model->selectWithQuery("SELECT * FROM flights ORDER BY scheduled_time ASC;");
        }
        else {
            if (empty($datetime_end)) {
                $flights = $this->model->selectWithQuery("SELECT * FROM flights WHERE scheduled_time>='" . $datetime_start . "' ORDER BY scheduled_time ASC;");
            }
            else { 
                //$flights = $this->model->selectWithQuery("SELECT * FROM flights WHERE scheduled_time>='" . $datetime_start . "' AND scheduled_time<='"  . $datetime_end . "';");
                $flights = $this->model->selectWithQuery("SELECT * FROM flights WHERE scheduled_time >= '2020-01-03 06:00:00' AND scheduled_time <= '2020-01-03 06:00:00' ORDER BY scheduled_time ASC;");
            }
        }
        $countries = $cities = $airports = $airlines = $flightreferences = [];
        if (count($flights) > 10) {
            $countries = $this->model->selectWithQuery("SELECT * FROM countries;");
            $cities = $this->model->selectWithQuery("SELECT * FROM cities;");
            $airports = $this->model->selectWithQuery("SELECT * FROM airports;");
            $airlines = $this->model->selectWithQuery("SELECT * FROM airlines;");
            $flightreferences = $this->model->selectWithQuery("SELECT * FROM flightreferences;");
        }
        $data = ["countries"=> $countries, "cities"=> $cities, "airports"=> $airports, 
                               "airlines"=> $airlines, "flightreferences"=> $flightreferences, "flights"=> $flights];
        $json = json_encode($data);
        
        echo($json);
    }
    
    public function jsonlist($datetime_start = '', $datetime_end = '') {

        $this->model = new AirportQueryInterface();

        $countries = $this->model->selectWithQuery("SELECT * FROM countries");
        $cities = $this->model->selectWithQuery("SELECT * FROM cities");
        $airports = $this->model->selectWithQuery("SELECT * FROM airports");
        $airlines = $this->model->selectWithQuery("SELECT * FROM airlines");
        $flightreferences = $this->model->selectWithQuery("SELECT * FROM flightreferences");
        if (empty($datetime_start)) {
            $flights = $this->model->selectWithQuery("SELECT * FROM flights");
        }
        else {
            if (empty($datetime_end)) {
                $flights = $this->model->selectWithQuery("SELECT * FROM flights WHERE scheduled_time>=" . $datetime_start);
            }
            else { 
                $flights = $this->model->selectWithQuery("SELECT * FROM flights WHERE scheduled_time>=" . $datetime_start . "estimated_time>="  . $datetime_end);
            }
        }
        
        $data = ["countries"=> $countries, "cities"=> $cities, "airports"=> $airports, 
                               "airlines"=> $airlines, "flightreferences"=> $flightreferences, "flights"=> $flights];

        $json = json_encode($data);
        
        echo($json);
    }
    
    public function countries($result = 'JSON') {

        $countries = [];
        if (strtoupper($result) == 'JSON') {
            $this->model = new AirportQueryInterface();
            $countries = $this->model->selectWithQuery("SELECT * FROM countries");
        }
        $json = json_encode($countries);
        echo($json);
    }
    
    public function cities($result = 'JSON') {

        $cities = [];
        if (strtoupper($result) == 'JSON') {
            $this->model = new AirportQueryInterface();
            $cities = $this->model->selectWithQuery("SELECT * FROM cities");
        }
        $json = json_encode($cities);
        echo($json);
    }
    
    public function airlines($result = 'JSON') {

        $airlines = [];
        if (strtoupper($result) == 'JSON') {
            $this->model = new AirportQueryInterface();
            $airlines = $this->model->selectWithQuery("SELECT * FROM airlines");
        }
        $json = json_encode($airlines);
        echo($json);
    }
    
    public function airports($result = 'JSON') {

        $airports = [];
        if (strtoupper($result) == 'JSON') {
            $this->model = new AirportQueryInterface();
            $airports = $this->model->selectWithQuery("SELECT * FROM airports");
        }
        $json = json_encode($airports);
        echo($json);
    }
    
    public function cleanflightrefs() {

        $this->model = new AirportQueryInterface();
        $flightreferences = $this->model->selectWithQuery("SELECT flightnumber FROM flightreferences;");
        foreach ($flightreferences as $flightreference) {
            $flights = $this->model->selectWithQuery("SELECT id FROM flights WHERE flightref_number='" . $flightreference->flightnumber . "';");
            if (count($flights) == 0){
                $this->model->selectWithQuery("DELETE FROM flightreferences WHERE flightnumber='" . $flightreference->flightnumber . "';");
                echo '['.$flightreference->flightnumber . ']';
            }
        }
    }
    
    // flight/updateflightdates/flights
    public function updateflightdates($tablename = '') {  
        if (strtolower($tablename) != 'flights') {
            $date = new DateTime();
            echo $date;
            //echo '<No table>'; 
            return;
        }
        $this->model = new AirportQueryInterface2();
        $flights = $this->model->selectWithQuery("SELECT * FROM flights;")->data;
        $out = '';
        $count = 0;
        foreach ($flights as $flight){
            $sdate = substr($flight->scheduled_time, 0, 10);
            $stime = substr($flight->scheduled_time, 10);
            switch ($sdate) {
                case  '2020-01-12': $sdate = '2020-01-13'; break;
                case  '2020-01-13': $sdate = '2020-01-14'; break;
                case  '2020-01-14': $sdate = '2020-01-15'; break;
                case  '2020-01-15': $sdate = '2020-01-16'; break;
            }
            $edate = substr($flight->estimated_time, 0, 10);
            $etime = substr($flight->estimated_time, 10);
            switch ($edate) {
                case  '2020-01-12': $edate = '2020-01-13'; break;
                case  '2020-01-13': $edate = '2020-01-14'; break;
                case  '2020-01-14': $edate = '2020-01-15'; break;
                case  '2020-01-15': $edate = '2020-01-16'; break;
            }
            $query = "UPDATE flights SET scheduled_time='" . ($sdate . $stime) . "', estimated_time='" . ($edate . $etime) . 
                                  "' WHERE id=" . $flight->id . ";";
            
            //$out .= $query . '<br>';
            
            $result = $this->model->updateWithQuery($query);
            if ($result['code'] != 0) {
                $count++; $out .= '['. $flight->id . '/' . $flight->flightref_number .': err code: ' . $result['code'] . ']';
            }
            
        }
        $count = count($flights) - $count;
        $out .= "<br><p>Table: VolCedules<br>Nombre d'enregistrements proposé: " . count($flights) . "<br>Nombre d'enregistrements ajoutés dans la table: " . 
                $count . '</p><br>';
      
        
        
        echo $out;
        
    }
    public function recordtodb($tablename, $mode = 'a'){
        $_mode = strtoupper($mode);
        if ($_mode != 'A' && $_mode != 'N') return '';
        $this->model = new AirportQueryInterface2();
        $log = '';
        if ($_mode == 'N') {
            // $ro =  returned object
            $ro = $this->model->selectWithQuery('SELECT count(id) count FROM cities');
            if ($ro->data[0]->count != 0) {
                $ro = $this->model->selectWithQuery('DELETE FROM flights WHERE 1'); 
                $ro = $this->model->selectWithQuery('DELETE FROM flightreferences WHERE 1'); 
                $ro = $this->model->selectWithQuery('DELETE FROM airports WHERE 1'); 
                $ro = $this->model->selectWithQuery('DELETE FROM cities WHERE 1'); 
                if ($ro->code == 0) {
                    $log = ' -> [Informa] Table contents deleted. ';
                } else {
                    $log = ' -> [Warning] Not able to delete table content: ' . $ro->log . '\n ';
                }
            }    
        } 
        $_tablename = strtolower($tablename);
        $array = json_decode($_POST[$_tablename]);
        $i = 0;
        switch($_tablename)  {
            case 'cities': 
                foreach ($array as $city) {
                    $ro = $this->model->insert(new City($city->id, $city->name, $city->state, $city->country_id));  
                    if ($ro->code == 0) $i++;
                } 
                $log .= $i . ' ' . $_tablename . ' recorded. \n';
                break;
            case 'airports': 
                foreach ($array as $airport) {
                    $ro = $this->model->insert(new Airport($airport->iata, $airport->name, $airport->city_id, $airport->url_logo));  
                    if ($ro->code == 0) $i++;
                } 
                $log .= $i . ' ' . $_tablename . ' recorded. \n';
                break; 
            case 'airlines': 
                foreach ($array as $airline) {
                    $ro = $this->model->insert(new Airline($airline->iata, $airline->name, $airline->oaci, $airline->country_iso_code, $airline->url_icon));  
                    if ($ro->code == 0) $i++;
                } 
                $log .= $i . ' ' . $_tablename . ' recorded. \n';
                break; 
            case 'flightreferences': 
                echo $_tablename . ' length: ' . count($array) . ' \n'; 
                foreach ($array as $flightreference) {
                    $ro = $this->model->insert(new FlightReference($flightreference->flightnumber, $flightreference->airline_iata, 
                                                                   $flightreference->airport_iata, $flightreference->direction, $flightreference->time));  
                    if ($ro->code == 0) $i++;
                } 
                $log .= $i . ' ' . $_tablename . ' recorded. \n';
                break; 
            case 'flights': 
                echo $_tablename . ' length: ' . count($array) . ' \n';
                foreach ($array as $flight) {
                    $ro = $this->model->insert(new Flight($flight->flightref_number, $flight->scheduled_time, $flight->estimated_time, 
                                                                                                        $flight->status, $flight->terminal, $flight->gate));  
                    if ($ro->code == 0) $i++;
                } 
                $log .= $i . ' ' . $_tablename . ' recorded. \n';
                break; 
            default: $log = 'Unknown table name';
        }
        echo $log;
    }

    
    // For testing
    public function test(){
        
        
        
    }
    
    public function list($airport = '', $direction = '', $year = '', $month = '', $day = '', $hour = '', $result_type = '', $limit = '') {

        if (empty($airport)) {
            $airport = 'YUL';
        }
        if (empty($direction)) {
            $direction = 'Departures';
        }

        $queryString = 'year=' . $year . '&month=' . $month . '&date=' . $day . '&hour=' . $hour;

        $url = 'https://www.flightstats.com/v2/flight-tracker/' . $direction . '/' . $airport . '/?' . $queryString;  //echo $url;     
        //file_get_contents() 
        $url_content = file_get_contents($url); //echo ', content length = '. strlen($url_content);

        $start = strpos($url_content, '__NEXT_DATA__');
        $end = strpos($url_content, ',"loading":{"LOAD_FLIGHT_TRACKER_ROUTE');
        $jsonStr = substr($url_content, $start + 16, $end - $start - 16) . '}}}';
        $jsonStr = str_replace("\u0026", "&", $jsonStr);
        $jsonStr = str_replace("\\", "\\\\", $jsonStr);
        $jsonStr = str_replace("'", " ", $jsonStr);

        switch($result_type) {
            case "": 
            case "NBER": 
                    $flights = json_decode($jsonStr)->props->initialState->flightTracker->route->flights; 
                    echo count($flights); 
                    break;
            case "JSON": echo $jsonStr; break;
            case "UPDT": 
                    $limit = 30;
                    $flights = json_decode($jsonStr)->props->initialState->flightTracker->route->flights;
                    if ($direction == 'Departures') { $this->updateDepartureFlights($flights); }
                    else { $this->updateArrivalFlights($flights, $limit); }
                    break;
            default: echo 'Unknown result type';
        }
    }

    public function detail($airline = '', $flightnumber = '', $yearmonthdayflightid = '', $result_type = '') {

        $url = 'https://www.flightstats.com/v2/flight-tracker/' . $airline . '/' . $flightnumber . '/?' . $yearmonthdayflightid;  //echo $url; 
        //file_get_contents() 
        $url_content = file_get_contents($url); //echo $url_content;

        $start = strpos($url_content, '__NEXT_DATA__');
        //$end = strpos($url_content, '__NEXT_LOADED_PAGES__'); 
        $end = strpos($url_content, 'LOAD_FLIGHT_TRACKER_FLIGHT');
        $jsonStr = substr($url_content, $start + 16, $end - $start - 30) . '}}}}';
        $jsonStr = str_replace("\u0026", "&", $jsonStr);
        $jsonStr = str_replace("\\", "\\\\", $jsonStr);
        $jsonStr = str_replace("'", " ", $jsonStr);
        
        switch($result_type) {
            case "": return $jsonStr; break;
            case "JSON": echo $jsonStr; break;
            default: echo 'Unknown result type';
        }
        
    }
    
    private function updateDepartureFlights($_flights = [], $limit = '') {
        
        $direction = 0;
        
        $countries = new CountryModel(); 
        $cities = new CityModel(); 
        $airlines = new AirlineModel();
        $airports = new AirportModel(); 
        $flightrefs = new FlightReferenceModel(); 
        $flights = new FlightModel(); 
        $count = 0;
        echo count($_flights).'<br>';
        foreach ($_flights as $_flight) {
            $yearmonthdayflightid = substr($_flight->url, strpos($_flight->url, "?") + 1);
            $data = $this->detail($_flight->carrier->fs, $_flight->carrier->flightNumber, $yearmonthdayflightid);
            $flight = json_decode($data)->props->initialState->flightTracker->flight; //props.initialState.flightTracker.flight
            $airport = $flight->arrivalAirport;
            $airline = $flight->ticketHeader;
            
            // check if country code exist in the database
            $index = $countries->getCountryIndex($airport->country);
            if ($index == -1) $airport->country = 'UNK'; 
            
            // Insert the city if not exist
            if (isset($airport->state)) $state= $airport->state; else $state=''; 
            //echo  '[State:'.$state.']';
            $city_id = $cities->addCity(new City(-1, $airport->city, $state, $airport->country)) + 1;
            
            // Insert the airport if not exist
            $airport_rec = $airports->addAirport(new Airport($airport->iata, $airport->name, $city_id));
            if (!is_null($airport_rec)) $airport_id = $airport_rec->iata; 
           
            // Insert the airline if not exist
            $airline_rec = $airlines->addAirline(new Airline($airline->carrier->fs, $airline->carrier->name, '', 'UNK', $airline->iconURL));
            if (!is_null($airline_rec)) $airline_id = $airline_rec->iata; 
            
            // Insert the flightref if not exist
            $flightnumber = $airline->carrier->fs . $airline->flightNumber;
            $time = '0001-01-01 ' . $flight->departureAirport->times->scheduled->time24 . ':00';
            $flightrefs->addFlightReference(new FlightReference($flightnumber, $airline_id, $airport_id, $direction, $time)); 
            
            // Insert the flight if not exist
            echo '<p>[flightNumber: '.$flightnumber.'-'.$flight->schedule->scheduledDeparture.'|';
            $flights->addFlight(new Flight($flightnumber, $this->formatDateTime($flight->schedule->scheduledDeparture),
                                $this->formatDateTime($flight->schedule->scheduledDeparture), $this->getStatusId($flight->status->status),
                                $flight->departureAirport->terminal, $flight->departureAirport->gate));
            echo ']';
            if (!empty($limit))
                if (++$count > $limit) {
                    break;
                }
        }
        
        echo $countries->saveChanges();
        echo $cities->saveChanges();
        echo $airlines->saveChanges();
        echo $airports->saveChanges();
        echo $flightrefs->saveChanges();
        echo $flights->saveChanges();
        echo '</p>';
        
    }

    private function updateArrivalFlights($_flights = [], $limit = '') {
        
        $direction = 1;
        
        $countries = new CountryModel(); 
        $cities = new CityModel(); 
        $airlines = new AirlineModel();
        $airports = new AirportModel(); 
        $flightrefs = new FlightReferenceModel(); 
        $flights = new FlightModel(); 
        $count = 0;
        echo count($_flights).'<br>';
        foreach ($_flights as $_flight) {
            $yearmonthdayflightid = substr($_flight->url, strpos($_flight->url, "?") + 1);
            $data = $this->detail($_flight->carrier->fs, $_flight->carrier->flightNumber, $yearmonthdayflightid);
            $flight = json_decode($data)->props->initialState->flightTracker->flight; //props.initialState.flightTracker.flight
            $airport = $flight->departureAirport;;
            $airline = $flight->ticketHeader;
            
            // check if country code exist in the database
            $index = $countries->getCountryIndex($airport->country);
            if ($index == -1) $airport->country = 'UNK'; 
            
            // Insert the city if not exist
            if (isset($airport->state)) $state= $airport->state; else $state=''; 
            //echo  '[State:'.$state.']';
            $city_id = $cities->addCity(new City(-1, $airport->city, $state, $airport->country)) + 1;
            
            // Insert the airport if not exist
            $airport_rec = $airports->addAirport(new Airport($airport->iata, $airport->name, $city_id));
            if (!is_null($airport_rec)) $airport_id = $airport_rec->iata; 
           
            // Insert the airline if not exist
            $airline_rec = $airlines->addAirline(new Airline($airline->carrier->fs, $airline->carrier->name, '', 'UNK', $airline->iconURL));
            if (!is_null($airline_rec)) $airline_id = $airline_rec->iata; 
            
            // Insert the flightref if not exist
            $flightnumber = $airline->carrier->fs . $airline->flightNumber;
            $time = '0001-01-01 ' . $flight->arrivalAirport->times->scheduled->time24 . ':00';
            $flightrefs->addFlightReference(new FlightReference($flightnumber, $airline_id, $airport_id, $direction, $time)); 
            
            // Insert the flight if not exist
            echo '<p>[flightNumber: '.$flightnumber.'-'.$flight->schedule->scheduledArrival.'|';
            $flights->addFlight(new Flight($flightnumber, $this->formatDateTime($flight->schedule->scheduledArrival),
                                $this->formatDateTime($flight->schedule->scheduledArrival), $this->getStatusId($flight->status->status),
                                $flight->arrivalAirport->terminal, $flight->arrivalAirport->gate));
            echo ']';
            if (!empty($limit))
                if (++$count > $limit) {
                    break;
                }
        }
        echo '<br/><hr/>';
        echo $countries->saveChanges();
        echo $cities->saveChanges();
        echo $airlines->saveChanges();
        echo $airports->saveChanges();
        echo $flightrefs->saveChanges();
        echo $flights->saveChanges();
        echo '</p>';
        
    }
    
    
    private function getStatusId($statusString) {

        switch ($statusString) {
            case 'On time' : return 0;
            case 'Delayed' : return 3;
            case 'Departed': return 1;
            case 'Arrived' : return 2;
            case 'Canceled': return 5;
            default: return 4;
        }
    }
    public function loadedflights() {
        
        header('Content-Type: text/event-stream');
        header('Cache-Control: no-cache');

        $time = date('r');
        echo "data: The server time is: {$time}\n\n";
        flush();
        
//        if ($_COOKIE['loaded_flight_number']) echo $_COOKIE['loaded_flight_number'];
//        echo 0;
        
    }
    
    
    // Private functions
    
    private function formatDateTime($dateTimeStr) {

        return date_format(date_create($dateTimeStr), "Y-m-d H:i:s");
    }

    private function addDateTimeAndFormat($dateTimeStr, $number, $unity) {

        $date = date_create($dateTimeStr);
        date_add($date, date_interval_create_from_date_string($number . ' ' . $unity));
        return date_format($date, "Y-m-d H:i:s");
    }
    
}
