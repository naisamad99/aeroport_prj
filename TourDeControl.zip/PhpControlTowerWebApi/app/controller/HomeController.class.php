<?php

class HomeController extends BaseController {

    public function index() {

        $this->ctrl_action = __METHOD__;
        $data = [];

        $this->setView($data, 'Home');
        $this->view->render();
    }

    public function test() {
        
        $data = '';
        //$model = new AirportQueryInterface();
        
        //$data = $model->selectFromTables(['name'], ['countries'], 'iso_alpha2_code=\'US\'');
        //$data = $model->selectWithQuery("SELECT * FROM countries WHERE iso_alpha2_code='US'");
        //$country = new Country('WAR', 'WAR');
        //$data = $model->insert($country);
        
        //echo date_format(date_create("2019-12-11T05:50:00.000"),"H:i:s");
        $date=date_create("2013-03-15 20:30:00");
        date_add($date,date_interval_create_from_date_string("2 minutes"));
        echo date_format($date,"Y-m-d H:i:s");
        
    }

    public function sendsms() {

        $this->ctrl_action = __METHOD__;
        $data = [];

        $this->setView($data, 'Send SMS');

        $this->view->render();
    }

    public function sms() {

        try {
            $message = 'Hello ebayi';
            $phoneNumber = '4384087640';

            if ($message != null && $phoneNumber != null) {
                $url = "http://192.168.2.10:8090/SendSMS?username=nsmad&password=1234&phone=" . $phoneNumber . "&message=" . urlencode($message);
                println($url);

                $curl = curl_init($url);
                curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
                $curl_response = curl_exec($curl);
                if ($curl_response === false) {
                    $info = curl_getinfo($curl);
                    curl_close($curl);
                    die('Error occurred' . var_export($info));
                }
                curl_close($curl);
                $response = json_decode($curl_response);
                if ($response->status == 200) {
                    echo 'Message has been sent';
                } else {
                    'Technical Problem';
                }
            }
        } catch (Exception $ex) {
            echo "Exception: " . $ex;
        }
    }

    private function microtime_float() {
        list($usec, $sec) = explode(" ", microtime());
        return ((float) $usec + (float) $sec);
    }

}
