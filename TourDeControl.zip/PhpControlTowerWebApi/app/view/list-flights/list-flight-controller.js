console.log('Loading of ListFlightController =...');

function ListFlightController($scope, $http, $log) {
    
    // initialization
    $scope.initialization = function () {
       
        
    }
    
    // Methods
    
    $scope.setParameters = function () {
       
    }
        
    
    // initialization
    $scope.initialization();

}

