console.log('Loading of UpdateFlightController =...');

function UpdateFlightController($scope, $http, $log) {

    // initialization
    $scope.initialization = function () {
        $scope.period_day_numbers = [{desc : '1 day', val: 1}, {desc : '2 days', val: 2}, {desc : '3 days', val: 3}, {desc : '4 days', val: 4}, {desc : '5 days', val: 5}, {desc : '6 days', val: 6}, {desc : '7 days', val: 7}];
        $scope.period_day_number = $scope.period_day_numbers[0]; // 2 par defaut
        $scope.airports = [{name: 'Montreal Airport', code: 'YUL'}, {name: 'Quebec City Jean Lesage International Airport', code: 'YQB'}];
        $scope.airport = $scope.airports[0];
        $scope.ourAirport = {active: true, city: '', classification: '', country: '', fs: '', iata: '', icao: '', name: '', state: '', timeZoneRegionName: ''};
        $scope.timeranges = [{desc: '00h-06h', val: 0}, {desc: '06h-12h', val: 6}, {desc: '12h-18h', val: 12}, {desc: '18h-24h', val: 18}];
        $scope.flightArrivalTotal = 0;
        $scope.flightArrivalLoaded = 0;
        $scope.flightArrivalRatio = 0;
        $scope.flightDepartureTotal = 0;
        $scope.flightDepartureLoaded = 0;
        $scope.flightDepartureRatio = 0;
        $scope.flightLoadedTotal = 0;
        $scope.flightTotal = 0;
        $scope.showWaitingMsg = false;
    }
    
    // Methods
        
    $scope.updateFlightList = function (direction, result_type) {
        if (['NBER','JSON','UPDT'].indexOf(result_type) === -1) return;
        var date = new Date($scope.selecteddate.val);
        var year = date.getFullYear();
        var month = date.getMonth() + 1;
        var day = date.getDate();
        var nbr;        
        var url = './flight/list/'+ $scope.airport.code + '/' + direction + '/' + year + '/' + month + '/' + day + '/' + 
                                    $scope.timerange.val + '/' + result_type; $log.log(url);
        $http({method: 'GET', url : url})
            .then(function (response) {

                switch(result_type) {
                    case "": 
                    case "NBER": 
                            $scope.status = response.status;
                            $scope.content = response.data;
                            nbr = parseInt(response.data);
                            if (direction === 'Departures') { $scope.flightDepartureTotal +=  nbr; }
                            else { $scope.flightArrivalTotal +=  nbr; }
                            $scope.flightTotal += nbr;
                            break;
                            
                    case "JSON": 
                            $scope.status += response.status  + ', ';
                            if (response.data.props) {
                                var flights = response.data.props.initialState.flightTracker.route.flights;
                                nbr = flights.length; 
                                $scope.flighttotal += nbr;
                                if (direction === 'Departures') { $scope.flightDepartureLoaded += nbr; }
                                else { $scope.flightArrivalLoaded += nbr; }
                                $scope.flightLoadedTotal += nbr;
                            }
                            flightlist = response.data;
                            $scope.content = response.data;
                            break;
                            
                    case "UPDT": 
                            $scope.status = response.status;
                            var pos = response.data.indexOf('<');
                            nbr = parseInt(response.data.substr(0, pos));
                            $log.log('nbr='+ nbr);
                            $scope.content = response.data.substr(pos);
                            if (direction === 'Departures') { 
                                $scope.flightDepartureLoaded += nbr;
                                $scope.flightDepartureRatio = $scope.flightDepartureLoaded / $scope.flightDepartureTotal * 100;
                                document.getElementById("update-status-departure-log").innerHTML += '<br/><hr/>' + $scope.content;
                            }
                            else { 
                                $scope.flightArrivalLoaded += nbr;
                                $scope.flightArrivalRatio = $scope.flightArrivalLoaded / $scope.flightArrivalTotal * 100;
                                document.getElementById("update-status-arival-log").innerHTML += '<br/><hr/>' + $scope.content;
                            }
                            $scope.flightLoadedTotal += nbr;
                            if ($scope.flightTotal === $scope.flightLoadedTotal) $scope.showWaitingMsg = false;
                            break;
                }
                

            }, function (response) {
                $log.log('Error loading: status: '+ response.status + 'url->[' + url + ']');
            });
    }

    $scope.getFlightDetail = function (flight, index) {
        var url_qry_str = flight.url.substr(flight.url.indexOf("?") + 1);
        var url = './flight/detail/'+ flight.carrier.fs + '/' + flight.carrier.flightNumber + '/' + url_qry_str; //$log.log(url);
        $http({method: 'GET', url: url})
            .then(function (response) {

                $log.log('Reponse > Status: ' + response.data);
                $scope.flightloaded++;
                var elapsedtime = ((new Date()) - $scope.starttime) / 1000; // number of secondes
                var hours = Math.floor(elapsedtime /3600); 
                var minutes = Math.floor((elapsedtime-(hours*3600))/60); 
                var secondes = Math.floor(elapsedtime-(hours*3600)-(minutes*60)); 
                $scope.elapsedtime = hours + ':' + minutes + ':' + secondes;
                
                

            }, function (response) {
                $log.log('Error loading: status: '+ response.status + 'url->[' + url + ']');
            });
    }
    
    $scope.loadFlightListToDatabase = function() {
        var result_type; //'' or 'NBER' : FlightNumber, 'UPDT' : Update, 'JSON' :  JSON Format
        var directions = ['Departures', 'Arrivals'];
        var direction;
        $scope.showWaitingMsg = true;
        $scope.starttime = new Date();
        result_type = 'NBER';
        for (var dirIndex = 1; dirIndex < 2; dirIndex++){
            direction = directions[dirIndex];    
            $scope.dates = getDates($scope.period_day_number.val);
            for (var i = 0; i < $scope.period_day_number.val; i++){ // $scope.period_day_number.val
                $scope.selecteddate = $scope.dates[i];
                for (var j = 1; j < 2; j++){ // 4 : 0..3
                    $scope.timerange = $scope.timeranges[j];
                    $scope.updateFlightList(direction, result_type);
                }
            }
        }
        $log.log('Requesting NBER done.');
        result_type = 'UPDT';
        for (var dirIndex = 1; dirIndex < 2; dirIndex++){
            direction = directions[dirIndex];    
            for (var i = 0; i < $scope.period_day_number.val; i++){ // 0..($scope.period_day_number.val-1)
                $scope.selecteddate = $scope.dates[i];
                for (var j = 1; j < 2; j++){ // 0..(4-1)
                    $scope.timerange = $scope.timeranges[j];
                    $scope.updateFlightList(direction, result_type);
                    $log.log('direction='+ direction+', i='+ i+', j='+ j);
                }
            }
        }
        $log.log('Requesting UPDT done.');
    }
    
    serverSentEvent = function(){
        if(typeof(EventSource) !== "undefined") {
            var source = new EventSource("./flight/loadedflights");
            source.onmessage = function(event) {
              $scope.ssevent = event.data + "<br>";
            };
        } else {
          $scope.ssevent = "Sorry, your browser does not support server-sent events...";
        }
    }
    // Initialization
    $scope.initialization();
    
}

function DatabaseService($http) {
    var url = '';
    this.getDatabaseData = function(){
        return $http.get(url);
    }
}


