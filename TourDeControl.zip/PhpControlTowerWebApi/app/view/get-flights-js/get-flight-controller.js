console.log('Loading of GetFlightController =...');
function GetFlightController($scope, $http, $log, databaseSevice) {
    const DEPARTURE = 0, ARRIVAL = 1;
    const tablenames = ['flights', 'flightreferences', 'airports', 'cities'];
        
    // initialization
    $scope.initialization = function () {
        $scope.databaseSevice = databaseSevice;
        $scope.period_day_numbers = [{desc: '1 day', val: 1}, {desc: '2 days', val: 2}, {desc: '3 days', val: 3}, {desc: '4 days', val: 4}, {desc: '5 days', val: 5}, {desc: '6 days', val: 6}, {desc: '7 days', val: 7}];
        $scope.period_day_number = $scope.period_day_numbers[3]; // 2 par defaut
        $scope.airports = [{name: 'Montreal Airport', code: 'YUL'}, {name: 'Quebec City Jean Lesage International Airport', code: 'YQB'}];
        $scope.airport = $scope.airports[0];
        //$scope.ourAirport = {active: true, city: '', classification: '', country: '', fs: '', iata: '', icao: '', name: '', state: '', timeZoneRegionName: ''};
        $scope.timeranges = [{desc: '00h-06h', val: 0}, {desc: '06h-12h', val: 6}, {desc: '12h-18h', val: 12}, {desc: '18h-24h', val: 18}];
        $scope.flightArrivalTotal = 0;
        $scope.flightArrivalLoaded = 0;
        $scope.flightArrivalRatio = 0;
        $scope.flightDepartureTotal = 0;
        $scope.flightDepartureLoaded = 0;
        $scope.flightDepartureRatio = 0;
        $scope.flightLoadedTotal = 0;
        $scope.flightTotalRatio = 100;
        $scope.flightTotal = 0;
    }

    // Methods

    $scope.updateFlightList = function (direction, result_type) {
        if ((['NBER', 'JSON', 'UPDT'].indexOf(result_type) === -1) || (direction > 1)) { return; }
        var direction_title = (direction === DEPARTURE) ? 'Departures' : 'Arrivals';
        var date = new Date($scope.selecteddate.val);
        var year = date.getFullYear();
        var month = date.getMonth() + 1;
        var day = date.getDate();
        var nbrmax_range = 7, flightnbr;
        var url = './flight/list/' + $scope.airport.code + '/' + direction_title + '/' + year + '/' + month + '/' + day + '/' +
                $scope.timerange.val + '/' + result_type;
        $log.log(url);
        $http({method: 'GET', url: url})
                .then(function (response) {

                    switch (result_type) {
                        case "":
                        case "NBER":
                            $scope.status = response.status;
                            $scope.content = response.data;
                            flightnbr = parseInt(response.data); if (flightnbr > nbrmax_range) flightnbr = nbrmax_range;
                            if (direction === DEPARTURE) {
                                $scope.flightDepartureTotal += flightnbr;
                            } else {
                                $scope.flightArrivalTotal += flightnbr;
                            }
                            $scope.flightTotal += flightnbr;
                            break;
                        case "JSON":
                            $scope.status += response.status + ', ';
                            if (response.data.props) {
                                var flights = response.data.props.initialState.flightTracker.route.flights;
                                flightnbr = flights.length; if (flightnbr > nbrmax_range) flightnbr = nbrmax_range;
                                for (var i = 0; i < flightnbr; i++) {
                                    var flight = flights[i];
                                    var index = -1;
                                    if (flight.carrier.fs) index = $scope.databaseSevice.getAirlineIndex(flight.carrier.fs);
                                    if (index !== -1) {
                                       $scope.getFlightDetail(flight, direction); 
                                    }
                                    else {
                                        if (direction === DEPARTURE) {
                                                $scope.flightDepartureTotal--;
                                        } else {
                                            $scope.flightArrivalTotal--;
                                        }
                                        $scope.flightTotal--;
                                    }
                                }
                            }
                            $scope.content = response.data;
                            break;
                    }
                }, function (response) {
                    $log.log('Error loading: status: ' + response.status + 'url->[' + url + ']');
                });
    }

    $scope.getFlightDetail = function (flight, direction) {
        var url_qry_str = flight.url.substr(flight.url.indexOf("?") + 1);
        var url = './flight/detail/' + flight.carrier.fs + '/' + flight.carrier.flightNumber + '/' + url_qry_str + '/JSON'; //$log.log(url);
        $http({method: 'GET', url: url})
                .then(function (response) {
                    if (response.data.props && response.data.props.initialState) {
                        processFlight(response.data.props.initialState.flightTracker.flight , direction);
                    } else $log.log('props.initialState undefined ->url: '+ url);
                    if (direction === DEPARTURE) {
                        $scope.flightDepartureLoaded++;
                        $scope.flightDepartureRatio = ($scope.flightDepartureLoaded / $scope.flightDepartureTotal * 100).toFixed(2);
                    } else {
                        $scope.flightArrivalLoaded++;
                        $scope.flightArrivalRatio = ($scope.flightArrivalLoaded / $scope.flightArrivalTotal * 100).toFixed(2);
                    }
                    $scope.flightLoadedTotal++;
                    $scope.flightTotalRatio = ($scope.flightTotal === 0) ? 0 : ($scope.flightLoadedTotal / $scope.flightTotal * 100).toFixed(2);
                    if ($scope.flightTotalRatio == 100.00) {
                        $scope.transferDataToDatabase();
                    }
                    
                }, function (response) {
                    $log.log('Error loading: status: ' + response.status + 'url->[' + url + ']');
                });
    }

    $scope.loadFlightListToDatabase = function () {
        
        var result_type; //'' or 'NBER' : FlightNumber, 'UPDT' : Update, 'JSON' :  JSON Format
        var directions = [DEPARTURE, ARRIVAL]; //['Departures', 'Arrivals'];
        var direction;
        $scope.starttime = new Date();
        var day_st = 1, day_end = 2; // 0 to $scope.period_day_number.val
        var dir_st = 0, dir_end = 2;
        var range_st = 0, range_end = 4; // 0 to 3
        result_type = 'NBER';
        for (var dirIndex = dir_st; dirIndex < dir_end; dirIndex++) {
            direction = directions[dirIndex];
            $scope.dates = getDates($scope.period_day_number.val);
            for (var i = day_st; i < day_end; i++) { // $scope.period_day_number.val
                $scope.selecteddate = $scope.dates[i];
                for (var j = range_st; j < range_end; j++) { 
                    $scope.timerange = $scope.timeranges[j];
                    $scope.updateFlightList(direction, result_type);
                }
            }
        }

        result_type = 'JSON';
        for (var dirIndex = dir_st; dirIndex < dir_end; dirIndex++) {
            direction = directions[dirIndex];
            for (var i = day_st; i < day_end; i++) { // 0..($scope.period_day_number.val-1)
                $scope.selecteddate = $scope.dates[i];
                for (var j = range_st; j < range_end; j++) { // 0..(4-1)
                    $scope.timerange = $scope.timeranges[j];
                    $scope.updateFlightList(direction, result_type);
                    $log.log('direction=' + ((direction === DEPARTURE) ? 'Departures' : 'Arrivals') + ', i=' + i + ', j=' + j);
                }
            }
        }
        $log.log('LOOP END');
    }


    // Private methods
    
    processFlight = function(flight, direction) {
        var our_airport = {}, other_airport = {};
        if (direction === DEPARTURE) {
            our_airport = flight.departureAirport;
            other_airport = flight.arrivalAirport;
        } else {
            our_airport = flight.arrivalAirport;
            other_airport = flight.departureAirport;
        }
        if (our_airport === undefined || our_airport.times === undefined || our_airport.times.scheduled === undefined || our_airport.times.scheduled.time24 === undefined) return;
        var airline = flight.ticketHeader;
        var flightnumber = airline.carrier.fs + airline.flightNumber;
        //$log.log('<*>'+flightnumber + '<*>'); $log.log('=> scheduled.time24->[' + our_airport.times.scheduled.time24 +']');
        if (!our_airport.times.estimatedActual.time24) our_airport.times.estimatedActual.time24 = '';
        var datetime = getEstimatedDateTime(our_airport.date, our_airport.times.scheduled.time24, 					
                           our_airport.times.estimatedActual.time24, our_airport.times.estimatedActual.title);
        
        var flightindex = $scope.databaseSevice.getFlightIndex(flightnumber, datetime.scheduled); 
        if (flightindex === -1) {
            if (our_airport.terminal === null) our_airport.terminal = '';
            var airline = flight.ticketHeader;
            
            // check if country code exist in the database
            if ($scope.databaseSevice.getCountryIsoCode(other_airport.country) === -1) other_airport.country = 'UNK';
            
            // Insert the city if not exist
            if (!other_airport.state || other_airport.state === null) other_airport.state = '';
            var city_id = $scope.databaseSevice.addCity(new City(-1, other_airport.city, other_airport.state, other_airport.country)) + 1;
            
            // Insert the airport if not exist
            var other_airport_index = $scope.databaseSevice.addAirport(new Airport(other_airport.iata, other_airport.name, city_id, ''));
            
            // Insert the airline if not exist
            var airline_index = $scope.databaseSevice.addAirline(new Airline(airline.carrier.fs, airline.carrier.name, '', 'UNK', airline.iconURL));
            
            // Insert the flightref if not exist
            var time = '2001-01-01 ' + our_airport.times.scheduled.time24 + ':00';
            $scope.databaseSevice.addFlightRef(new FlightReference(flightnumber, $scope.databaseSevice.getAirlineIata(airline_index), 
                                                                    $scope.databaseSevice.getAirportIata(other_airport_index), direction, time));
            
            // Insert the flight if not exist
            var status = '';
            if (flight.status.status) status = flight.status.status;
            $scope.databaseSevice.addFlight(new Flight(flightnumber, datetime.scheduled, datetime.estimated, getStatusId(status), 
                                                                                                        our_airport.terminal, our_airport.gate));
            //$log.log('Airport: ' + airport.name + ', country: ' + airport.country);
        }
            
    
    }

    $scope.transferDataToDatabase = function () {
        //$scope.databaseSevice.printCountries(20);
        $scope.databaseSevice.printCities();
        $scope.databaseSevice.printAirports();
        //$scope.databaseSevice.printAirlines();
        $scope.databaseSevice.printFlightRefs();
        $scope.databaseSevice.printFlights();
        var mode = 'a';
        //$scope.postData(tablenames.length - 1, mode);
    }

    $scope.postData = function(level, mode){
        $log.log('LEVEL : ' + level);
        var tablename = tablenames[level--];
        var postData = null;
        switch(tablename) {
            case 'cities':  postData = 'cities=' + JSON.stringify($scope.databaseSevice.getCitiesToTransfer()); break;
            case 'airports': postData = 'airports=' + JSON.stringify($scope.databaseSevice.getAirportsToTransfer()); break;
            case 'flightreferences': postData = 'flightreferences=' + JSON.stringify($scope.databaseSevice.flightrefs); break;
            case 'flights': postData = 'flights=' + JSON.stringify($scope.databaseSevice.flights); break;
        }
        if (postData === null) {
            $log.log('[Warning] Unknow table name. ');
            return;
        }
        $http({
                method : 'POST',
                url : './flight/recordtodb/' + tablename + '/' + mode,
                data: postData,
                headers : {'Content-Type': 'application/x-www-form-urlencoded'}  
            })
            .then(function(response){
                $log.log(tablename + ' record request status: ' + response.status);
                $log.log(response.data);
                if (level >= 0) $scope.postData(level, 'a');
                else $log.log('End of transfert');
            }, function(response){
                $log.log(tablename + ' record request status: ' + response.status);
                $log.log(response.data);
            });
    }
    
    $scope.cleanFlightreferencesTable =  function(){
        $log.log('cleanFlightreferencesTable()');
        $http({method: 'GET', url: './flight/cleanflightrefs'})
                .then(function(response){
                    $scope.status = response.status;
                    $scope.content = response.data;
                    $log.log('Clean');
                    
                },function(response){
                    $log.log('Error');
                    $scope.status = response.status;
                    $scope.content = response.data;
                });
    }
    
    getEstimatedDateTime = function (scheduled_datetime, scheduled_time, estimated_time, estimated_title) {
        var sch_datetime = scheduled_datetime.substr(0, 10) + ' ' + scheduled_time + '.00';
        var est_datetime = null;
        if (!isEmpty(estimated_time) && estimated_title !== "Estimated") {
            var d = new Date(scheduled_datetime + '-00:00');
            if (parseInt(scheduled_time.replace(':', '')) - parseInt(estimated_time.replace(':', '')) > 200) { d.setDate(d.getDate() + 1); }
            est_datetime = d.toISOString().substr(0, 10) + ' ' + estimated_time + '.00';
        }
        return {"scheduled": sch_datetime, "estimated": est_datetime};
    }
    
    getStatusId = function(statusString) {

        switch (statusString) {
            case 'On time' : return 0;
            case 'Scheduled' : return 0;
            case 'Departed' : return 1;
            case 'Arrived' : return 2;
            case 'Delayed' : return 3;
            case 'Canceled': return 5;
            default: return 4; // 'Advanced'
        }
    }
    
    
    // Initialization
    $scope.initialization();

}

/*
 {
 "flight":{
 "flightId":1025849405,
 "flightNote":{
 "final":true,
 "canceled":false,
 "hasDepartedGate":true,
 "hasDepartedRunway":true,
 "landed":true,
 "message":"The flight has landed",
 "messageCode":"L",
 "pastExpectedTakeOff":true,
 "tracking":false,
 "hasPositions":true,
 "trackingUnavailable":false,
 "phase":"Landed",
 "hasActualRunwayDepartureTime":true,
 "hasActualGateDepartureTime":true
 },
 "isTracking":false,
 "isLanded":true,
 "isScheduled":false,
 "sortTime":"2019-12-28T02:10:00.000Z",    
 "schedule":{
 "scheduledDeparture":"2019-12-27T21:10:00.000",
 "scheduledDepartureUTC":"2019-12-28T02:10:00.000Z",
 "estimatedActualDepartureRunway":false,
 "estimatedActualDepartureTitle":"Actual",
 "estimatedActualDeparture":"2019-12-27T23:57:00.000",
 "estimatedActualDepartureUTC":"2019-12-28T04:57:00.000Z",
 "scheduledArrival":"2019-12-28T01:05:00.000",
 "scheduledArrivalUTC":"2019-12-28T04:35:00.000Z",
 "estimatedActualArrivalRunway":false,
 "estimatedActualArrivalTitle":"Actual",
 "estimatedActualArrival":"2019-12-28T03:36:00.000",
 "estimatedActualArrivalUTC":"2019-12-28T07:06:00.000Z",
 "graphXAxis":{
 "dep":"2019-12-27T23:57:00.000",
 "depUTC":"2019-12-28T04:57:00.000Z",
 "arr":"2019-12-28T03:36:00.000",
 "arrUTC":"2019-12-28T07:06:00.000Z"
 },
 "tookOff":"2019-12-27T23:57:00.000",
 "landing":"2019-12-28T03:36:00.000",
 "isLanded":true
 },
 "status":{
 "statusCode":"L",
 "status":"Arrived",
 "color":"yellow",
 "statusDescription":"Delayed by 2h 31m",
 "delay":{
 "departure":{
 "minutes":167
 },
 "arrival":{
 "minutes":151
 }
 },
 "delayStatus":{
 "wording":"Delayed by 2h 31m",
 "minutes":151
 },
 "lastUpdatedText":"Status Last Updated More Than 3 Hours Ago",
 "finalStatus":"Delayed",
 "diverted":false
 },
 "resultHeader":{
 "statusDescription":"Delayed by 2h 31m",
 "carrier":{
 "name":"Lufthansa",
 "fs":"LH"
 },
 "flightNumber":"6686",
 "status":"Arrived",
 "diverted":false,
 "color":"yellow",
 "departureAirportFS":"YUL",
 "arrivalAirportFS":"YYT",
 "divertedAirport":null
 },
 "ticketHeader":{
 "carrier":{
 "name":"Lufthansa",
 "fs":"LH"
 },
 "flightNumber":"6686",
 "iconURL":"https://d3brl4nqahsb3e.cloudfront.net/logos/png/150x50/lh-logo.png"
 },
 "operatedBy":"Operated by Jazz on behalf of Air Canada 8018",
 "departureAirport":{
 "fs":"YUL",
 "iata":"YUL",
 "name":"Montreal-Pierre Elliott Trudeau International Airport",
 "city":"Montreal",
 "state":"QC",
 "country":"CA",
 "timeZoneRegionName":"America/Toronto",
 "regionName":"North America",
 "gate":"A6",
 "terminal":null,
 "times":{
 "scheduled":{
 "time":"9:10",
 "ampm":"PM",
 "time24":"21:10",
 "timezone":"EST"
 },
 "estimatedActual":{
 "title":"Actual",
 "time":"11:57",
 "ampm":"PM",
 "time24":"23:57",
 "runway":false,
 "timezone":"EST"
 }
 },
 "date":"2019-12-27T21:10:00.000"
 },
 "arrivalAirport":{
 "fs":"YYT",
 "iata":"YYT",
 "name":"St. John's International Airport",
 "city":"St. John's",
 "state":"NL",
 "country":"CA",
 "timeZoneRegionName":"America/St_Johns",
 "regionName":"North America",
 "gate":null,
 "terminal":null,
 "baggage":null,
 "times":{
 "scheduled":{
 "time":"1:05",
 "ampm":"AM",
 "time24":"01:05",
 "timezone":"NST"
 },
 "estimatedActual":{
 "title":"Actual",
 "time":"3:36",
 "ampm":"AM",
 "time24":"03:36",
 "runway":false,
 "timezone":"NST"
 }
 },
 "date":"2019-12-28T01:05:00.000"
 },
 "divertedAirport":null,
 "additionalFlightInfo":{
 "equipment":{
 "iata":"CR9",
 "name":"Canadair (Bombardier) Regional Jet 900 and Challenger 890",
 "title":"Actual"
 },
 "flightDuration":"2h 9m"
 },
 "codeshares":[
 {
 "fs":"CA",
 "name":"Air China LTD",
 "flightNumber":"7539"
 },
 {
 "fs":"TK",
 "name":"Turkish Airlines",
 "flightNumber":"9112"
 },
 {
 "fs":"AC",
 "name":"Air Canada",
 "flightNumber":"8018"
 }
 ],
 "positional":{
 "departureAirportCode":"YUL",
 "arrivalAirportCode":"YYT",
 "divertedAirportCode":null,
 "flexFlightStatus":"L",
 "flexTrack":{
 "flightId":1025849405,
 "carrierFsCode":"QK",
 "flightNumber":"8018",
 "callsign":"JZA8018",
 "departureAirportFsCode":"YUL",
 "arrivalAirportFsCode":"YYT",
 "departureDate":{
 "dateLocal":"2019-12-27T21:10:00.000",
 "dateUtc":"2019-12-28T02:10:00.000Z"
 },
 "equipment":"CR9",
 "delayMinutes":151,
 "bearing":88.87988135274742,
 "heading":88.72659518168338,
 "positions":[
 {
 "lon": - 53.2795,
 "lat":47.607,
 "speedMph":249,
 "altitudeFt":7653,
 "source":"derived",
 "date":"2019-12-28T07:01:11.052Z",
 "course":89,
 "vrateMps": - 5
 },
 {
 "lon": - 53.3714,
 "lat":47.6058,
 "speedMph":264,
 "altitudeFt":8574,
 "source":"derived",
 "date":"2019-12-28T07:00:10.971Z",
 "course":89,
 "vrateMps": - 5
 }
 ],
 "irregularOperations":[
 ]
 }
 },
 "flightState":"historical"
 }
 }
 
 */