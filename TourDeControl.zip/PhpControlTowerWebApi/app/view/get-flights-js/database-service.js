function DatabaseSevice($http, $log){
    
    var country_table_loaded, city_table_loaded, airport_table_loaded, airline_table_loaded, flightref_table_loaded, flight_table_loaded;
    
    this.init = function(){
        this.flightrefs = [];
        this.flights = [];
        this.tables_loaded = false;
        this.flights_and_references_loaded = false; 
        flightref_table_loaded = flight_table_loaded = false;
        country_table_loaded = city_table_loaded = airport_table_loaded = airline_table_loaded = false;
        this.getCountries();
        this.getAirlines();
        this.getAirports();
        this.getCities();
    }
    
    this.setTablesLoaded = function(){
        this.tables_loaded = country_table_loaded && city_table_loaded && airport_table_loaded && airline_table_loaded;
    }
    //===================================================================================================================================
    //-------------------------------------------------------------------------------------------------------------------> C O U N T R Y
    //===================================================================================================================================
    //Country(iso_alpha2_code, name) 
    
    this.getCountry = function(index){
        if (index>=0 & index < this.countries.length) 
            return this.countries[index];
        else return null;
    }
    this.getCountryIsoCode = function(iso_code){
        var len = this.countries.length;
        for (var i=0; i<len; i++){
            if (this.countries[i].iso_alpha2_code.toUpperCase() === iso_code.toUpperCase()){
                return i;
            }
        }
        return -1;
    }
    this.addCountry = function(country){
        if (country instanceof Country) {
            return this.countries.push(country);
        }
        else return -1;
    }
    this.printCountries = function(nbr){
        var len = this.countries.length;
        if (len > nbr) len = nbr;
        $log.log(len + ' Countries');
        var out = '';
        for (var i = 0; i < len; i++){
            var country = new Country(this.countries[i].iso_alpha2_code, this.countries[i].name);
            out += country.toString() + '\n';
        }
        $log.log(out);
    }

    this.getCountries = function(){
       var self = this;
       self.countries = [];
       $http({method: 'GET', url: './flight/countries/json'})
            .then(function(response){
                self.countries = response.data;
                country_table_loaded = true; self.setTablesLoaded();
                $log.log('[Informa] Table countries loaded, size: ' + self.countries.length);
                
            }, function(response){
                $log.log('[Warning] Table countries not loaded: ' + response.status);
            }
        );

    }
    
    //===================================================================================================================================
    //-------------------------------------------------------------------------------------------------------------------------> C I T Y
    //===================================================================================================================================
    // City(id, name, state, country_id)
    
    this.getCityByIndex = function(index){
        if (index>=0 & index < this.cities.length) 
            return this.cities[index];
        else return null;
    }
    this.getCityIndex = function(name, state){
        var len = this.cities.length;
        for (var i = 0; i < len; i++){
            if (this.cities[i].name.toUpperCase() === name.toUpperCase() && this.cities[i].state.toUpperCase() === state.toUpperCase()){
                return i;
            }
        }
        return -1;
    }
    this.addCity = function(city){
        if (!(city instanceof City)) return -1;
        var index = this.getCityIndex(city.name, city.state);
        if (index !== -1 ) return index; 
        if (city.id === -1) city.setId(this.cities.length+1); //$log.log('Adding city: ' + city.toString());
        return this.cities.push(city) - 1;
    }
    this.getCities = function(){
       var self = this;
       self.cities = [];
       self.nextCityIndex = 0; 
       $http({method: 'GET', url: './flight/cities/json'})
            .then(function(response){
                self.cities = response.data;
                city_table_loaded = true; self.setTablesLoaded();
                self.nextCityIndex = self.cities.length;
                $log.log('[Informa] Table cities loaded, size: ' + self.cities.length);
                
            }, function(response){
                $log.log('[Warning] Table cities not loaded: ' + response.status);
            }
        );
    }
    this.getCitiesToTransfer = function(){
        if (this.nextCityIndex == 0) return this.cities;
        return this.cities.slice(this.nextCityIndex, this.cities.length);
    }
    this.printCities = function(){
        var len = this.cities.length;
        $log.log(len +' Cities');
        var out = '';
        for (var i = 0; i < len; i++){
            var city = new City(this.cities[i].id, this.cities[i].name, this.cities[i].state, this.cities[i].country_id);
            out += city.toString() + '\n';
        }
        $log.log(out);
    }
       
    
    //===================================================================================================================================
    //-------------------------------------------------------------------------------------------------------------------> A I R P O R T
    //===================================================================================================================================
    // Airport(iata, name, city_id, url_logo)
    
    this.getAirportByIndex = function(index){
        if (index>=0 & index < this.airports.length) 
            return this.airports[index];
        else return null;
    }
    this.getAirportIndex = function(iata){
        var len = this.airports.length;
        for (var i = 0; i < len; i++){
            if (this.airports[i].iata.toUpperCase() === iata.toUpperCase()){
                return i;
            }
        }
        return -1;
    }
    this.getAirportIata = function(index){
        if (index < this.airports.length && index >= 0) return this.airports[index].iata;
        return '';
    }
    this.addAirport = function(airport){
        if (!(airport instanceof Airport)) return -1;
        var index = this.getAirportIndex(airport.iata);
        if (index !== -1 ) return index; 
        return this.airports.push(airport) - 1;
    }
    this.getAirports = function(){
       var self = this;
       self.airports = [];
       self.nextAirportIndex = 0; 
       $http({method: 'GET', url: './flight/airports/json'})
            .then(function(response){
                self.airports = response.data;
                airport_table_loaded = true; self.setTablesLoaded();
                self.nextAirportIndex = self.airports.length;
                $log.log('[Informa] Table airports loaded, size: ' + self.airports.length);
                
            }, function(response){
                $log.log('[Warning] Table airports not loaded: ' + response.status);
            }
        );
    }
    this.getAirportsToTransfer = function(){
        if (this.nextAirportIndex == 0) return this.airports;
        return this.airports.slice(this.nextAirportIndex, this.airports.length);
    }
    this.printAirports = function(){
        var len = this.airports.length;
        $log.log(len +' airports');
        var out = '';
        for (var i = 0; i < len; i++){
            var airport = new Airport(this.airports[i].iata, this.airports[i].name, this.airports[i].city_id, this.airports[i].url_logo);
            out += airport.toString() + '\n';
        }
        $log.log(out);
    } 
    
    //===================================================================================================================================
    //-------------------------------------------------------------------------------------------------------------------> A I R L I N E
    //===================================================================================================================================
    // Airline(iata, name, oaci, country_iso_code, url_icon)
    
    this.getAirlineByIndex = function(index){
        if (index>=0 & index < this.airlines.length) 
            return this.airlines[index];
        else return null;
    }
    this.getAirlineIndex = function(iata){
        var len = this.airlines.length;
        for (var i = 0; i < len; i++){
            if (this.airlines[i].iata.toUpperCase() === iata.toUpperCase()){
                return i;
            }
        }
        return -1;
    }
    this.getAirlineIata = function(index){
        if (index < this.airlines.length && index >= 0) return this.airlines[index].iata;
        return '';
    }
    this.addAirline = function(airline){
        if (!(airline instanceof Airline)) return -1;
        var index = this.getAirlineIndex(airline.iata);
        if (index !== -1 ) {
            //if (this.airlines[index].url_icon == "" || this.airlines[index].url_icon == null) this.airlines[index].url_icon = airline.url_icon;
            return index;
        } 
        return this.airlines.push(airline);
    }
    this.getAirlines = function(){
       var self = this;
       self.airlines = [];
       $http({method: 'GET', url: './flight/airlines/json'})
            .then(function(response){
                self.airlines = response.data;
                airline_table_loaded = true; self.setTablesLoaded();
                $log.log('[Informa] Table airlines loaded, size: ' + self.airlines.length);
                
            }, function(response){
                $log.log('[Warning] Table airlines not loaded: ' + response.status);
            }
        );
    }
    this.printAirlines = function(){
        var len = this.airlines.length;
        $log.log(len +' airlines');
        var out = '';
        for (var i = 0; i < len; i++){
            var airline = new Airline(this.airlines[i].iata, this.airlines[i].name, this.airlines[i].oaci,  
                                    this.airlines[i].country_iso_code, this.airlines[i].url_icon);
            out += airline.toString() + '\n';
        }
        $log.log(out);
    } 
     
    //===================================================================================================================================
    //-----------------------------------------------------------------------------------------------------> F L G H T R E F E R E N C E
    //===================================================================================================================================
    // FlightReference(flightnumber, airline_iata, airport_iata, direction, time)
    
    this.getFlightRefByIndex = function(index){
        if (index>=0 & index < this.flightrefs.length) 
            return this.flightrefs[index];
        else return null;
    }
    this.getFlightRefIndex = function(flightnumber){
        var len = this.flightrefs.length;
        for (var i = 0; i < len; i++){
            if (this.flightrefs[i].flightnumber.toUpperCase() === flightnumber.toUpperCase()){
                return i;
            }
        }
        return -1;
    }
    this.addFlightRef = function(flightref){
        if (!(flightref instanceof FlightReference)) return -1;
        var index = this.getFlightRefIndex(flightref.flightnumber);
        if (index !== -1 ) return index; 
        return this.flightrefs.push(flightref);
    }
    
    this.getFlightRefs = function(){
       var self = this;
       self.flightrefs = [];
       $http({method: 'GET', url: './flight/flightrefs/json'})
            .then(function(response){
                self.flightrefs = response.data;
                self.printFlightRefs();
                flightref_table_loaded = true;
                this.flights_and_references_loaded = flightref_table_loaded && flight_table_loaded;
                $log.log('[Informa] Table flightrefs loaded, size: ' + self.flightrefs.length);
                
            }, function(response){
                $log.log('[Warning] Table flightrefs not loaded: ' + response.status);
            }
        );
    }
    
    this.printFlightRefs = function(){
        var len = this.flightrefs.length;
        $log.log(len +' flightrefs');
        var out = '';
        for (var i = 0; i < len; i++){
            out += '[' + this.flightrefs[i].flightref_number + ', ' + this.flightrefs[i].scheduled_time+ ', ' + 
                    this.flightrefs[i].estimated_time  + ', ' + this.flightrefs[i].status  + ', ' + 
                    this.terminal  + ', ' + this.gate + ']\n';
        }
        $log.log(out);
    } 
    
    //===================================================================================================================================
    //-----------------------------------------------------------------------------------------------------------------------> F L G H T
    //===================================================================================================================================
    // Flight(flightref_number, scheduled_time, estimated_time, status, terminal, gate)
    
    this.getFlightByIndex = function(index){
        if (index>=0 & index < this.flights.length) 
            return this.flights[index];
        else return null;
    }
    this.getFlightIndex = function(flightref_number, scheduled_time){
        var len = this.flights.length;
        for (var i = 0; i < len; i++){
            if (this.flights[i].flightref_number.toUpperCase() === flightref_number.toUpperCase() &&
                                            this.flights[i].scheduled_time === scheduled_time){
                return i;
            }
        }
        return -1;
    }
    this.addFlight = function(flight){
        if (!(flight instanceof Flight)) return -1;
        var index = this.getFlightIndex(flight.flightref_number, flight.scheduled_time);
        if (index !== -1 ) return index; 
        return this.flights.push(flight);
    }
    this.getFlights = function(){
       var self = this;
       self.flights = [];
       $http({method: 'GET', url: './flight/flights/json'})
            .then(function(response){
                self.flights = response.data;
                self.printFlights();
                flight_table_loaded = true;
                this.flights_and_references_loaded = flightref_table_loaded && flight_table_loaded;
                $log.log('[Informa] Table flights loaded, size: ' + self.flights.length);
                
            }, function(response){
                $log.log('[Warning] Table flights not loaded: ' + response.status);
            }
        );
    }
    this.printFlights = function(nbr){
        var len = this.flights.length;
        if (len > nbr) len = nbr;
        $log.log(len +' flights');
        var out = '';
        for (var i = 0; i < len; i++){
            out += this.flights[i].toString() + '\n';
        }
        $log.log(out);
    }  
     
    //Initialization
    this.init();
}

