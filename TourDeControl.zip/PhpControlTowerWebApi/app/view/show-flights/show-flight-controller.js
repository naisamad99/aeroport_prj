console.log('Loading of ShowFlightController =...');

function ShowFlightController($scope, $http, $log) {

    // initialization
    $scope.initialization = function () {
        $scope.period_day_numbers = [{desc : '1 day', val: 1}, {desc : '2 days', val: 2}, {desc : '3 days', val: 3}, {desc : '4 days', val: 4}, {desc : '5 days', val: 5}, {desc : '6 days', val: 6}, {desc : '7 days', val: 7}];
        $scope.period_day_number = $scope.period_day_numbers[2];
        $scope.airports = [{name: 'Montreal Airport', code: 'YUL'}, {name: 'Quebec City Jean Lesage International Airport', code: 'YQB'}, {name: 'Houari Boumediene(Algiers) Airport', code: 'ALG'}];
        $scope.directions = ['Departures', 'Arrivals'];
        $scope.ourAirport = {active: true, city: '', classification: '', country: '', fs: '', iata: '', icao: '', name: '', state: '', timeZoneRegionName: ''};
        $scope.updateStatusColor = [];
        $scope.timeranges = [{desc: '00h-06h', val: 0}, {desc: '06h-12h', val: 6}, {desc: '12h-18h', val: 12}, {desc: '18h-24h', val: 18}];
        $scope.loaded = 0;
        $scope.setParameters();
        
    }
    
    // Methods
    
    $scope.setParameters = function () {
        $scope.airport = $scope.airports[0];
        $scope.direction = $scope.directions[0];
        $scope.timerange = $scope.timeranges[0];
        $scope.dates = getDates($scope.period_day_number.val);
        $scope.selecteddate = $scope.dates[($scope.period_day_number.val === 1)? 0 : Math.round($scope.period_day_number.val / 2)];
        $scope.loaded = 0;
        $scope.updateFlightList();
    }
    
    
    $scope.updateFlightList = function () {
        var date = new Date($scope.selecteddate.val);
        var year = date.getFullYear();
        var month = date.getMonth() + 1;
        var day = date.getDate();
        var result_type = '/JSON';
        $scope.flights = {};
        $scope.loaded = 0;
        $scope.content = '';
        $scope.status = '';
        var url = './flight/list/'+ $scope.airport.code + '/' + $scope.direction + '/' + year + '/' + month + '/' + day + '/' + 
                                    $scope.timerange.val + result_type;  // $log.log(url);
        $http({method: 'GET', url : url})
            .then(function (response) {

                if (response.data.props) {
                    $scope.flights = response.data.props.initialState.flightTracker.route.flights;
                    $scope.ourAirport = response.data.props.initialState.flightTracker.departureAirport;
                    if (isEmpty($scope.ourAirport))
                        $scope.ourAirport = response.data.props.initialState.flightTracker.arrivalAirport;
                    
                    var len = $scope.flights.length; 
                    for (var i=0; i<len; i++){ $scope.updateStatusColor[i] = 'red'; }
                    for (var i=0; i<3; i++){ $scope.getFlightDetail($scope.flights[i], i); }
                    
                }
                flightlist = response.data;
                $scope.content = response.data;
                $scope.status = response.status;
            }, function (response) {
                $log.log('Error loading: status: '+ response.status + 'url->[' + url + ']');
            });
    }

    $scope.getFlightDetail = function (flight, index) {
        var url_qry_str = flight.url.substr(flight.url.indexOf("?") + 1);
        var url = './flight/detail/'+ flight.carrier.fs + '/' + flight.carrier.flightNumber + '/' + url_qry_str + '/JSON'; //$log.log(url);
        $http({method: 'GET', url: url})
                .then(function (response) {
                    $scope.updateStatusColor[index] = 'green';
                    $scope.loaded++;
                    flightdetail = response.data; 
                    $scope.status = response.status;
                    $scope.content = response.data; 
                }, function (response) {
                    $log.log('Error loading: status: '+ response.status + 'url->[' + url + ']');
                });
    }
    

    
    
    // initialization
    $scope.initialization();

}

