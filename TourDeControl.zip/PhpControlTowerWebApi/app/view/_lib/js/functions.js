// Some useful functions

function isEmpty(obj) {
    for (var prop in obj) {
        if (obj.hasOwnProperty(prop))
            return false;
    }
    return true
}

function getDates(days = 7) {
    if (days > 7 || days < 1) days = 5;
    var dates = [];
    var d = new Date();
    var mdays = Math.round(days / 2);
    d.setDate(d.getDate() - mdays);
    for (var i = 0; i < days; i++) {
        d.setDate(d.getDate() + 1);
        var datestr = d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + ((d.getDate() < 10) ? '0' + d.getDate() : d.getDate());
        dates.push({desc: datestr, val: new Date(d)});
    }
    return dates;
}

function sleep(milliseconds) {
  const date = Date.now();
  let currentDate = null;
  do {
    currentDate = Date.now();
  } while (currentDate - date < milliseconds);
}




