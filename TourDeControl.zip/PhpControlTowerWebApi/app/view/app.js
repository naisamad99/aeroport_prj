//'use strict';

const requires = ['ui.router'];
const app = angular.module('ctrlTowerApp', requires);

console.log('[Informa] app loaded : 1');

app.config(['$stateProvider', '$urlRouterProvider', function ($stateProvider, $urlRouterProvider) {
        $stateProvider
                .state('home', {
                    url: '/home',
                    template: '<h2>Home page</h2><a href="./test">Verify Database Access</a>'
                })
                .state('listflights', {
                    url: '/listflights',
                    templateUrl: '../app/view/list-flights/list-flight-list.html',
                    controller: 'listflightController'
                })
                .state('showflights', {
                    url: '/showflights',
                    templateUrl: '../app/view/show-flights/show-flight-list.html',
                    controller: 'showflightController'
                })
                .state('getflights', {
                    url: '/getflights',
                    templateUrl: '../app/view/get-flights-js/get-flight-list.html',
                    controller: 'getflightController'
                })
                .state('saveflights', {
                    url: '/saveflights',
                    templateUrl: '../app/view/update-database/update-flight-list.html',
                    controller: 'updateflightController'
                })
                .state('aboutus', {
                    url: '/aboutus',
                    template: '<h2>About us page</h2>'
                });
        $urlRouterProvider.otherwise('listflights');
    }]);

app.service('databaseSevice', ['$http', '$log', DatabaseSevice]);

app.controller('navCtrl', ['$log', NavController]);

app.controller('listflightController', ListFlightController);

app.controller('showflightController', ShowFlightController);

app.controller('updateflightController', UpdateFlightController);

app.controller('getflightController', ['$scope', '$http', '$log', 'databaseSevice', GetFlightController]);


function NavController() {
    this.init = function(){
        this.profilName = 'user';
        this.profilChanged()
    }
    
    this.profilChanged = function(){
        console.log('profil changed: ' + this.profilName);
        this.adminProfil =  (this.profilName == 'admin');
        console.log('adminProfil: ' + this.adminProfil);
    }
    this.init();
    
}



