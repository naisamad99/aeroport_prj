<?php
//[iata, name, oaci, country_iso_code, url_icon]
class AirlineModel {

    private $airlines = null;
    private $initCount = 0;

    public function __construct() {
        $this->airlines = (new AirportQueryInterface())->selectWithQuery("SELECT * FROM airlines");
        $this->initCount = count($this->airlines);
    }
    
    public function getAirlines() {
        return $this->airlines;
    }

    public function getAirlineByIndex($index) {
        if ($index >= 0 && $index < count($this->airlines)) {
            return $this->airlines[$index];
        }
        return null;
    }
    
    public function getAirlineIndex($iata) {
        $index = -1;
        $iatacode = strtoupper($iata);
        $count = count($this->airlines);
        for ($i = 0; $i < $count; $i++) {
            if ($this->airlines[$i]->iata == $iatacode) {
                $index = $i; break;
            }
        }
        return $index;
    }
    
    public function addAirline($airline) {
        if (!$airline instanceof Airline) {
            return null;
        }
        $index = $this->getAirlineIndex($airline->getIata());
        if ($index == -1){
            $index = count($this->airlines);
            $this->airlines[$index] = new AirlineClass(strtoupper($airline->getIata()), $airline->getName(), $airline->getOaci(), 
                                                       $airline->getCountryIsoCode(), $airline->getUrlIcon());
        } 
        return $this->airlines[$index];
    }
    
    public function saveChanges() {
        $currentCount = count($this->airlines);
        for ($i = $this->initCount; $i < $currentCount; $i++) {
            $model = new AirportQueryInterface();
            $model->insert(new Airline($this->airlines[$i]->iata, $this->airlines[$i]->name, $this->airlines[$i]->oaci, 
                    $this->airlines[$i]->country_iso_code, $this->airlines[$i]->url_icon));
        }
        return '['.($currentCount-$this->initCount). ' airlines were added.]';
      
    }
    
}

class AirlineClass {
    
    public $iata;
    public $name;
    public $oaci;
    public $country_iso_code;
    public $url_icon;
    
    function __construct($iata, $name, $oaci, $country_iso_code, $url_icon) {
        $this->iata = $iata;
        $this->name = $name;
        $this->oaci = $oaci;
        $this->country_iso_code = $country_iso_code;
        $this->url_icon = $url_icon;
    }

    
}
