<?php
//[iata, name, city_id, url_logo]
class AirportModel {

    private $airports = null;
    private $initCount = 0;

    public function __construct() {
        $this->airports = (new AirportQueryInterface())->selectWithQuery("SELECT * FROM airports");
        $this->initCount = count($this->airports);
    }
    
    public function getAirports() {
        return $this->airports;
    }

    public function getAirportByIndex($index) {
        if ($index >= 0 && $index < count($this->airports)) {
            return $this->airports[$index];
        }
        return null;
    }
    
    public function getAirportIndex($iata) {
        $index = -1;
        $iatacode = strtoupper($iata);
        $count = count($this->airports);
        for ($i = 0; $i < $count; $i++) {
            if ($this->airports[$i]->iata == $iatacode) {
                $index = $i; break;
            }
        }
        return $index;
    }
    
    public function addAirport($airport) {
        if (!$airport instanceof Airport) return null;
        $index = $this->getAirportIndex($airport->getIata());
        if ($index == -1){
            $index = count($this->airports);
            $this->airports[$index] = new AirportClass(strtoupper($airport->getIata()), $airport->getName(), $airport->getCityId(), $airport->getUrlLogo());
        } 
        return $this->airports[$index];
    }
    
    public function saveChanges() {
        $currentCount = count($this->airports);
        for ($i = $this->initCount; $i < $currentCount; $i++) {
            $model = new AirportQueryInterface();
            $model->insert(new Airport($this->airports[$i]->iata, $this->airports[$i]->name, $this->airports[$i]->city_id, 
                                       $this->airports[$i]->url_logo));
        }
        return '['.($currentCount-$this->initCount). ' airports were added.]';
      
    }
    
}

class AirportClass {
    
    public $iata;
    public $name;
    public $city_id;
    public $url_logo;
    
    
    function __construct($iata, $name, $city_id, $url_logo) {
        $this->iata = $iata;
        $this->name = $name;
        $this->city_id = $city_id;
        $this->url_logo = $url_logo;
    }

    
}
