<?php

class UserModel {

    public $users = null;

    function __construct() {
        $this->users = [];
    }

    public function selectAll() {

        $query = 'SELECT * FROM users';
        $params = [];
        $pdo = new DataAccessObject(DSN, DB_USERNAME, DB_PASSWORD);
        $this->users = $pdo->query($query, $params);
        $pdo->close();
        return $this->users;
    }

    public function select($username_email, $password) {

        $query = 'SELECT * FROM users WHERE usr_password = :password AND (usr_username = :username_email OR usr_email = :username_email)';
        $params = ['username_email' => $username_email, 'password' => $password];
        
        $pdo = new DataAccessObject(DSN, DB_USERNAME, DB_PASSWORD);
        $this->users = $pdo->query($query, $params);
        $pdo->close();


        return $this->users;
    }

    public function insert(User $user) {
        $fields = ['username', 'email', 'password'];
        $values = [':username', ':email', ':password'];
        $query = 'INSERT INTO users(' . implode(',', $fields) . ' ) VALUES(' . implode(',', $values) . ')';
        $params = ['user_username' => $user->getUsername(), 'email' => $user->getEmail(), 'password' => $user->getPassword()];
        $pdo = new DataAccessObject(DSN, DB_USERNAME, DB_PASSWORD);
        $this->users = $pdo->query($query, $params);
        //$pdo->close();
        return $this->users;
    }

}
