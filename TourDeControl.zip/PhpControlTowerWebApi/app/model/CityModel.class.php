<?php

class CityModel {

    private $cities = null;
    private $initCount = 0;

    public function __construct() {
        $this->cities = (new AirportQueryInterface())->selectWithQuery("SELECT * FROM cities");
        $this->initCount = count($this->cities);
    }
    
    public function getCities() {
        return $this->cities;
    }

    public function getCityByIndex($index) {
        if ($index >= 0 && $index < count($this->cities)) {
            return $this->cities[$index];
        }
        return null;
    }
    
    public function getCity($city) {
        $index = -1;
        if ($city instanceof City) {
            $count = count($this->cities);
            for ($i = 0; $i < $count; $i++) {
                if ($this->cities[$i]->name == $city->getName() && $this->cities[$i]->state == $city->getState()) {
                    $index = $i; break;
                }
            }
        }
        return $index;
    }
    
    public function addCity($city) {
        $index = $this->getCity($city);
        if ($index == -1){
                $index = count($this->cities);
                $this->cities[$index] = new CityClass($index+1, $city->getName(), $city->getState(), $city->getCountryIsoCode());
        } 
        return $index;
    }
    
    public function saveChanges() {
        $currentCount = count($this->cities);
        
        for ($i = $this->initCount; $i < $currentCount; $i++) {
            $model = new AirportQueryInterface();
            $model->insert(new City($this->cities[$i]->id, $this->cities[$i]->name, $this->cities[$i]->state, $this->cities[$i]->country_iso_code));
        }
        return '['.($currentCount-$this->initCount). ' cities were added.]';
      
    }
    
}

class CityClass {
    
    public $id;
    public $name;
    public $state;
    public $country_iso_code;
    
    function __construct($id, $name, $state, $country_iso_code) {
        $this->id = $id;
        $this->name = $name;
        $this->state = $state;
        $this->country_iso_code = $country_iso_code;
    }

}
