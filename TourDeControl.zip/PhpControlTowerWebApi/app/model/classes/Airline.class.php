<?php

class Airline {
    
    private $iata;
    private $name;
    private $oaci;
    private $country_iso_code;
    private $url_icon;
    
    public function __construct($iata, $name, $oaci, $country_iso_code, $url_icon = '') {
        $this->iata = $iata;
        $this->name = $name;
        $this->oaci = $oaci;
        $this->country_iso_code = $country_iso_code;
        $this->url_icon = $url_icon;
    }

    public function getName() {
        return $this->name;
    }

    public function getIata() {
        return $this->iata;
    }

    public function getOaci() {
        return $this->oaci;
    }

    public function getCountryIsoCode() {
        return $this->country_iso_code;
    }

    public function getUrlIcon() {
        return $this->url_icon;
    }

    public function setName($name) {
        $this->name = $name;
    }

    public function setIata($iata) {
        $this->iata = $iata;
    }

    public function setOaci($oaci) {
        $this->oaci = $oaci;
    }

    public function setCountryIsoCode($country_iso_code) {
        $this->country_iso_code = $country_iso_code;
    }

    public function setUrlIcon($url_icon) {
        $this->url_icon = $url_icon;
    }


}
