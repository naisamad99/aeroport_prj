<?php

class Country {
    
    private $name;
    private $iso_alpha2_code;
    
    public function __construct($name, $iso_alpha2_code) {
        $this->name = $name;
        $this->iso_alpha2_code = $iso_alpha2_code;
    }

    public function getName() {
        return $this->name;
    }

    public function getIsoAlpha2Code() {
        return $this->iso_alpha2_code;
    }

    public function setName($name) {
        $this->name = $name;
    }

    public function setIsoAlpha2Code($iso_alpha2_code) {
        $this->iso_alpha2_code = $iso_alpha2_code;
    }



}
