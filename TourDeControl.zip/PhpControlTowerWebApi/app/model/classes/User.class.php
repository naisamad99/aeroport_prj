<?php


class User {
    
    private $id;
    private $username;
    private $email;
    private $password;
    private $account_type_id;
    private $group_id;
    private $subscription_date;
    private $logo;
    private $post_default_scope;
    
    function __construct($username, $email, $password) {
        $this->username = $username;
        $this->email = $email;
        $this->password = $password;
        $this->account_type_id = $account_type_id;
        $this->group_id = $group_id;
        $this->subscription_date = $subscription_date;
        $this->logo = $logo;
        $this->post_default_scope = $post_default_scope;
    }

    function getId() {
        return $this->id;
    }

    function getUsername() {
        return $this->username;
    }

    function getEmail() {
        return $this->email;
    }

    function getPassword() {
        return $this->password;
    }

    function getAccount_type_id() {
        return $this->account_type_id;
    }

    function getGroup_id() {
        return $this->group_id;
    }
    
    function getSubscription_date() {
        return $this->subscription_date;
    }

    function getLogo() {
        return $this->logo;
    }

    function getPost_default_scope() {
        return $this->post_default_scope;
    }

    function setId($id) {
        $this->id = $id;
    }

    function setUsername($username) {
        $this->username = $username;
    }

    function setEmail($email) {
        $this->email = $email;
    }

    function setPassword($password) {
        $this->password = $password;
    }
    
    function setAccount_type_id($account_type_id) {
        $this->account_type_id = $account_type_id;
    }

    function setGroup_id($group_id) {
        $this->group_id = $group_id;
    }

    function setSubscription_date($subscription_date) {
        $this->subscription_date = $subscription_date;
    }

    function setLogo($logo) {
        $this->logo = $logo;
    }

    function setPost_default_scope($post_default_scope) {
        $this->post_default_scope = $post_default_scope;
    }

        
    
    //Override
    public function __toString() {
        return "User [{$this->id}, {$this->username}, {$this->email}, {$this->password},"
                    . "{$this->groupe_id}, {$this->$subscription_date}, {$this->logo}, {$this->post_default_scope}]";
        }
}
