<?php


class Flight {
    
    private $id; 
    private $flightref_number; 
    private $scheduled_time;
    private $estimated_time; 
    private $status;
    private $terminal;
    private $gate;
            
    public function __construct($flightref_number, $scheduled_time, $estimated_time, $status, $terminal, $gate) {
        $this->id = -1;
        $this->flightref_number = $flightref_number;
        $this->scheduled_time = $scheduled_time;
        $this->estimated_time = $estimated_time;
        $this->status = $status;
        $this->terminal = $terminal;
        $this->gate = $gate;
    }

    public function getId() {
        return $this->id;
    }

    public function getFlightReferenceNumber() {
        return $this->flightref_number;
    }

    public function getScheduledTime() {
        return $this->scheduled_time;
    }

    public function getEstimatedTime() {
        return $this->estimated_time;
    }

    public function getStatus() {
        return $this->status;
    }

    public function getTerminal() {
        return $this->terminal;
    }

    public function getGate() {
        return $this->gate;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function setFlightReferenceNumber($flightref_number) {
        $this->flightref_number = $flightref_number;
    }

    public function setScheduledTime($scheduled_time) {
        $this->scheduled_time = $scheduled_time;
    }

    public function setEstimatedTime($estimated_time) {
        $this->estimated_time = $estimated_time;
    }

    public function setStatus($status) {
        $this->status = $status;
    }

    public function setTerminal($terminal) {
        $this->terminal = $terminal;
    }

    public function setGate($gate) {
        $this->gate = $gate;
    }


    
}
