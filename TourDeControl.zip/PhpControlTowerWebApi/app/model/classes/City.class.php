<?php

class City {
    
    private $id;
    private $name;
    private $state;
    private $country_iso_code;
    
    
    function __construct($id, $name, $state, $country_iso_code) {
        $this->id = $id;
        $this->name = $name;
        $this->state = $state;
        $this->country_iso_code = $country_iso_code;
    }

    function getId() {
        return $this->id;
    }

    function getName() {
        return $this->name;
    }

    function getState() {
        return $this->state;
    }

    function getCountryIsoCode() {
        return $this->country_iso_code;
    }

    function setId($id) {
        $this->id = $id;
    }

    function setName($name) {
        $this->name = $name;
    }

    function setState($state) {
        $this->state = $state;
    }

    function setCountryIsoCode($country_iso_code) {
        $this->country_iso_code = $country_iso_code;
    }


}
