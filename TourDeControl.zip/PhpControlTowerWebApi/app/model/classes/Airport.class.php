<?php

class Airport {
    
    private $iata;
    private $name;
    private $city_id;
    private $url_logo;
   
    public function __construct($iata, $name, $city_id, $url_logo = '') {
        $this->name = $name;
        $this->iata = $iata;
        $this->city_id = $city_id;
        $this->url_logo = $url_logo;
    }

    public function getName() {
        return $this->name;
    }

    public function getIata() {
        return $this->iata;
    }

    public function getCityId() {
        return $this->city_id;
    }

    public function getUrlLogo() {
        return $this->url_logo;
    }

    public function setName($name) {
        $this->name = $name;
    }

    public function setIata($iata) {
        $this->iata = $iata;
    }

    public function setCityId($city_id) {
        $this->city_id = $city_id;
    }

    public function setUrlLogo($url_logo) {
        $this->url_logo = $url_logo;
    }



}
