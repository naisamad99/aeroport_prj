<?php


class FlightReference {
    
    private $flightnumber; 
    private $airline_iata; 
    private $airport_iata; 
    private $direction; 
    private $time;
    
    function __construct($flightnumber, $airline_iata, $airport_iata, $direction, $time) {
        $this->flightnumber = $flightnumber;
        $this->airline_iata = $airline_iata;
        $this->airport_iata = $airport_iata;
        $this->direction = $direction;
        $this->time = $time;
    }
    
    function getFlightNumber() {
        return $this->flightnumber;
    }

    function getAirlineIata() {
        return $this->airline_iata;
    }

    function getAirportIata() {
        return $this->airport_iata;
    }

    function getDirection() {
        return $this->direction;
    }

    function getTime() {
        return $this->time;
    }

    function setFlightNumber($flightnumber) {
        $this->flightnumber = $flightnumber;
    }

    function setAirlineIata($airline_iata) {
        $this->airline_iata = $airline_iata;
    }

    function setAirportIata($airport_iata) {
        $this->airport_iata = $airport_iata;
    }

    function setDirection($direction) {
        $this->direction = $direction;
    }

    function setTime($time) {
        $this->time = $time;
    }


    

}
