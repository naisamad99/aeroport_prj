<?php

class CountryModel {

    private $countries = null;
    private $initCount = 0;

    public function __construct() {
        $this->countries = (new AirportQueryInterface())->selectWithQuery("SELECT * FROM countries");
        $this->initCount = count($this->countries);
    }
    
    public function getCountries() {
        return $this->countries;
    }

    public function getCountryByIndex($index) {
        if ($index >= 0 && $index < count($this->countries)) {
            return $this->countries[$index];
        }
        return null;
    }
    
    public function getCountryIsoCodeByName($country_name) {
        $iata = '';
        $country_name = strtoupper($country_name);
        $count = count($this->countries);
        for ($i = 0; $i < $count; $i++) {
            if (strtoupper($this->countries[$i]->name) == $country_name) {
                $iata = $this->countries[$i]->iso_alpha2_code; break;
            }
        }
        return $iata;
    }
    public function getCountryIndex($countryisocode) {
        $index = -1;
        $count = count($this->countries);
        for ($i = 0; $i < $count; $i++) {
            if ($this->countries[$i]->iso_alpha2_code == strtoupper($countryisocode)) {
                $index = $i; break;
            }
        }
        return $index;
    }
    
    public function addCountry($country) {
        if (!$country instanceof Country) {
            return -1;
        }
        $index = $this->getCountryIndex($country->getIsoAlpha2Code());
        if ($index == -1){
                $index = count($this->countries);
                $this->countries[$index] = $this->countries[$index] = new CountryClass($country->getName(), $country->getIsoAlpha2Code());
        } 
        return $index;
    }
    
    public function saveChanges() {
        $currentCount = count($this->countries);
        
        for ($i = $this->initCount; $i < $currentCount; $i++) {
            $model = new AirportQueryInterface();
            $model->insert(new Country($this->countries[$i]->name, $this->countries[$i]->iso_alpha2_code));
        }
        return '['.($currentCount-$this->initCount). ' countries were added.]';
      
    }
    
}

class CountryClass {
    
    public $id;
    public $name;
    public $iso_alpha2_code;
    
    function __construct($name, $iso_alpha2_code) {
        $this->id = -1;
        $this->name = $name;
        $this->iso_alpha2_code = $iso_alpha2_code;
    }

}
