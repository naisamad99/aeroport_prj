<?php

class AirportQueryInterface2 {
    
    private $data;

    public function __construct() {
        $data = '';
    }

    public function selectFromTables($cols, $tables, $where = '') {
        
        $query = 'SELECT '. implode(',', $cols) .' FROM '. implode(',', $tables) . (empty($where)? '' : ' WHERE ' . $where);
        $params = [];
        $pdo = new DataAccessObject2(DSN, DB_USERNAME, DB_PASSWORD);
        $this->data = $pdo->query($query, $params);
        $pdo->close();
        return $this->data;
           
    }
    
    public function selectWithQuery($query) {
        
        $params = [];
        $pdo = new DataAccessObject2(DSN, DB_USERNAME, DB_PASSWORD);
        $this->data = $pdo->query($query, $params);
        $pdo->close();
        return $this->data;
    }

    public function updateWithQuery($query) {
        
        $params = [];
        $pdo = new DataAccessObject(DSN, DB_USERNAME, DB_PASSWORD);
        $this->data = $pdo->query($query, $params);
        $pdo->close();
        return $this->data;
    }
    
    public function insert($classObject) {
        
        switch($classObject) {
            
            //--------------------------------------------------------------------------[iata, name, oaci, country_iso_code, url_icon]
             case $classObject instanceof Airline: 
                $table = 'airlines';
                $fields = ['iata', 'name', 'oaci', 'country_iso_code', 'url_icon'];
                $values = [':iata', ':name', ':oaci', ':country_iso_code', ':url_icon'];
                $params = [':iata' => $classObject->getIata(), ':name' => $classObject->getName(), ':oaci' => $classObject->getOaci(), 
                           ':country_iso_code' => $classObject->getCountryIsoCode(), ':url_icon' => $classObject->getUrlIcon()];
                break;
            //-----------------------------------------------------------------------------------------[iata, name, city_id, url_logo]
            case $classObject instanceof Airport: 
                $table = 'airports';
                $fields = ['iata', 'name', 'city_id', 'url_logo'];
                $values = [':iata', ':name', ':city_id', ':url_logo'];
                $params = [':iata' => $classObject->getIata(), ':name' => $classObject->getName(), 
                           ':city_id' => $classObject->getCityId(), ':url_logo' => $classObject->getUrlLogo()];
                break;
            //-------------------------------------------------------------------------------------[id, name, state, country_iso_code]
            case $classObject instanceof City: 
                $table = 'cities';
                $fields = ['id', 'name', 'state', 'country_iso_code'];
                $values = [':id', ':name', ':state', ':country_iso_code'];
                $params = [':id' => $classObject->getId(), ':name' => $classObject->getName(), 
                           ':state' => $classObject->getState(), ':country_iso_code' => $classObject->getCountryIsoCode()];
                break;
            //-------------------------------------------------------------------------------------------------[name, iso_alpha2_code]
            case $classObject instanceof Country:
                $table = 'countries';
                $fields = ['name', 'iso_alpha2_code'];
                $values = [':name', ':iso_alpha2_code'];
                $params = [':name' => $classObject->getName(), ':iso_alpha2_code' => $classObject->getIsoAlpha2Code()];
                break;
            //-------------------------------------------------------------[flightnumber, airline_iata, airport_iata, direction, time]
            case $classObject instanceof FlightReference: 
                $table = 'flightreferences';
                $fields = ['flightnumber', 'airline_iata', 'airport_iata', 'direction', 'time'];
                $values = [':flightnumber', ':airline_iata', ':airport_iata', ':direction', ':time'];
                $params = [':flightnumber' => $classObject->getFlightNumber(), ':airline_iata' => $classObject->getAirlineIata(), 
                            ':airport_iata' => $classObject->getAirportIata(), ':direction' => $classObject->getDirection(), 
                            ':time' => $classObject->getTime()];
                break;
            //------------------------------------------[id, flightref_number, scheduled_time, estimated_time, status, terminal, gate]
            case $classObject instanceof Flight: 
                $table = 'flights';
                $fields = ['flightref_number', 'scheduled_time', 'estimated_time', 'status', 'terminal', 'gate'];
                $values = [':flightref_number', ':scheduled_time', ':estimated_time', ':status', ':terminal', ':gate'];
                $params = [':flightref_number' => $classObject->getFlightReferenceNumber(), 
                           ':scheduled_time' => $classObject->getScheduledTime(), 
                           ':estimated_time' => $classObject->getEstimatedTime(), ':status' => $classObject->getStatus(), 
                           ':terminal' => $classObject->getTerminal(), ':gate' => $classObject->getGate()];
                break;
        
        }
        
        $query = 'INSERT INTO '. $table . '(' . implode(',', $fields) . ') VALUES(' . implode(',', $values) . ')'; //return $query;
        $pdo = new DataAccessObject2(DSN, DB_USERNAME, DB_PASSWORD);
        $this->data = $pdo->query($query, $params);
        $pdo->close();
        return $this->data;
    }
    
    public function test() {
        $str = 'Inside FlightModel';
        
        return $str;
    }
}
