<?php
//[flightnumber, airline_iata, airport_iata, direction, time]
class FlightReferenceModel {

    private $flightReferences = null;
    private $initCount = 0;

    public function __construct() {
        $this->flightReferences = (new AirportQueryInterface())->selectWithQuery("SELECT * FROM flightReferences");
        $this->initCount = count($this->flightReferences);
    }
    
    public function getFlightReferences() {
        return $this->flightReferences;
    }

    public function getFlightReferenceByIndex($index) {
        if ($index >= 0 && $index < count($this->flightReferences)) {
            return $this->flightReferences[$index];
        }
        return null;
    }
    
    public function getFlightReferenceIndex($flightNumber) {
        $index = -1;
        $flightnumber = strtoupper($flightNumber);
        $count = count($this->flightReferences);
        for ($i = 0; $i < $count; $i++) {
            if (strtoupper($this->flightReferences[$i]->flightnumber) == $flightnumber) {
                $index = $i; break;
            }
        }
        return $index;
    }
    
    public function addFlightReference($flightReference) {
        if (!$flightReference instanceof FlightReference) {
            return -1;
        }
        $index = $this->getFlightReferenceIndex($flightReference->getFlightnumber());
        if ($index == -1){
            $index = count($this->flightReferences);
            $this->flightReferences[$index] = new FlightReferenceClass($flightReference->getFlightNumber(), $flightReference->getAirlineIata(), 
                                                  $flightReference->getAirportIata(), $flightReference->getDirection(), $flightReference->getTime());
        } 
        return $index;
    }
    
    public function saveChanges() {
        $currentCount = count($this->flightReferences);
        for ($i = $this->initCount; $i < $currentCount; $i++) {
            $model = new AirportQueryInterface();
            $model->insert(new FlightReference($this->flightReferences[$i]->flightnumber, $this->flightReferences[$i]->airline_iata, 
                               $this->flightReferences[$i]->airport_iata, $this->flightReferences[$i]->direction, $this->flightReferences[$i]->time));
        }
        return '['.($currentCount-$this->initCount). ' flightReferences were added.]';
      
    }
    
}

class FlightReferenceClass {
    public $flightnumber;
    public $airline_iata;
    public $airport_iata;
    public $direction;
    public $time;
    
    function __construct($flightnumber, $airline_iata, $airport_iata, $direction, $time) {
        $this->flightnumber = $flightnumber;
        $this->airline_iata = $airline_iata;
        $this->airport_iata = $airport_iata;
        $this->direction = $direction;
        $this->time = $time;
    }

}
