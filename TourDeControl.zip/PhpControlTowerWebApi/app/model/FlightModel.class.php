<?php
//[id, flightref_number, scheduled_time, estimated_time, status, terminal, gate]
class FlightModel {

    private $flights = null;
    private $initCount = 0;

    public function __construct() {
        $this->flights = (new AirportQueryInterface())->selectWithQuery("SELECT * FROM flights");
        $this->initCount = count($this->flights);
    }
    
    public function getFlights() {
        return $this->flights;
    }

    public function getFlightByIndex($index) {
        if ($index >= 0 && $index < count($this->flights)) {
            return $this->flights[$index];
        }
        return null;
    }
    
    public function getFlightIndex($flightrefnumber, $scheduled_time) {
        $index = -1;
        $count = count($this->flights);
        for ($i = 0; $i < $count; $i++) {
            if ($this->flights[$i]->flightref_number == $flightrefnumber && $this->flights[$i]->scheduled_time == $scheduled_time) {
                $index = $i; break;
            }
        }
        return $index;
    }
    
    public function addFlight($flight) {
        if (!$flight instanceof Flight) {
            return null;
        }
        $index = $this->getFlightIndex($flight->getFlightReferenceNumber(), $flight->getScheduledTime());
        echo 'index='. $index;
        if ($index == -1){
            echo '|Added';
            $index = count($this->flights);
            $this->flights[$index] = new FlightClass($flight->getFlightReferenceNumber(), $flight->getScheduledTime(), 
                                        $flight->getEstimatedTime(), $flight->getStatus(), $flight->getTerminal(), $flight->getGate());
        } 
        return $this->flights[$index];
    }
    
    public function pushFlight($flight) {
        $index = count($this->flights);
        $this->flights[$index] = new FlightClass($flight->getFlightReferenceNumber(), $flight->getScheduledTime(), 
                                        $flight->getEstimatedTime(), $flight->getStatus(), $flight->getTerminal(), $flight->getGate());
        return $this->flights[$index];
    }
    public function saveChanges() {
        $currentCount = count($this->flights);
        for ($i = $this->initCount; $i < $currentCount; $i++) {
            $model = new AirportQueryInterface();
            $model->insert(new Flight($this->flights[$i]->flightref_number, $this->flights[$i]->scheduled_time, $this->flights[$i]->estimated_time, 
                                    $this->flights[$i]->status, $this->flights[$i]->terminal, $this->flights[$i]->gate));
        }
        return '['.($currentCount-$this->initCount). ' flights were added.]';
      
    }
    
}

class FlightClass {
    public $id;
    public $flightref_number;
    public $scheduled_time;
    public $estimated_time;
    public $status;
    public $terminal;
    public $gate;
    
    function __construct($flightref_number, $scheduled_time, $estimated_time, $status, $terminal, $gate) {
        $this->id = -1;  // Auto-Increment
        $this->flightref_number = $flightref_number;
        $this->scheduled_time = $scheduled_time;
        $this->estimated_time = $estimated_time;
        $this->status = $status;
        $this->terminal = $terminal;
        $this->gate = $gate;
    }

    
}
